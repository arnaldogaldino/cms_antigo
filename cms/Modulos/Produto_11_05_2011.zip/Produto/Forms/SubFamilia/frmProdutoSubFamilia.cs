﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using cms.Data;

namespace cms.Modulos.Produto.Forms.SubFamilia
{
    public partial class frmProdutoSubFamilia : cms.Modulos.Util.WindowBase
    {

        cms.Modulos.Produto.Cn.cnSubFamilia cProdutoSubFamilia = new cms.Modulos.Produto.Cn.cnSubFamilia();
        cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia _fProdutoFamilia;

        private produto_subfamilia produto_subfamilia = new produto_subfamilia();

        public Util.Acao Acao { get; set; }
        public long id_subfamilia { get; set; }

        public cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia fProdutoFamilia
        {
            set { _fProdutoFamilia = value; }
        }

        public frmProdutoSubFamilia()
        {
            InitializeComponent();
        }

        private void frmProdutoFamilia_Load(object sender, EventArgs e)
        {
            if (this.Acao == Util.Acao.Cadastrar)
                this.TelaModoCadastrarNovo();
            else if (this.Acao == Util.Acao.Editar)
                this.TelaModoEditar();
            else if (this.Acao == Util.Acao.Visualizar)
                this.TelaModoVisualizar();
        }

        #region Modo de Tela
        private void TelaModoCadastrarNovo()
        {
            this.produto_subfamilia = new produto_subfamilia();
            this.Text = "Sub-Familia de Produto - Cadastrar novo sub-familia de produto";

            this.Acao = Util.Acao.Cadastrar;
            LimparCampos(this.Controls);
            DestravaFormControles(this.Controls);
            txtCodigo.Enabled = false;
            txtFamilia.ReadOnly = true;

            btNovo.Enabled = false;
            btEditar.Enabled = false;
            btExcluir.Enabled = false;
            btGravar.Enabled = true;
            btCancelar.Enabled = false;
            btFechar.Enabled = true;

            btFamilia.Enabled = true;
        }
        private void TelaModoEditar()
        {
            this.Text = "Sub-Familia de Produto - Editar cadastro de sub-familia de produto";
            this.Acao = Util.Acao.Editar;

            DestravaFormControles(this.Controls);
            txtCodigo.Enabled = false;
            txtFamilia.ReadOnly = true;

            btNovo.Enabled = false;
            btEditar.Enabled = false;
            btExcluir.Enabled = false;
            btGravar.Enabled = true;
            btCancelar.Enabled = true;
            btFechar.Enabled = true;

            btFamilia.Enabled = true;
        }
        private void TelaModoVisualizar()
        {
            this.produto_subfamilia = cProdutoSubFamilia.GetSubFamiliaByID(id_subfamilia);

            if (this.produto_subfamilia == null)
            {
                MessageBox.Show(null, "Este cadastro não existe!", "Cadastro de sub-familia de produto.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.TelaModoCadastrarNovo();
                return;
            }
            this.Text = "Sub-Familia de Produto - Visualizar cadastro de sub-familia de produto";
            this.Acao = Util.Acao.Visualizar;
            PreencherCampos();

            btNovo.Enabled = true;
            btEditar.Enabled = true;
            btExcluir.Enabled = true;
            btGravar.Enabled = false;
            btCancelar.Enabled = false;
            btFechar.Enabled = true;
            
            btFamilia.Enabled = false;

            TravaFormControles(this.Controls);
        }
        #endregion

        #region Menu Ação
        private void btFechar_Click(object sender, EventArgs e)
        {
            if (_fProdutoFamilia != null)
                _fProdutoFamilia.PreencherGridSubFamilia();

            this.Close();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            if (this.Acao == Util.Acao.Editar)
                this.TelaModoVisualizar();
        }

        private void btGravar_Click(object sender, EventArgs e)
        {

            ValidForm();
            if (FormIsValid)
                PreencherFamilia();
            
            if (this.Acao == Util.Acao.Cadastrar)
            {
                if (FormIsValid)
                {
                    if (cProdutoSubFamilia.SubFamiliaCadastrar(ref produto_subfamilia))
                    {
                        this.id_subfamilia = produto_subfamilia.id_produto_subfamilia;
                        TelaModoVisualizar();
                    }
                    else
                    {
                        MessageBox.Show(null, "Não foi possivel cadastrar o sub-familia de produto!", "Erro ao cadastrar sub-familia de produto.", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }

            if (this.Acao == Util.Acao.Editar)
            {
                if (FormIsValid)
                    if (cProdutoSubFamilia.SubFamiliaEditar(ref produto_subfamilia))
                        TelaModoVisualizar();
                    else
                        MessageBox.Show(null, "Não foi possivel editar o sub-familia de produto!", "Erro ao cadastrar sub-familia de produto.", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(null, "Tem certeza que deseja excluir \n o Sub-Familia de Produto: " + produto_subfamilia.subfamilia + "!", "Cadastro de Sub-Familia de Produto.", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                produto_subfamilia.excluido = true;
                if (cProdutoSubFamilia.SubFamiliaEditar(ref produto_subfamilia))
                    TelaModoCadastrarNovo();
            }
        }

        private void btEditar_Click(object sender, EventArgs e)
        {
            DestravaFormControles(this.Controls);
            txtCodigo.ReadOnly = true;
            txtFamilia.ReadOnly = true;
            TelaModoEditar();
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            LimparCampos(this.Controls);
            DestravaFormControles(this.Controls);
            txtCodigo.ReadOnly = true;
            txtFamilia.ReadOnly = true;
            TelaModoCadastrarNovo();
        }

        private void PreencherFamilia()
        {
            produto_subfamilia.subfamilia = txtSubFamilia.Text;
            produto_subfamilia.id_produto_familia = ((produto_familia)txtFamilia.Tag).id_produto_familia;
        }
        private void PreencherCampos()
        {
            txtCodigo.Text = this.produto_subfamilia.id_produto_subfamilia.ToString();
            txtSubFamilia.Text = this.produto_subfamilia.subfamilia;
            txtFamilia.Tag = this.produto_subfamilia.produto_familia;
            txtFamilia.Text = this.produto_subfamilia.produto_familia.id_produto_familia + " - " + this.produto_subfamilia.produto_familia.familia;

        }
        #endregion

        #region Validação de Formulario
        private void ValidForm()
        {
            this.FormIsValid = true;
            bool erro = false;

            if (txtFamilia.Tag == null)
            {
                erro = true;
                txtFamilia.BackColor = CorCampoInvalido;
                this.ValidarForm.SetToolTip(this.txtFamilia, "Campo familia de produto é obrigatório.");
            }
            else
                txtFamilia.BackColor = DefaultBackColor;

            if (string.IsNullOrEmpty(txtSubFamilia.Text))
            {
                erro = true;
                txtSubFamilia.BackColor = CorCampoInvalido;
                this.ValidarForm.SetToolTip(this.txtFamilia, "Campo sub-familia de produto é obrigatório.");
            }
            else
                txtSubFamilia.BackColor = DefaultBackColor;

            if (erro)
                this.FormIsValid = false;
        }
        #endregion
        
        private void btFamilia_Click(object sender, EventArgs e)
        {
            cms.Modulos.Produto.Forms.Familia.frmProdutoFamiliaLockup fProdutoFamiliaLockup = new cms.Modulos.Produto.Forms.Familia.frmProdutoFamiliaLockup();

            if (fProdutoFamiliaLockup.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var familia = fProdutoFamiliaLockup.GetFamiliaSelecionado();

                txtFamilia.Tag = familia;
                txtFamilia.Text = familia.id_produto_familia + " - " + familia.familia;

                fProdutoFamiliaLockup.Close();
                fProdutoFamiliaLockup.Dispose();
            }
            else
            {
                txtFamilia.Tag = null;
                txtFamilia.Text = string.Empty;
            }
        }
        private void txtFamilia_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F1)
            {
                btFamilia_Click(sender, e);
            }
        }

    }
}
