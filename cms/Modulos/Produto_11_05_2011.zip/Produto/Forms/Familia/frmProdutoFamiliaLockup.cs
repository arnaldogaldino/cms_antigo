﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using cms.Data;

namespace cms.Modulos.Produto.Forms.Familia
{
    public partial class frmProdutoFamiliaLockup : cms.Modulos.Util.WindowBase
    {
        cms.Modulos.Produto.Cn.cnFamilia cFamilia = new cms.Modulos.Produto.Cn.cnFamilia();

        produto_familia produto_familia = new produto_familia();

        IQueryable<produto_familia> familias;
        Thread threadPreencherGrid;
        cms.Modulos.Util.Carregando load = new cms.Modulos.Util.Carregando();
        
        public frmProdutoFamiliaLockup()
        {
            InitializeComponent();
        }
        
        private void btFechar_Click(object sender, EventArgs e)
        {
            this.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.Close();
        }

        private void btPesquisar_Click(object sender, EventArgs e)
        {
            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }

            load.btCancelar.Click += new EventHandler(btCancelar_Click);
            load.LoadShow(this);

            threadPreencherGrid = new Thread(AtualizarGvProdutoFamilia);
            threadPreencherGrid.IsBackground = true;
            threadPreencherGrid.Start();
        }

        void btCancelar_Click(object sender, EventArgs e)
        {
            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }
        }

        private void gvProdutoFamilia_DoubleClick(object sender, EventArgs e)
        {
            SelecionarFamilia();
        }
        
        private void AtualizarGvProdutoFamilia()
        {
            long? id_familia = null;
            string familia = string.Empty;

            if (txtCodigo.InvokeRequired)
                if (!string.IsNullOrEmpty(txtCodigo.Text))
                    id_familia = long.Parse(txtCodigo.Text);

            if (txtFamilia.InvokeRequired)
                if (!string.IsNullOrEmpty(txtFamilia.Text))
                    familia = txtFamilia.Text;

            try
            {
                familias = cFamilia.FamiliaProcurar(id_familia, familia);
            }
            catch { }

            if (gvProdutoFamilia.InvokeRequired)
                gvProdutoFamilia.Invoke(new MethodInvoker(Preencher));

        }

        public void Preencher()
        {
            gvProdutoFamilia.AutoGenerateColumns = false;
            gvProdutoFamilia.DataSource = familias;
            gvProdutoFamilia.Refresh();

            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            SelecionarFamilia();
        }
        
        private void SelecionarFamilia()
        {
            if (gvProdutoFamilia.CurrentRow == null)
                return;

            produto_familia = (produto_familia)gvProdutoFamilia.CurrentRow.DataBoundItem;
            this.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.Hide();
        }

        public produto_familia GetFamiliaSelecionado()
        {
            return produto_familia;
        }
    }
}
