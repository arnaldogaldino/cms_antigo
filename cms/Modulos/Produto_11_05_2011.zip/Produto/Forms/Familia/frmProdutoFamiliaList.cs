﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Linq;
using cms.Data;

namespace cms.Modulos.Produto.Forms.Familia
{
    public partial class frmProdutoFamiliaList : cms.Modulos.Util.WindowBase
    {

        cms.Modulos.Produto.Cn.cnFamilia cFamilia = new cms.Modulos.Produto.Cn.cnFamilia();

        IQueryable<produto_familia> familias;
        Thread threadPreencherGrid;
        cms.Modulos.Util.Carregando load = new cms.Modulos.Util.Carregando();

        public frmProdutoFamiliaList()
        {
            InitializeComponent();
        }

        private void btFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia fProdutoFamilia = new cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia();

            fProdutoFamilia.Acao = Util.Acao.Cadastrar;

            if (((WeifenLuo.WinFormsUI.Docking.DockPanel)this.Tag).DocumentStyle == WeifenLuo.WinFormsUI.Docking.DocumentStyle.SystemMdi)
            {
                fProdutoFamilia.MdiParent = this;
                fProdutoFamilia.Show();
            }
            else
                fProdutoFamilia.Show(((WeifenLuo.WinFormsUI.Docking.DockPanel)this.Tag));
        }

        public void btPesquisar_Click(object sender, EventArgs e)
        {
            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }

            load.btCancelar.Click += new EventHandler(btCancelar_Click);
            load.LoadShow(this);

            threadPreencherGrid = new Thread(AtualizarGvFinanceiroNcm);
            threadPreencherGrid.IsBackground = true;
            threadPreencherGrid.Start();
        }

        void btCancelar_Click(object sender, EventArgs e)
        {
            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }
        }
        
        private void gvProdutoFamilia_DoubleClick(object sender, EventArgs e)
        {
            if (gvProdutoFamilia.CurrentRow == null)
                return;

            produto_familia produto_familia = (produto_familia)gvProdutoFamilia.CurrentRow.DataBoundItem;

            cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia fProdutoFamilia = new cms.Modulos.Produto.Forms.Familia.frmProdutoFamilia();

            fProdutoFamilia.id_familia = produto_familia.id_produto_familia;
            fProdutoFamilia.Acao = Util.Acao.Visualizar;
            fProdutoFamilia.Tag = this.Tag;

            if (((WeifenLuo.WinFormsUI.Docking.DockPanel)this.Tag).DocumentStyle == WeifenLuo.WinFormsUI.Docking.DocumentStyle.SystemMdi)
            {
                fProdutoFamilia.MdiParent = this;
                fProdutoFamilia.Show();
            }
            else
                fProdutoFamilia.Show(((WeifenLuo.WinFormsUI.Docking.DockPanel)this.Tag));
        }

        private void AtualizarGvFinanceiroNcm()
        {
            long? id_familia = null;
            string familia = string.Empty;

            if (txtCodigo.InvokeRequired)
                if (!string.IsNullOrEmpty(txtCodigo.Text))
                    id_familia = long.Parse(txtCodigo.Text);

            if (txtFamilia.InvokeRequired)
                if (!string.IsNullOrEmpty(txtFamilia.Text))
                    familia = txtFamilia.Text;

            try
            {
                familias = cFamilia.FamiliaProcurar(id_familia, familia);
            }
            catch { }

            if (gvProdutoFamilia.InvokeRequired)
                gvProdutoFamilia.Invoke(new MethodInvoker(Preencher));

        }
        
        public void Preencher()
        {
            gvProdutoFamilia.AutoGenerateColumns = false;
            gvProdutoFamilia.DataSource = familias;
            gvProdutoFamilia.Refresh();

            if (threadPreencherGrid != null)
            {
                threadPreencherGrid.Abort();
                threadPreencherGrid = null;
                load.LoadHide(this);
            }
        }

    }
}
