﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expressions;
using cms.Modulos.Util;
using cms.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnSubGrupo
    {

        private cmsEntities dbEntities = new cmsEntities();

        public cnSubGrupo()
        { }
        
        #region SubGrupo

        public IQueryable<vw_produto_subgrupo> SubGrupoProcurar(long? id_subgrupo, long? id_grupo, string subgrupo)
        {
            var predicate = PredicateBuilder.True<vw_produto_subgrupo>();

            if (id_subgrupo != null)
                predicate = predicate.And(e => e.id_produto_subgrupo == id_subgrupo);

            if (id_grupo != null)
                predicate = predicate.And(e => e.id_produto_grupo == id_grupo);
            
            if (!string.IsNullOrEmpty(subgrupo))
                predicate = predicate.And(e => e.subgrupo.Contains(subgrupo));

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.vw_produto_subgrupo);

            return dbEntities.vw_produto_subgrupo.OrderBy(e => e.grupo).ThenBy(e => e.subgrupo).Where(predicate);
        }

        public produto_subgrupo GetSubGrupoByID(long id_subgrupo)
        {
            produto_subgrupo IResult = new produto_subgrupo();

            var predicate = PredicateBuilder.True<produto_subgrupo>();

            predicate = predicate.And(e => e.id_produto_subgrupo == id_subgrupo);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_subgrupo);

            try
            {
                IResult = dbEntities.produto_subgrupo.Where(predicate).SingleOrDefault();
            }
            catch { }

            return IResult;
        }

        public bool SubGrupoCadastrar(ref produto_subgrupo subgrupo)
        {
            try
            {
                subgrupo.id_produto_subgrupo = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_subgrupo);
                dbEntities.AddToproduto_subgrupo(subgrupo);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool SubGrupoEditar(ref produto_subgrupo subgrupo)
        {
            try
            {
                dbEntities.produto_subgrupo.ApplyCurrentValues(subgrupo);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

    }
}
