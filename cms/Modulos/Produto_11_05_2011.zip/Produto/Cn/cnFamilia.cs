﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expressions;
using cms.Modulos.Util;
using cms.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnFamilia
    {
        private cmsEntities dbEntities = new cmsEntities();

        public cnFamilia()
        { }
        
        #region Familia

        public IQueryable<produto_familia> FamiliaProcurar(long? id_familia, string familia)
        {
            var predicate = PredicateBuilder.True<produto_familia>();

            if (id_familia != null)
                predicate = predicate.And(e => e.id_produto_familia == id_familia);

            if (!string.IsNullOrEmpty(familia))
                predicate = predicate.And(e => e.familia.Contains(familia));

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_familia);

            return dbEntities.produto_familia.Where(predicate);
        }

        public produto_familia GetFamiliaByID(long id_familia)
        {
            produto_familia IResult = new produto_familia();

            var predicate = PredicateBuilder.True<produto_familia>();

            predicate = predicate.And(e => e.id_produto_familia == id_familia);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_familia);
            try
            {
                IResult = ((IQueryable<produto_familia>)dbEntities.produto_familia.Where(predicate)).SingleOrDefault();
            }
            catch { }

            return IResult;
        }

        public bool FamiliaCadastrar(ref produto_familia familia)
        {
            try
            {
                familia.id_produto_familia = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_familia);
                dbEntities.AddToproduto_familia(familia);
                dbEntities.SaveChanges();

            }
            catch { return false; }

            return true;
        }

        public bool FamiliaEditar(ref produto_familia familia)
        {
            try
            {
                dbEntities.produto_familia.ApplyCurrentValues(familia);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

    }
}
