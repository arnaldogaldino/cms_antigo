﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expressions;
using cms.Modulos.Util;
using cms.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnSubFamilia
    {

        private cmsEntities dbEntities = new cmsEntities();

        public cnSubFamilia()
        { }
        
        #region SubFamilia

        public IQueryable<vw_produto_subfamilia> SubFamiliaProcurar(long? id_subfamilia, long? id_familia, string subfamilia)
        {
            var predicate = PredicateBuilder.True<vw_produto_subfamilia>();

            if (id_subfamilia != null)
                predicate = predicate.And(e => e.id_produto_subfamilia == id_subfamilia);

            if (id_familia != null)
                predicate = predicate.And(e => e.id_produto_familia == id_familia);
            
            if (!string.IsNullOrEmpty(subfamilia))
                predicate = predicate.And(e => e.subfamilia.Contains(subfamilia));

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.vw_produto_subfamilia);
            return dbEntities.vw_produto_subfamilia.OrderBy(e => e.familia).ThenBy(e => e.subfamilia).Where(predicate); ;
        }

        public produto_subfamilia GetSubFamiliaByID(long id_subfamilia)
        {
            produto_subfamilia IResult = new produto_subfamilia();

            var predicate = PredicateBuilder.True<produto_subfamilia>();

            predicate = predicate.And(e => e.id_produto_subfamilia == id_subfamilia);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_subfamilia);
            try
            {
                IResult = ((IQueryable<produto_subfamilia>)dbEntities.produto_subfamilia.Where(predicate)).SingleOrDefault();
            }
            catch { }

            return IResult;
        }

        public bool SubFamiliaCadastrar(ref produto_subfamilia subfamilia)
        {
            try
            {
                subfamilia.id_produto_subfamilia = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_subfamilia);
                subfamilia.excluido = false;
                dbEntities.AddToproduto_subfamilia(subfamilia);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool SubFamiliaEditar(ref produto_subfamilia subfamilia)
        {
            try
            {
                dbEntities.produto_subfamilia.ApplyCurrentValues(subfamilia);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

    }
}
