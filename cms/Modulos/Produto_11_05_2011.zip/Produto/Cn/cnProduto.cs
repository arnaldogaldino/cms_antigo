﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using cms.Modulos.Util;
using Expressions;
using cms.Data;
using System.Data.EntityClient;
using System.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnProduto
    {

        private cmsEntities dbEntities = new cmsEntities();

        public cnProduto()
        { }

        #region Produto
        public produto GetProdutoByID(long id_produto)
        {
            var predicate = PredicateBuilder.True<produto>();

            predicate = predicate.And(e => e.id_produto == id_produto);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto);
            return dbEntities.produto.Where(predicate).SingleOrDefault();
        }
        public bool ProdutoCadastrar(ref produto pProduto)
        {
            try
            {
                pProduto.id_produto = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto);
                dbEntities.AddToproduto(pProduto);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true; 
        }
        public bool ProdutoEditar(ref produto pProduto)
        {
            try
            {
                EntityKey key = dbEntities.CreateEntityKey("produto", pProduto);
                object originalItem;

                if (dbEntities.TryGetObjectByKey(key, out originalItem))
                {
                    dbEntities.ApplyCurrentValues(key.EntitySetName, pProduto);
                }
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion
        
        #region Embalagem
        public IQueryable<produto_embalagem> ProdutoEmbalagembyIDProduto(long id_produto)
        {
            var predicate = PredicateBuilder.True<produto_embalagem>();

            predicate = predicate.And(e => e.excluido == false);
            predicate = predicate.And(e => e.id_produto == id_produto);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_embalagem);
            return dbEntities.produto_embalagem.Where(predicate).OrderBy(o => o.data_cadastro);
        }
        public bool ProdutoEmbalagemCadastrar(produto_embalagem embalagem)
        {
            try
            {
                embalagem.id_produto_embalagem = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_embalagem);
                dbEntities.AddToproduto_embalagem(embalagem);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        public bool ProdutoEmbalagemEditar(ref produto_embalagem embalagem)
        {
            try
            {
                EntityKey key = dbEntities.CreateEntityKey("produto_embalagem", embalagem);
                object originalItem;

                if (dbEntities.TryGetObjectByKey(key, out originalItem))
                {
                    dbEntities.ApplyCurrentValues(key.EntitySetName, embalagem);
                }
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

        #region Preços
        public IQueryable<produto_preco> ProdutoPrecobyIDProduto(long id_produto)
        {
            var predicate = PredicateBuilder.True<produto_preco>();

            predicate = predicate.And(e => e.excluido == false);
            predicate = predicate.And(e => e.id_produto == id_produto);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_preco);
            return dbEntities.produto_preco.Where(predicate).OrderBy(o => o.id_produto_preco);
        }
        public bool ProdutoPrecoCadastrar(produto_preco preco)
        {
            try
            {
                preco.id_produto_preco = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_preco);
                dbEntities.AddToproduto_preco(preco);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        public bool ProdutoPrecoEditar(ref produto_preco preco)
        {
            try
            {
                EntityKey key = dbEntities.CreateEntityKey("produto_preco", preco);
                object originalItem;

                if (dbEntities.TryGetObjectByKey(key, out originalItem))
                {
                    dbEntities.ApplyCurrentValues(key.EntitySetName, preco);
                }
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

        #region Foto
        public IQueryable<produto_foto> ProdutoFotobyIDProduto(long id_produto)
        {
            var predicate = PredicateBuilder.True<produto_foto>();

            predicate = predicate.And(e => e.excluido == false);
            predicate = predicate.And(e => e.id_produto == id_produto);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_preco);
            return dbEntities.produto_foto.Where(predicate).OrderBy(o => o.ordem);
        }
        public bool ProdutoFotoCadastrar(produto_foto foto)
        {
            try
            {
                foto.id_produto_foto = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_preco);
                dbEntities.AddToproduto_foto(foto);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        public bool ProdutoFotoEditar(ref produto_foto foto)
        {
            try
            {
                EntityKey key = dbEntities.CreateEntityKey("produto_foto", foto);
                object originalItem;

                if (dbEntities.TryGetObjectByKey(key, out originalItem))
                {
                    dbEntities.ApplyCurrentValues(key.EntitySetName, foto);
                }
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion
    }
}
