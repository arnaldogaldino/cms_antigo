﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expressions;
using cms.Modulos.Util;
using cms.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnPrecoTabela
    {
        private cmsEntities dbEntities = new cmsEntities();

        public cnPrecoTabela()
        { }
        
        #region PrecoTabela

        public IQueryable<produto_preco_tabela> PrecoTabelaProcurar(long? id_preco_tabela, string preco_tabela)
        {
            var predicate = PredicateBuilder.True<produto_preco_tabela>();

            if (id_preco_tabela != null)
                predicate = predicate.And(e => e.id_produto_preco_tabela == id_preco_tabela);

            if (!string.IsNullOrEmpty(preco_tabela))
                predicate = predicate.And(e => e.preco_tabela.Contains(preco_tabela));

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_preco_tabela);

            return dbEntities.produto_preco_tabela.Where(predicate);
        }

        public produto_preco_tabela GetPrecoTabelaByID(long id_preco_tabela)
        {
            produto_preco_tabela IResult = new produto_preco_tabela();

            var predicate = PredicateBuilder.True<produto_preco_tabela>();

            predicate = predicate.And(e => e.id_produto_preco_tabela == id_preco_tabela);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_preco_tabela);
            try
            {
                IResult = ((IQueryable<produto_preco_tabela>)dbEntities.produto_preco_tabela.Where(predicate)).SingleOrDefault();
            }
            catch { }

            return IResult;
        }

        public bool PrecoTabelaCadastrar(ref produto_preco_tabela preco_tabela)
        {
            try
            {
                preco_tabela.id_produto_preco_tabela = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_preco_tabela);
                preco_tabela.data_cadastro = cms.Modulos.Util.Util.sp_getdatetime();
                preco_tabela.excluido = false;
                dbEntities.AddToproduto_preco_tabela(preco_tabela);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool PrecoTabelaEditar(ref produto_preco_tabela preco_tabela)
        {
            try
            {
                dbEntities.produto_preco_tabela.ApplyCurrentValues(preco_tabela);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

    }
}
