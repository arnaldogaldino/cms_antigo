﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expressions;
using cms.Modulos.Util;
using cms.Data;

namespace cms.Modulos.Produto.Cn
{
    public class cnGrupo
    {
        private cmsEntities dbEntities = new cmsEntities();

        public cnGrupo()
        { }
        
        #region Grupo

        public IQueryable<produto_grupo> GrupoProcurar(long? id_grupo, string grupo)
        {
            var predicate = PredicateBuilder.True<produto_grupo>();

            if (id_grupo != null)
                predicate = predicate.And(e => e.id_produto_grupo == id_grupo);

            if (!string.IsNullOrEmpty(grupo))
                predicate = predicate.And(e => e.grupo.Contains(grupo));

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_grupo);

            return dbEntities.produto_grupo.Where(predicate);
        }

        public produto_grupo GetGrupoByID(long id_grupo)
        {
            produto_grupo IResult = new produto_grupo();

            var predicate = PredicateBuilder.True<produto_grupo>();

            predicate = predicate.And(e => e.id_produto_grupo == id_grupo);

            predicate = predicate.And(e => e.excluido == false);

            dbEntities.Refresh(System.Data.Objects.RefreshMode.ClientWins, dbEntities.produto_grupo);
            try
            {
                IResult = ((IQueryable<produto_grupo>)dbEntities.produto_grupo.Where(predicate)).SingleOrDefault();
            }
            catch { }

            return IResult;
        }

        public bool GrupoCadastrar(ref produto_grupo grupo)
        {
            try
            {
                grupo.id_produto_grupo = cms.Modulos.Util.Util.sp_getcodigo(Referencia.produto_grupo);
                dbEntities.AddToproduto_grupo(grupo);
                dbEntities.SaveChanges();

            }
            catch { return false; }

            return true;
        }

        public bool GrupoEditar(ref produto_grupo grupo)
        {
            try
            {
                dbEntities.produto_grupo.ApplyCurrentValues(grupo);
                dbEntities.SaveChanges();
            }
            catch { return false; }

            return true;
        }
        #endregion

    }
}
