using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using System.Threading;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MenuImpressoraDual_Principal : Form
    {
        public FR_MenuImpressoraDual_Principal()
        {
            InitializeComponent();
        }

        private void FR_MenuImpressoraDual_Principal_Load(object sender, EventArgs e)
        {

            

        }

        private void MN_FecharDual_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MN_Exemplo4_Click(object sender, EventArgs e)
        {

            FR_DUAL_menuExemplo4_comForumulario FormPrincipal = new FR_DUAL_menuExemplo4_comForumulario();
            FormPrincipal.Show();

        }

        private void MN_iAutenticarDocumento_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {

            FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework FormPrincipal = new FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework();
            FormPrincipal.Show();
            
        }

        private void MN_iImprimirTexto_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {

            FR_metodo_iImprimirTexto_DUAL_DarumaFramework FormPrincipal = new FR_metodo_iImprimirTexto_DUAL_DarumaFramework();
            FormPrincipal.Show();

        }

        private void MN_Testes_LoopingStatus_Click(object sender, EventArgs e)
        {

            FR_DUAL_menuTestes_LoopingStatus FormPrincipal = new FR_DUAL_menuTestes_LoopingStatus();
            FormPrincipal.Show();

        }

        private void MN_Testes_LoopingDoc_Click(object sender, EventArgs e)
        {

            FR_DUAL_menuTestes_LoopingStatusDocumento FormPrincipal = new FR_DUAL_menuTestes_LoopingStatusDocumento();
            FormPrincipal.Show();

        }

        private void MN_regAguardar_Habilitar_Click(object sender, EventArgs e)
        {
            MN_regAguardar_Habilitar.Checked = false;
            MN_regAguardar_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regAguardarProcesso_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regAguardar_Habilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regAguardar_Desabilitar_Click(object sender, EventArgs e)
        {
            MN_regAguardar_Habilitar.Checked = false;
            MN_regAguardar_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regAguardarProcesso_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regAguardar_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regEnterFinal_Habilitar_Click(object sender, EventArgs e)
        {
            MN_regEnterFinal_Habilitar.Checked = false;
            MN_regEnterFinal_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regEnterFinal_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regEnterFinal_Habilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regEnterFinal_Desabilitar_Click(object sender, EventArgs e)
        {
            MN_regEnterFinal_Habilitar.Checked = false;
            MN_regEnterFinal_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regEnterFinal_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regEnterFinal_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regLinhasGuilhotina_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("N�mero de linhas para habilitar a guilhotina (0 a 20):", "05");
            
            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regLinhasGuilhotina_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            } 
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regLinhasGuilhotina_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
    
        
        }

        private void MN_regGaveta_Padrao_Click(object sender, EventArgs e)
        {
            MN_regGaveta_Padrao.Checked = false;
            MN_regGaveta_AlteraPadrao.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regModoGaveta_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regGaveta_Padrao.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regGaveta_AlteraPadrao_Click(object sender, EventArgs e)
        {
            MN_regGaveta_Padrao.Checked = false;
            MN_regGaveta_AlteraPadrao.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regModoGaveta_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regGaveta_AlteraPadrao.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regPortaComunicacao_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita a Porta de Comunica��o:", "COM1");
            
            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regPortaComunicacao_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            } 
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regPortaComunicacao_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regTabulacao_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Entre com a tabula��o desejada ('05,10,15,20,25,35'):", "05");
            
            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regTabulacao_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            } 
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regTabulacao_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regTermica_Habilitar_Click(object sender, EventArgs e)
        {
            MN_regTermica_Habilitar.Checked = false;
            MN_regTermica_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regTermica_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regTermica_Habilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regTermica_Desabilitar_Click(object sender, EventArgs e)
        {
            MN_regTermica_Habilitar.Checked = false;
            MN_regTermica_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regTermica_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regTermica_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regVelocidade_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Selecione a velocidade de comunica��o com a impressora:", "9600");

            if (Declaracoes.iRetorno == 1 | STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" & STR_Retorno_CaixaInput == "1200" | STR_Retorno_CaixaInput == "2400" | STR_Retorno_CaixaInput == "300" | STR_Retorno_CaixaInput == "4800" | STR_Retorno_CaixaInput == "57600" | STR_Retorno_CaixaInput == "19200" | STR_Retorno_CaixaInput == "38400" | STR_Retorno_CaixaInput == "115200" | STR_Retorno_CaixaInput == "9600")
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regVelocidade_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            } 
                     
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regVelocidade_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_rStatusImpressora_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rStatusImpressora_DUAL_DarumaFramework();

            if (Declaracoes.iRetorno == 1 | Declaracoes.iRetorno == 0 | Declaracoes.iRetorno == -27 | Declaracoes.iRetorno == -50 | Declaracoes.iRetorno == 51 | Declaracoes.iRetorno == 52)
                switch (Declaracoes.iRetorno)
                {
                    case 0: MessageBox.Show("0(zero) - Impressora Desligada!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 1: MessageBox.Show("1(um) - Impressora OK!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case -50: MessageBox.Show("-50 - Impressora OFF-LINE!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case -51: MessageBox.Show("-51 - Impressora Sem Papel!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case -27: MessageBox.Show("-27 - Erro Generico!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case -52: MessageBox.Show("-52 - Impressora inicializando!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }

            else
            {
                MessageBox.Show("Retorno n�o esperado!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void MN_rStatusDocumento_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rStatusDocumento_DUAL_DarumaFramework();

            if (Declaracoes.iRetorno == 1 | Declaracoes.iRetorno == 0 | Declaracoes.iRetorno == -27)
                switch (Declaracoes.iRetorno)
                {
                    case 0: MessageBox.Show("0(zero) - Documento n�o posicionado, favor verificar!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 1: MessageBox.Show("1(um) - Documento posicionado", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                    case -27: MessageBox.Show("-27 - Erro Generico!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;      
                }

            else
            {
                MessageBox.Show("Retorno n�o esperado!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_rStatusGaveta_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {

            int iStatusGaveta;

            iStatusGaveta = 0;

            Declaracoes.iRetorno = Declaracoes.rStatusGaveta_DUAL_DarumaFramework(ref iStatusGaveta);
            
            if (Declaracoes.iRetorno == 1)
                switch (iStatusGaveta)
                {
                    case 0: MessageBox.Show("0(zero) - Gaveta Fechada", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    case 1: MessageBox.Show("1(um) - Gaveta Aberta", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;
                }

            else
            {
                MessageBox.Show("Retorno n�o esperado!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_iAcionarGaveta_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            
            Declaracoes.iRetorno = Declaracoes.eAcionarGaveta_DUAL_DarumaFramework();
            
            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Gaveta aciona com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regTermica_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao acionar a Gaveta", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void MN_iImprimirArquivo_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Entre com o nome do arquivo a ser impresso:", "C:\\DarumaDLLFramework.txt");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                
                Declaracoes.iRetorno = Declaracoes.iImprimirArquivo_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            }    
            if (Declaracoes.iRetorno == 1)

            {
                Declaracoes.iRetorno = Declaracoes.iImprimirArquivo_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Impress�o realizada com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao imprimir o arquivo, ou a a��o foi cancelada", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_iEnviarBMP_DUAL_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;
            
            STR_Retorno_CaixaInput = Declaracoes.InputBox("Entre com o nome do logotipo a ser enviado:", "C:\\logo.bmp");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.iEnviarBMP_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.iEnviarBMP_DUAL_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("O envio do logotipo foi realizado com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao enviar o Logotipo, ou a a��o foi cancelada", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_Exemplo2_Click(object sender, EventArgs e)
        {
            //IMPRIMINDO A PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb><b>FRAB<tb>Ano<tb>Modelo<tb>Valor<tb>Cor</b>", 0);
            //IMPRIMINDO A SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>2000<tb>Corsa<tb>12.000<tb>Azul", 0);
            //IMPRIMINDO A TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Ford<tb>2005<tb>Fiesta<tb>14.000<tb>Verde", 0);
            //IMPRIMINDO A QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Fiat<tb>1998<tb>Uno Mille<tb>9.000<tb>Branco", 0);
            //IMPRIMINDO A QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>1997<tb>Vectra<tb>18.000<tb>Prata", 0);
            //IMPRIMINDO A SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>1999<tb>Tigra<tb>17.000<tb>Verde", 0);
            //IMPRIMINDO A SETIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Ford<tb>2001<tb>Versalhes<tb>5.000<tb>Vinho", 0);
            //IMPRIMINDO A OITAVA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>1998<tb>Corsa<tb>10.000<tb>Preto", 0);
            //IMPRIMINDO A NONA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Fiat<tb>1996<tb>Fiurino<tb>6.000<tb>Branca", 0);
            //IMPRIMINDO A DECIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>WV<tb>1979<tb>Fusca<tb>3.000<tb>Bordo", 0);
            //IMPRIMINDO A DECIMA PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>1996<tb>Vectra<tb>16.000<tb>Grafite", 0);
            //IMPRIMINDO A DECIMA SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Fiat<tb>1985<tb>Fiat147<tb>3.000<tb>Azul", 0);
            //IMPRIMINDO A DECIMA TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Hond<tb>2003<tb>Civic<tb>28.000<tb>Preto", 0);
            //IMPRIMINDO A DECIMA QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>Fiat<tb>1999<tb>Palio<tb>12.000<tb>Cinza", 0);
            //IMPRIMINDO A DECIMA QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>GM<tb>2003<tb>Celta<tb>17.000<tb>Branco<sl>7</sl>", 0);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro, na impress�o do Exemplo 2!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void MN_Exemplo3_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tc>#</tc>", 0);
            //IMPRIMINDO A PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<e><ce>ACADEMIA NEW SPORTS</ce></e>", 0);
            //IMPRIMINDO A SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb><i>Rua Nossa Senhora da Luz</i>, 350", 0);
            //IMPRIMINDO A TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb><i>Jardim Social   -   Curitiba   -  PR</i>", 0);
            //IMPRIMINDO A QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>CNPJ 04.888.968/0001-79<tb><e>234-5678<l></l></e>", 0);
            //IMPRIMINDO A QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tc>#</tc><l></l>", 0);
            //IMPRIMINDO A SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<i><dt></dt><i>", 0);
            //IMPRIMINDO A S�TIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ad>Recibo nr.258963</ad><l></l>", 0);
            //IMPRIMINDO A OITAVA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<c>Nome : </c><b>ELAINE MARIA</b><sp>5</sp>(545)<l></l> ", 0);
            //IMPRIMINDO A NONA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<c>Plano : </c><b>MUSCULA��O NOTURNO</b><sp>5</sp>(5)<l></l> ", 0);
            //IMPRIMINDO A DECIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><e>VALOR PAGO : 45,00</e></ce> ", 0);
            //IMPRIMINDO A DECIMA PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<c>Ref. ao per�odo de 03/04/2005 at� 03/05/2005</c><l></l>", 0);
            //IMPRIMINDO A DECIMA SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<c>Obs: MENSALIDADE</c><l></l>", 0);
            //IMPRIMINDO A DECIMA TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tc>_</tc><l></l>", 0);
            //IMPRIMINDO A DECIMA QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><e>WWW.ACADEMIANEW.COM.BR</e></ce>", 0);
            //IMPRIMINDO A DECIMA QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tc>_</tc><l></l>", 0);
            //IMPRIMINDO A DECIMA SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><e>SAUDE BELEZA E BEM ESTAR</e></ce>", 0);
            //IMPRIMINDO A DECIMA S�TIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sn></sn>", 0);
            //IMPRIMINDO A DECIMA OITAVA LINHA

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro, na impress�o do Exemplo 3!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void MN_Exemplo1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tc>~</tc><l></l>",0);
                //IMPRIMINDO A PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><e><b>CENTRO DE DAN�A FLASH</b></e></ce>" +
                //IMPRIMINDO A SEGUNDA LINHA
            "************************\x0d\x0a" +
                //IMPRIMINDO A TERCEIRA LINHA
            "Rua: <c>XV de Novembro N 785 Centro CTBA  SP BR\x0d\x0a" +
                //IMPRIMINDO A QUARTA LINHA
            "Fone: 234-5678  Fax:324-5678\x0d\x0a" +
                //IMPRIMINDO A QUINTA LINHA
            "Data: 13/12/2009 Hora: 13:45\x0d\x0a" +
                //IMPRIMINDO A SEXTA LINHA
            "Pedido:00069 Cliente:00013\x0d\x0a" +
                //IMPRIMINDO A S�TIMA LINHA
            "Atividades Escolhidas:Samba\x0d\x0a", 0);
                //IMPRIMINDO A OITAVA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("SAMBA-BOLERO-FORR�",0);
                    //IMPRIMINDO A NONA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<Valor: 55,00",0);
                //IMPRIMINDO A DECIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("Vencimento: 10-01-10",0);
                //IMPRIMINDO A DECIMA PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("o n�o pagamento implica no cancelamento da vaga", 0);
                //IMPRIMINDO A DECIMA SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("In�cio dia 01 de Fevereiro as 17:30hr",0);
                //IMPRIMINDO A DECIMA TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("Venha Dan�ar!!!", 0);
                    //IMPRIMINDO A DECIMA QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("Samba,Bolero,Soltinho,Forr�,Zouk",0);
                    //IMPRIMINDO A DECIMA QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("Obrigado.\x0d\x0a", 0);
            //IMPRIMINDO A DECIMA SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sl></sl><sn></sn>", 0);
            //IMPRIMINDO A DECIMA S�TIMA LINHA

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro, na impress�o do Exemplo 1!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void BT_fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar_Click(object sender, EventArgs e)
        {
            MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Checked = false;
            MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regCodePageAutomatico_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar_Click(object sender, EventArgs e)
        {
            MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Checked = false;
            MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regCodePageAutomatico_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regZeroCortado_DUAL_DarumaFramework_Habilitar_Click(object sender, EventArgs e)
        {
            MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Checked = false;
            MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regZeroCortado_DUAL_DarumaFramework("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar_Click(object sender, EventArgs e)
        {
            MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Checked = false;
            MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regZeroCortado_DUAL_DarumaFramework("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_eDefinirProduto_Daruma_Click(object sender, EventArgs e)
        {

            string sProduto;

            sProduto = "DUAL";

            Declaracoes.iRetorno = Declaracoes.eDefinirProduto_Daruma(sProduto);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso, produto DUAL", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void MN_regRetornaValorChave_DarumaFramework_Click(object sender, EventArgs e)
        {

            FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework DarumaRetorna = new FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework();
            DarumaRetorna.Show();

        }
    }
}