namespace DarumaFramework_CSharp
{
    partial class FR_MenuImpressoraDual_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PN_Dual = new System.Windows.Forms.Panel();
            this.LB_DLL = new System.Windows.Forms.Label();
            this.LB_Impressoras = new System.Windows.Forms.Label();
            this.PB_DDC = new System.Windows.Forms.PictureBox();
            this.MS_Geral_Dual = new System.Windows.Forms.MenuStrip();
            this.MN_MetodosDarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_eDefinirProduto_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_MRegistro = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regAguardarProcesso_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regAguardar_Habilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regAguardar_Desabilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regEnterFinal_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regEnterFinal_Habilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regEnterFinal_Desabilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regModoGaveta_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regGaveta_Padrao = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regGaveta_AlteraPadrao = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regPortaComunicacao_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regTabulacao_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regTermica_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regTermica_Habilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regTermica_Desabilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regVelocidade_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regZeroCortado_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Status = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_rStatusImpressora_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_rStatusDocumento_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_rStatusGaveta_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Testes = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Testes_LoopingStatus = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Testes_LoopingDoc = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_AutenticaImpressao = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_iImprimirTexto_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_iImprimirArquivo_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_iAcionarGaveta_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_iEnviarBMP_DUAL_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplos = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplo1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplo2 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplo3 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplo4 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_FecharDual = new System.Windows.Forms.ToolStripMenuItem();
            this.lb_duvidas = new System.Windows.Forms.Label();
            this.BT_fechar = new System.Windows.Forms.Button();
            this.MN_regRetornaValorChave_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.PN_Dual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).BeginInit();
            this.MS_Geral_Dual.SuspendLayout();
            this.SuspendLayout();
            // 
            // PN_Dual
            // 
            this.PN_Dual.BackColor = System.Drawing.Color.White;
            this.PN_Dual.Controls.Add(this.LB_DLL);
            this.PN_Dual.Controls.Add(this.LB_Impressoras);
            this.PN_Dual.Controls.Add(this.PB_DDC);
            this.PN_Dual.Location = new System.Drawing.Point(0, 321);
            this.PN_Dual.Name = "PN_Dual";
            this.PN_Dual.Size = new System.Drawing.Size(957, 114);
            this.PN_Dual.TabIndex = 0;
            // 
            // LB_DLL
            // 
            this.LB_DLL.AutoSize = true;
            this.LB_DLL.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DLL.Location = new System.Drawing.Point(12, 84);
            this.LB_DLL.Name = "LB_DLL";
            this.LB_DLL.Size = new System.Drawing.Size(204, 16);
            this.LB_DLL.TabIndex = 2;
            this.LB_DLL.Text = "DLL: DarumaFramework.dll";
            // 
            // LB_Impressoras
            // 
            this.LB_Impressoras.AutoSize = true;
            this.LB_Impressoras.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Impressoras.Location = new System.Drawing.Point(12, 19);
            this.LB_Impressoras.Name = "LB_Impressoras";
            this.LB_Impressoras.Size = new System.Drawing.Size(262, 23);
            this.LB_Impressoras.TabIndex = 1;
            this.LB_Impressoras.Text = "Impressoras N�o-Fiscal";
            // 
            // PB_DDC
            // 
            this.PB_DDC.Image = global::DarumaFramework_CSharp.Properties.Resources.logoDDCpeq2;
            this.PB_DDC.Location = new System.Drawing.Point(601, 19);
            this.PB_DDC.Name = "PB_DDC";
            this.PB_DDC.Size = new System.Drawing.Size(185, 81);
            this.PB_DDC.TabIndex = 0;
            this.PB_DDC.TabStop = false;
            // 
            // MS_Geral_Dual
            // 
            this.MS_Geral_Dual.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_MetodosDarumaFramework,
            this.MN_MRegistro,
            this.MN_Status,
            this.MN_AutenticaImpressao,
            this.MN_Exemplos,
            this.MN_FecharDual});
            this.MS_Geral_Dual.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.MS_Geral_Dual.Location = new System.Drawing.Point(0, 0);
            this.MS_Geral_Dual.Name = "MS_Geral_Dual";
            this.MS_Geral_Dual.Size = new System.Drawing.Size(798, 42);
            this.MS_Geral_Dual.TabIndex = 1;
            this.MS_Geral_Dual.Text = "menuStrip1";
            // 
            // MN_MetodosDarumaFramework
            // 
            this.MN_MetodosDarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_eDefinirProduto_Daruma,
            this.MN_regRetornaValorChave_DarumaFramework});
            this.MN_MetodosDarumaFramework.Name = "MN_MetodosDarumaFramework";
            this.MN_MetodosDarumaFramework.Size = new System.Drawing.Size(196, 19);
            this.MN_MetodosDarumaFramework.Text = "&M�todos para DarumaFramework";
            // 
            // MN_eDefinirProduto_Daruma
            // 
            this.MN_eDefinirProduto_Daruma.Name = "MN_eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Size = new System.Drawing.Size(343, 22);
            this.MN_eDefinirProduto_Daruma.Text = "M�todo eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Click += new System.EventHandler(this.MN_eDefinirProduto_Daruma_Click);
            // 
            // MN_MRegistro
            // 
            this.MN_MRegistro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regAguardarProcesso_DUAL_DarumaFramework,
            this.MN_regEnterFinal_DUAL_DarumaFramework,
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework,
            this.MN_regModoGaveta_DUAL_DarumaFramework,
            this.MN_regPortaComunicacao_DUAL_DarumaFramework,
            this.MN_regTabulacao_DUAL_DarumaFramework,
            this.MN_regTermica_DUAL_DarumaFramework,
            this.MN_regVelocidade_DUAL_DarumaFramework,
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework,
            this.MN_regZeroCortado_DUAL_DarumaFramework});
            this.MN_MRegistro.Name = "MN_MRegistro";
            this.MN_MRegistro.Size = new System.Drawing.Size(188, 19);
            this.MN_MRegistro.Text = "M�todos para &Registro(Registry)";
            // 
            // MN_regAguardarProcesso_DUAL_DarumaFramework
            // 
            this.MN_regAguardarProcesso_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regAguardar_Habilitar,
            this.MN_regAguardar_Desabilitar});
            this.MN_regAguardarProcesso_DUAL_DarumaFramework.Name = "MN_regAguardarProcesso_DUAL_DarumaFramework";
            this.MN_regAguardarProcesso_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regAguardarProcesso_DUAL_DarumaFramework.Text = "M�todo regAguardarProcesso_DUAL_DarumaFramework";
            // 
            // MN_regAguardar_Habilitar
            // 
            this.MN_regAguardar_Habilitar.Name = "MN_regAguardar_Habilitar";
            this.MN_regAguardar_Habilitar.Size = new System.Drawing.Size(152, 22);
            this.MN_regAguardar_Habilitar.Text = "1 - Habilitar";
            this.MN_regAguardar_Habilitar.Click += new System.EventHandler(this.MN_regAguardar_Habilitar_Click);
            // 
            // MN_regAguardar_Desabilitar
            // 
            this.MN_regAguardar_Desabilitar.Name = "MN_regAguardar_Desabilitar";
            this.MN_regAguardar_Desabilitar.Size = new System.Drawing.Size(152, 22);
            this.MN_regAguardar_Desabilitar.Text = "0 - Desabilitar";
            this.MN_regAguardar_Desabilitar.Click += new System.EventHandler(this.MN_regAguardar_Desabilitar_Click);
            // 
            // MN_regEnterFinal_DUAL_DarumaFramework
            // 
            this.MN_regEnterFinal_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regEnterFinal_Habilitar,
            this.MN_regEnterFinal_Desabilitar});
            this.MN_regEnterFinal_DUAL_DarumaFramework.Name = "MN_regEnterFinal_DUAL_DarumaFramework";
            this.MN_regEnterFinal_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regEnterFinal_DUAL_DarumaFramework.Text = "M�todo regEnterFinal_DUAL_DarumaFramework";
            // 
            // MN_regEnterFinal_Habilitar
            // 
            this.MN_regEnterFinal_Habilitar.Name = "MN_regEnterFinal_Habilitar";
            this.MN_regEnterFinal_Habilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regEnterFinal_Habilitar.Text = "1 - Habilitar";
            this.MN_regEnterFinal_Habilitar.Click += new System.EventHandler(this.MN_regEnterFinal_Habilitar_Click);
            // 
            // MN_regEnterFinal_Desabilitar
            // 
            this.MN_regEnterFinal_Desabilitar.Name = "MN_regEnterFinal_Desabilitar";
            this.MN_regEnterFinal_Desabilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regEnterFinal_Desabilitar.Text = "0 - Desabilitar";
            this.MN_regEnterFinal_Desabilitar.Click += new System.EventHandler(this.MN_regEnterFinal_Desabilitar_Click);
            // 
            // MN_regLinhasGuilhotina_DUAL_DarumaFramework
            // 
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework.Name = "MN_regLinhasGuilhotina_DUAL_DarumaFramework";
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework.Text = "M�todo regLinhasGuilhotina_DUAL_DarumaFramework";
            this.MN_regLinhasGuilhotina_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_regLinhasGuilhotina_DUAL_DarumaFramework_Click);
            // 
            // MN_regModoGaveta_DUAL_DarumaFramework
            // 
            this.MN_regModoGaveta_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regGaveta_Padrao,
            this.MN_regGaveta_AlteraPadrao});
            this.MN_regModoGaveta_DUAL_DarumaFramework.Name = "MN_regModoGaveta_DUAL_DarumaFramework";
            this.MN_regModoGaveta_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regModoGaveta_DUAL_DarumaFramework.Text = "M�todo regModoGaveta_DUAL_DarumaFramework";
            // 
            // MN_regGaveta_Padrao
            // 
            this.MN_regGaveta_Padrao.Name = "MN_regGaveta_Padrao";
            this.MN_regGaveta_Padrao.Size = new System.Drawing.Size(162, 22);
            this.MN_regGaveta_Padrao.Text = "0 - Padr�o";
            this.MN_regGaveta_Padrao.Click += new System.EventHandler(this.MN_regGaveta_Padrao_Click);
            // 
            // MN_regGaveta_AlteraPadrao
            // 
            this.MN_regGaveta_AlteraPadrao.Name = "MN_regGaveta_AlteraPadrao";
            this.MN_regGaveta_AlteraPadrao.Size = new System.Drawing.Size(162, 22);
            this.MN_regGaveta_AlteraPadrao.Text = "1 - Altera Padr�o";
            this.MN_regGaveta_AlteraPadrao.Click += new System.EventHandler(this.MN_regGaveta_AlteraPadrao_Click);
            // 
            // MN_regPortaComunicacao_DUAL_DarumaFramework
            // 
            this.MN_regPortaComunicacao_DUAL_DarumaFramework.Name = "MN_regPortaComunicacao_DUAL_DarumaFramework";
            this.MN_regPortaComunicacao_DUAL_DarumaFramework.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.MN_regPortaComunicacao_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regPortaComunicacao_DUAL_DarumaFramework.Text = "M�todo regPortaComunicacao_DUAL_DarumaFramework";
            this.MN_regPortaComunicacao_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_regPortaComunicacao_DUAL_DarumaFramework_Click);
            // 
            // MN_regTabulacao_DUAL_DarumaFramework
            // 
            this.MN_regTabulacao_DUAL_DarumaFramework.Name = "MN_regTabulacao_DUAL_DarumaFramework";
            this.MN_regTabulacao_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regTabulacao_DUAL_DarumaFramework.Text = "M�todo regTabulacao_DUAL_DarumaFramework";
            this.MN_regTabulacao_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_regTabulacao_DUAL_DarumaFramework_Click);
            // 
            // MN_regTermica_DUAL_DarumaFramework
            // 
            this.MN_regTermica_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regTermica_Habilitar,
            this.MN_regTermica_Desabilitar});
            this.MN_regTermica_DUAL_DarumaFramework.Name = "MN_regTermica_DUAL_DarumaFramework";
            this.MN_regTermica_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regTermica_DUAL_DarumaFramework.Text = "M�todo regTermica_DUAL_DarumaFramework";
            // 
            // MN_regTermica_Habilitar
            // 
            this.MN_regTermica_Habilitar.Name = "MN_regTermica_Habilitar";
            this.MN_regTermica_Habilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regTermica_Habilitar.Text = "1 - Habilitar";
            this.MN_regTermica_Habilitar.Click += new System.EventHandler(this.MN_regTermica_Habilitar_Click);
            // 
            // MN_regTermica_Desabilitar
            // 
            this.MN_regTermica_Desabilitar.Name = "MN_regTermica_Desabilitar";
            this.MN_regTermica_Desabilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regTermica_Desabilitar.Text = "0 - Desabilitar";
            this.MN_regTermica_Desabilitar.Click += new System.EventHandler(this.MN_regTermica_Desabilitar_Click);
            // 
            // MN_regVelocidade_DUAL_DarumaFramework
            // 
            this.MN_regVelocidade_DUAL_DarumaFramework.Name = "MN_regVelocidade_DUAL_DarumaFramework";
            this.MN_regVelocidade_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regVelocidade_DUAL_DarumaFramework.Text = "M�todo regVelocidade_DUAL_DarumaFramework";
            this.MN_regVelocidade_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_regVelocidade_DUAL_DarumaFramework_Click);
            // 
            // MN_regCodePageAutomatico_DUAL_DarumaFramework
            // 
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar,
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar});
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework.Name = "MN_regCodePageAutomatico_DUAL_DarumaFramework";
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework.Text = "M�todo regCodePageAutomatico_DUAL_DarumaFramework";
            // 
            // MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar
            // 
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Name = "MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar";
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Text = "1 - Habilitar";
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar.Click += new System.EventHandler(this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar_Click);
            // 
            // MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar
            // 
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Name = "MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar";
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Text = "0 - Desabilitar";
            this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar.Click += new System.EventHandler(this.MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar_Click);
            // 
            // MN_regZeroCortado_DUAL_DarumaFramework
            // 
            this.MN_regZeroCortado_DUAL_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar,
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar});
            this.MN_regZeroCortado_DUAL_DarumaFramework.Name = "MN_regZeroCortado_DUAL_DarumaFramework";
            this.MN_regZeroCortado_DUAL_DarumaFramework.Size = new System.Drawing.Size(420, 22);
            this.MN_regZeroCortado_DUAL_DarumaFramework.Text = "M�todo regZeroCortado_DUAL_DarumaFramework";
            // 
            // MN_regZeroCortado_DUAL_DarumaFramework_Habilitar
            // 
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Name = "MN_regZeroCortado_DUAL_DarumaFramework_Habilitar";
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Text = "1 - Habilitar";
            this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar.Click += new System.EventHandler(this.MN_regZeroCortado_DUAL_DarumaFramework_Habilitar_Click);
            // 
            // MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar
            // 
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Name = "MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar";
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Size = new System.Drawing.Size(146, 22);
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Text = "0 - Desabilitar";
            this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar.Click += new System.EventHandler(this.MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar_Click);
            // 
            // MN_Status
            // 
            this.MN_Status.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_rStatusImpressora_DUAL_DarumaFramework,
            this.MN_rStatusDocumento_DUAL_DarumaFramework,
            this.MN_rStatusGaveta_DUAL_DarumaFramework,
            this.MN_Testes});
            this.MN_Status.Name = "MN_Status";
            this.MN_Status.Size = new System.Drawing.Size(172, 19);
            this.MN_Status.Text = "M�todos para &Status e Testes";
            // 
            // MN_rStatusImpressora_DUAL_DarumaFramework
            // 
            this.MN_rStatusImpressora_DUAL_DarumaFramework.Name = "MN_rStatusImpressora_DUAL_DarumaFramework";
            this.MN_rStatusImpressora_DUAL_DarumaFramework.Size = new System.Drawing.Size(359, 22);
            this.MN_rStatusImpressora_DUAL_DarumaFramework.Text = "M�todo rStatusImpressora_DUAL_DarumaFramework";
            this.MN_rStatusImpressora_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_rStatusImpressora_DUAL_DarumaFramework_Click);
            // 
            // MN_rStatusDocumento_DUAL_DarumaFramework
            // 
            this.MN_rStatusDocumento_DUAL_DarumaFramework.Name = "MN_rStatusDocumento_DUAL_DarumaFramework";
            this.MN_rStatusDocumento_DUAL_DarumaFramework.Size = new System.Drawing.Size(359, 22);
            this.MN_rStatusDocumento_DUAL_DarumaFramework.Text = "M�todo rStatusDocumento_DUAL_DarumaFramework";
            this.MN_rStatusDocumento_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_rStatusDocumento_DUAL_DarumaFramework_Click);
            // 
            // MN_rStatusGaveta_DUAL_DarumaFramework
            // 
            this.MN_rStatusGaveta_DUAL_DarumaFramework.Name = "MN_rStatusGaveta_DUAL_DarumaFramework";
            this.MN_rStatusGaveta_DUAL_DarumaFramework.Size = new System.Drawing.Size(359, 22);
            this.MN_rStatusGaveta_DUAL_DarumaFramework.Text = "M�todo rStatusGaveta_DUAL_DarumaFramework";
            this.MN_rStatusGaveta_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_rStatusGaveta_DUAL_DarumaFramework_Click);
            // 
            // MN_Testes
            // 
            this.MN_Testes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_Testes_LoopingStatus,
            this.MN_Testes_LoopingDoc});
            this.MN_Testes.Name = "MN_Testes";
            this.MN_Testes.Size = new System.Drawing.Size(359, 22);
            this.MN_Testes.Text = "Menu para Testes";
            // 
            // MN_Testes_LoopingStatus
            // 
            this.MN_Testes_LoopingStatus.Name = "MN_Testes_LoopingStatus";
            this.MN_Testes_LoopingStatus.Size = new System.Drawing.Size(384, 22);
            this.MN_Testes_LoopingStatus.Text = "Teste para Looping de verifica��o de Status";
            this.MN_Testes_LoopingStatus.Click += new System.EventHandler(this.MN_Testes_LoopingStatus_Click);
            // 
            // MN_Testes_LoopingDoc
            // 
            this.MN_Testes_LoopingDoc.Name = "MN_Testes_LoopingDoc";
            this.MN_Testes_LoopingDoc.Size = new System.Drawing.Size(384, 22);
            this.MN_Testes_LoopingDoc.Text = "Teste para Looping de verifica��o de Status de Documento";
            this.MN_Testes_LoopingDoc.Click += new System.EventHandler(this.MN_Testes_LoopingDoc_Click);
            // 
            // MN_AutenticaImpressao
            // 
            this.MN_AutenticaImpressao.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_iImprimirTexto_DUAL_DarumaFramework,
            this.MN_iImprimirArquivo_DUAL_DarumaFramework,
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework,
            this.MN_iAcionarGaveta_DUAL_DarumaFramework,
            this.MN_iEnviarBMP_DUAL_DarumaFramework});
            this.MN_AutenticaImpressao.Name = "MN_AutenticaImpressao";
            this.MN_AutenticaImpressao.Size = new System.Drawing.Size(231, 19);
            this.MN_AutenticaImpressao.Text = "M�todos para &Autentica��o e Impress�o";
            // 
            // MN_iImprimirTexto_DUAL_DarumaFramework
            // 
            this.MN_iImprimirTexto_DUAL_DarumaFramework.Name = "MN_iImprimirTexto_DUAL_DarumaFramework";
            this.MN_iImprimirTexto_DUAL_DarumaFramework.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I)));
            this.MN_iImprimirTexto_DUAL_DarumaFramework.Size = new System.Drawing.Size(381, 22);
            this.MN_iImprimirTexto_DUAL_DarumaFramework.Text = "M�todo iImprimirTexto_DUAL_DarumaFramework";
            this.MN_iImprimirTexto_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_iImprimirTexto_DUAL_DarumaFramework_Click);
            // 
            // MN_iImprimirArquivo_DUAL_DarumaFramework
            // 
            this.MN_iImprimirArquivo_DUAL_DarumaFramework.Name = "MN_iImprimirArquivo_DUAL_DarumaFramework";
            this.MN_iImprimirArquivo_DUAL_DarumaFramework.Size = new System.Drawing.Size(381, 22);
            this.MN_iImprimirArquivo_DUAL_DarumaFramework.Text = "M�todo iImprimirArquivo_DUAL_DarumaFramework";
            this.MN_iImprimirArquivo_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_iImprimirArquivo_DUAL_DarumaFramework_Click);
            // 
            // MN_iAutenticarDocumento_DUAL_DarumaFramework
            // 
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework.Name = "MN_iAutenticarDocumento_DUAL_DarumaFramework";
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework.Size = new System.Drawing.Size(381, 22);
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework.Text = "M�todo iAutenticarDocumento_DUAL_DarumaFramework";
            this.MN_iAutenticarDocumento_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_iAutenticarDocumento_DUAL_DarumaFramework_Click);
            // 
            // MN_iAcionarGaveta_DUAL_DarumaFramework
            // 
            this.MN_iAcionarGaveta_DUAL_DarumaFramework.Name = "MN_iAcionarGaveta_DUAL_DarumaFramework";
            this.MN_iAcionarGaveta_DUAL_DarumaFramework.Size = new System.Drawing.Size(381, 22);
            this.MN_iAcionarGaveta_DUAL_DarumaFramework.Text = "M�todo iAcionarGaveta_DUAL_DarumaFramework";
            this.MN_iAcionarGaveta_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_iAcionarGaveta_DUAL_DarumaFramework_Click);
            // 
            // MN_iEnviarBMP_DUAL_DarumaFramework
            // 
            this.MN_iEnviarBMP_DUAL_DarumaFramework.Name = "MN_iEnviarBMP_DUAL_DarumaFramework";
            this.MN_iEnviarBMP_DUAL_DarumaFramework.Size = new System.Drawing.Size(381, 22);
            this.MN_iEnviarBMP_DUAL_DarumaFramework.Text = "M�todo iEnviarBMP_DUAL_DarumaFramework";
            this.MN_iEnviarBMP_DUAL_DarumaFramework.Click += new System.EventHandler(this.MN_iEnviarBMP_DUAL_DarumaFramework_Click);
            // 
            // MN_Exemplos
            // 
            this.MN_Exemplos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_Exemplo1,
            this.MN_Exemplo2,
            this.MN_Exemplo3,
            this.MN_Exemplo4});
            this.MN_Exemplos.Name = "MN_Exemplos";
            this.MN_Exemplos.Size = new System.Drawing.Size(69, 19);
            this.MN_Exemplos.Text = "E&xemplos";
            // 
            // MN_Exemplo1
            // 
            this.MN_Exemplo1.Name = "MN_Exemplo1";
            this.MN_Exemplo1.Size = new System.Drawing.Size(213, 22);
            this.MN_Exemplo1.Text = "Exemplo 1 (Buffer)";
            this.MN_Exemplo1.Click += new System.EventHandler(this.MN_Exemplo1_Click);
            // 
            // MN_Exemplo2
            // 
            this.MN_Exemplo2.Name = "MN_Exemplo2";
            this.MN_Exemplo2.Size = new System.Drawing.Size(213, 22);
            this.MN_Exemplo2.Text = "Exemplo 2 (Tabula��o)";
            this.MN_Exemplo2.Click += new System.EventHandler(this.MN_Exemplo2_Click);
            // 
            // MN_Exemplo3
            // 
            this.MN_Exemplo3.Name = "MN_Exemplo3";
            this.MN_Exemplo3.Size = new System.Drawing.Size(213, 22);
            this.MN_Exemplo3.Text = "Exemplo 3 (Linha-a-Linha)";
            this.MN_Exemplo3.Click += new System.EventHandler(this.MN_Exemplo3_Click);
            // 
            // MN_Exemplo4
            // 
            this.MN_Exemplo4.Name = "MN_Exemplo4";
            this.MN_Exemplo4.Size = new System.Drawing.Size(213, 22);
            this.MN_Exemplo4.Text = "Exemplo 4 (Formulario)";
            this.MN_Exemplo4.Click += new System.EventHandler(this.MN_Exemplo4_Click);
            // 
            // MN_FecharDual
            // 
            this.MN_FecharDual.Name = "MN_FecharDual";
            this.MN_FecharDual.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.MN_FecharDual.Size = new System.Drawing.Size(89, 19);
            this.MN_FecharDual.Text = "&Fechar Janela";
            this.MN_FecharDual.Click += new System.EventHandler(this.MN_FecharDual_Click);
            // 
            // lb_duvidas
            // 
            this.lb_duvidas.AutoSize = true;
            this.lb_duvidas.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_duvidas.Location = new System.Drawing.Point(13, 302);
            this.lb_duvidas.Name = "lb_duvidas";
            this.lb_duvidas.Size = new System.Drawing.Size(312, 16);
            this.lb_duvidas.TabIndex = 3;
            this.lb_duvidas.Text = "Duvidas? Ligue Gratuito! - 0800 770 33 20";
            // 
            // BT_fechar
            // 
            this.BT_fechar.Location = new System.Drawing.Point(711, 281);
            this.BT_fechar.Name = "BT_fechar";
            this.BT_fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_fechar.TabIndex = 4;
            this.BT_fechar.Text = "Fechar";
            this.BT_fechar.UseVisualStyleBackColor = true;
            this.BT_fechar.Click += new System.EventHandler(this.BT_fechar_Click);
            // 
            // MN_regRetornaValorChave_DarumaFramework
            // 
            this.MN_regRetornaValorChave_DarumaFramework.Name = "MN_regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Size = new System.Drawing.Size(343, 22);
            this.MN_regRetornaValorChave_DarumaFramework.Text = "M�todo regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Click += new System.EventHandler(this.MN_regRetornaValorChave_DarumaFramework_Click);
            // 
            // FR_MenuImpressoraDual_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 433);
            this.Controls.Add(this.BT_fechar);
            this.Controls.Add(this.lb_duvidas);
            this.Controls.Add(this.PN_Dual);
            this.Controls.Add(this.MS_Geral_Dual);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MenuImpressoraDual_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Daruma Framework - C#                                                            " +
                "                                                               Impressoras DUAL";
            this.Load += new System.EventHandler(this.FR_MenuImpressoraDual_Principal_Load);
            this.PN_Dual.ResumeLayout(false);
            this.PN_Dual.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).EndInit();
            this.MS_Geral_Dual.ResumeLayout(false);
            this.MS_Geral_Dual.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PN_Dual;
        private System.Windows.Forms.PictureBox PB_DDC;
        private System.Windows.Forms.Label LB_Impressoras;
        private System.Windows.Forms.Label LB_DLL;
        private System.Windows.Forms.MenuStrip MS_Geral_Dual;
        private System.Windows.Forms.ToolStripMenuItem MN_MRegistro;
        private System.Windows.Forms.ToolStripMenuItem MN_regAguardarProcesso_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regAguardar_Habilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regAguardar_Desabilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regEnterFinal_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regEnterFinal_Habilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regEnterFinal_Desabilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regLinhasGuilhotina_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regModoGaveta_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regGaveta_Padrao;
        private System.Windows.Forms.ToolStripMenuItem MN_regGaveta_AlteraPadrao;
        private System.Windows.Forms.ToolStripMenuItem MN_regPortaComunicacao_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regTabulacao_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regTermica_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regTermica_Habilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regTermica_Desabilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regVelocidade_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_Status;
        private System.Windows.Forms.ToolStripMenuItem MN_rStatusImpressora_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_rStatusDocumento_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_rStatusGaveta_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_Testes;
        private System.Windows.Forms.ToolStripMenuItem MN_Testes_LoopingStatus;
        private System.Windows.Forms.ToolStripMenuItem MN_Testes_LoopingDoc;
        private System.Windows.Forms.ToolStripMenuItem MN_AutenticaImpressao;
        private System.Windows.Forms.ToolStripMenuItem MN_iImprimirTexto_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_iAutenticarDocumento_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_iAcionarGaveta_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_iEnviarBMP_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplos;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplo1;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplo2;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplo3;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplo4;
        private System.Windows.Forms.ToolStripMenuItem MN_FecharDual;
        private System.Windows.Forms.ToolStripMenuItem MN_iImprimirArquivo_DUAL_DarumaFramework;
        private System.Windows.Forms.Label lb_duvidas;
        private System.Windows.Forms.Button BT_fechar;
        private System.Windows.Forms.ToolStripMenuItem MN_regCodePageAutomatico_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regCodePageAutomatico_DUAL_DarumaFramework_Habilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regCodePageAutomatico_DUAL_DarumaFramework_Desabilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regZeroCortado_DUAL_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regZeroCortado_DUAL_DarumaFramework_Habilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_regZeroCortado_DUAL_DarumaFramework_Desabilitar;
        private System.Windows.Forms.ToolStripMenuItem MN_MetodosDarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_eDefinirProduto_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regRetornaValorChave_DarumaFramework;
    }
}