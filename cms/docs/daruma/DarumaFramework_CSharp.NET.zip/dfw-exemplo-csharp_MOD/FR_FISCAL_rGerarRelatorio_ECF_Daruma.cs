﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rGerarRelatorio_ECF_Daruma : Form
    {
       public FR_FISCAL_rGerarRelatorio_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void CBO_Tipo_SelectedIndexChanged(object sender, EventArgs e)
        {
           if (CBO_Tipo.SelectedItem.Equals("DATAM"))
           {
               DTP_DataInicial.Visible = true;
               DTP_DataFinal.Visible = true;
               TB_Inicial.Visible = false;
               TB_Final.Visible = false;
           }else if(CBO_Tipo.SelectedItem.Equals("COO"))
                   {
                       DTP_DataInicial.Visible = false;
                       DTP_DataFinal.Visible = false;
                       TB_Inicial.Visible = true;
                       TB_Final.Visible = true;
                   }
           else if (CBO_Tipo.SelectedItem.Equals("CRZ"))
           {
               DTP_DataInicial.Visible = false;
               DTP_DataFinal.Visible = false;
               TB_Inicial.Visible = true;
               TB_Final.Visible = true;
           }

        }
      

        private void BT_GerarRelatorio_Click(object sender, EventArgs e)
        {
            string Str_Tipo,Str_ArquivoAtoCotepe,Str_ArquivoSintegra,Str_ArquivoNFP, Str_Inicial, Str_Final,Str_Relatorio;
            Str_Relatorio = Str_ArquivoAtoCotepe = Str_ArquivoNFP = Str_ArquivoSintegra = string.Empty;

            int Cont = 0;

            Str_ArquivoAtoCotepe = TB_ArquivoMF_MFD_TDM.Text;
            if (Str_ArquivoAtoCotepe != null)
            {
                Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"START\LocalArquivosRelatorios", Str_ArquivoAtoCotepe);
            }
       
            if (CHK_NFP.Checked) { Str_Relatorio += "NFP+"; Cont = Cont+1; }
            if (CHK_NFPTDM.Checked) { Str_Relatorio += "NFPTDM+"; Cont = Cont+1; }
            if (CHK_MF.Checked) { Str_Relatorio += "MF+"; Cont = Cont+1; }
            if (CHK_MFD.Checked) { Str_Relatorio += "MFD+"; Cont = Cont+1; }
            if (CHK_TDM.Checked) { Str_Relatorio += "TDM+"; Cont = Cont+1; }
            if (CHK_Sintegra.Checked) { Str_Relatorio += "SINTEGRA+"; Cont = Cont+1; }
            if (CHK_SPED.Checked) { Str_Relatorio += "SPED+"; Cont = Cont+1; }
            if (CHK_EAD.Checked) { Str_Relatorio += Str_Relatorio + "[EAD]" + TB_LocalChave.Text; }

            if(CBO_Tipo.SelectedItem.Equals("COO"))
            {
                Str_Tipo = "COO";
                Str_Inicial = TB_Inicial.Text.Trim() ;
                Str_Final = TB_Final.Text.Trim();

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorio_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno); 
           
            }else if(CBO_Tipo.SelectedItem.Equals("DATAM"))
                    {
                        Str_Tipo = "DATAM";
                        DateTime Str_Inicial1 = Convert.ToDateTime(DTP_DataInicial.Text);
                        Str_Inicial = Str_Inicial1.ToString("ddMMyyyy");
                        DateTime Str_Final1 = Convert.ToDateTime(DTP_DataFinal.Text);
                        Str_Final = Str_Final1.ToString("ddMMyyyy");
                              
                        Declaracoes.iRetorno = Declaracoes.rGerarRelatorio_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final);
                        Declaracoes.TrataRetorno(Declaracoes.iRetorno);    
                   
            } else if(CBO_Tipo.SelectedItem.Equals("CRZ"))
                             {
                                 Str_Tipo = "CRZ";
                                 Str_Inicial = TB_Inicial.Text.Trim();
                                 Str_Final = TB_Final.Text.Trim();

                              Declaracoes.iRetorno = Declaracoes.rGerarRelatorio_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final);
                              Declaracoes.TrataRetorno(Declaracoes.iRetorno);    
                              }
           
        }

        private void DTP_DataInicial_ValueChanged(object sender, EventArgs e)
        {

        }

        private void BT_FECHAR_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void EDT_Inicial_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BT_MF_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            TB_ArquivoMF_MFD_TDM.Text = folderBrowserDialog1.SelectedPath.ToString() + @"\";
        }

     

        private void TB_ArquivoMF_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_Informacoes_Click(object sender, EventArgs e)
        {
        }

        private void FR_FISCAL_rGerarRelatorio_ECF_Daruma_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void TB_Sintegra_TextChanged(object sender, EventArgs e)
        {

        }

        private void CHK_Sintegra_Click(object sender, EventArgs e)
        {
            

           
           
        }

        private void CHK_Sintegra_CheckedChanged(object sender, EventArgs e)
        {

         
           
        }

        private void CHK_Sintegra_CheckStateChanged(object sender, EventArgs e)
        {
            if (CHK_Sintegra.Checked == true)
            {
                FR_FISCAL_ParametrizacaoSintegra FormPrincipal = new FR_FISCAL_ParametrizacaoSintegra();
                FormPrincipal.Show();
            }
            
        }

        private void checkBox1_CheckStateChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_LocalChave.Text=openFileDialog1.FileName.ToString().Trim();

        }

   
    }
}
