using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_DarumaFramework_InputBox : Form
    {
        public FR_DarumaFramework_InputBox()
        {
            InitializeComponent();
            this.LB_stringInputBox.Text = Declaracoes.Str_LabelInputBox;
            this.TB_ComandoInputBox.Text = Declaracoes.Str_TextoInputBox;
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            Declaracoes.Str_Retorno_InputBox = this.TB_ComandoInputBox.Text;
            this.DestroyHandle();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Declaracoes.Str_Retorno_InputBox = "Erro ao incluir dados no Registro(Registry)!";
            this.DestroyHandle();

        }

        private void LB_stringInputBox_Click(object sender, EventArgs e)
        {

        }
    }
}