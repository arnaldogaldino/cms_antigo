﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Valor_Desconto = new System.Windows.Forms.TextBox();
            this.TB_Tipo_Desconto = new System.Windows.Forms.TextBox();
            this.TB_Numero_Item = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(199, 103);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 49;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(118, 103);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 48;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 71);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 13);
            this.label5.TabIndex = 47;
            this.label5.Text = "Valor  Desconto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 13);
            this.label4.TabIndex = 46;
            this.label4.Text = "Tipo Desconto:";
            // 
            // TB_Valor_Desconto
            // 
            this.TB_Valor_Desconto.Location = new System.Drawing.Point(118, 68);
            this.TB_Valor_Desconto.Name = "TB_Valor_Desconto";
            this.TB_Valor_Desconto.Size = new System.Drawing.Size(158, 20);
            this.TB_Valor_Desconto.TabIndex = 45;
            this.TB_Valor_Desconto.Text = "0,01";
            // 
            // TB_Tipo_Desconto
            // 
            this.TB_Tipo_Desconto.Location = new System.Drawing.Point(118, 42);
            this.TB_Tipo_Desconto.Name = "TB_Tipo_Desconto";
            this.TB_Tipo_Desconto.Size = new System.Drawing.Size(158, 20);
            this.TB_Tipo_Desconto.TabIndex = 44;
            this.TB_Tipo_Desconto.Text = "D$";
            // 
            // TB_Numero_Item
            // 
            this.TB_Numero_Item.Location = new System.Drawing.Point(118, 16);
            this.TB_Numero_Item.Name = "TB_Numero_Item";
            this.TB_Numero_Item.Size = new System.Drawing.Size(100, 20);
            this.TB_Numero_Item.TabIndex = 43;
            this.TB_Numero_Item.Text = "001";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "Número Item:";
            // 
            // FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 135);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_Valor_Desconto);
            this.Controls.Add(this.TB_Tipo_Desconto);
            this.Controls.Add(this.TB_Numero_Item);
            this.Controls.Add(this.label1);
            this.Name = "FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iCFLancarDescontoItem_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_Valor_Desconto;
        private System.Windows.Forms.TextBox TB_Tipo_Desconto;
        private System.Windows.Forms.TextBox TB_Numero_Item;
        private System.Windows.Forms.Label label1;
    }
}