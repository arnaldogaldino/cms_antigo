using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;
using System.Threading;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rReceberSMS_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rReceberSMS_MODEM_DarumaFramework()
        {
            InitializeComponent();
         
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            StringBuilder sIndiceSMS = new StringBuilder();
            StringBuilder sNumFone = new StringBuilder();
            StringBuilder sData = new StringBuilder();
            StringBuilder sHora = new StringBuilder();
            StringBuilder sMsg = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.iRetorno = Declaracoes.rReceberSms_MODEM_DarumaFramework(sIndiceSMS, sNumFone, sData, sHora, sMsg);


            if (Declaracoes.iRetorno > 0)
            {
                MessageBox.Show("'Mensagens Listadas com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_IndiceSms.Text = sIndiceSMS.ToString();
                TB_Telefone.Text = sNumFone.ToString();
                TB_Data.Text = sData.ToString();
                TB_Hora.Text = sHora.ToString();
                TB_Mensagem.Text = sMsg.ToString();
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Nao foi possivel Receber a mensagem.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -3: TB_RespostaModem.Text = "[-3] - Modem retornou caractere(s) inv�lido(s)";
                        break;
                    case -2: TB_RespostaModem.Text = "[-2] - Modem retornou erro";
                        break;
                    case -1: TB_RespostaModem.Text = "[-1] - Erro de comunica��o serial";
                        break;
                    case 0: TB_RespostaModem.Text = "[0] - N�o tem mensagem para ser lida";
                        break;
                }
            }

           
        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_IndiceSms.Clear();
            TB_Telefone.Clear();
            TB_Data.Clear();
            TB_Hora.Clear();
            TB_Mensagem.Clear();
            TB_RespostaModem.Clear();
        }
    }
}