namespace DarumaFramework_CSharp
{
    partial class FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Local = new System.Windows.Forms.Label();
            this.TB_Local = new System.Windows.Forms.TextBox();
            this.LB_Etiqueta = new System.Windows.Forms.Label();
            this.LB_Texto = new System.Windows.Forms.Label();
            this.TB_Texto = new System.Windows.Forms.TextBox();
            this.LB_TempoEtiqueta = new System.Windows.Forms.Label();
            this.TB_TimeOut = new System.Windows.Forms.TextBox();
            this.LB_SegundosEtiqueta = new System.Windows.Forms.Label();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LB_Local
            // 
            this.LB_Local.AutoSize = true;
            this.LB_Local.Location = new System.Drawing.Point(16, 34);
            this.LB_Local.Name = "LB_Local";
            this.LB_Local.Size = new System.Drawing.Size(36, 13);
            this.LB_Local.TabIndex = 0;
            this.LB_Local.Text = "Local:";
            // 
            // TB_Local
            // 
            this.TB_Local.Location = new System.Drawing.Point(74, 31);
            this.TB_Local.Name = "TB_Local";
            this.TB_Local.Size = new System.Drawing.Size(31, 20);
            this.TB_Local.TabIndex = 1;
            this.TB_Local.Text = "1";
            // 
            // LB_Etiqueta
            // 
            this.LB_Etiqueta.AutoSize = true;
            this.LB_Etiqueta.Location = new System.Drawing.Point(124, 34);
            this.LB_Etiqueta.Name = "LB_Etiqueta";
            this.LB_Etiqueta.Size = new System.Drawing.Size(222, 13);
            this.LB_Etiqueta.TabIndex = 2;
            this.LB_Etiqueta.Text = "1(um somente no doc) 0 (no doc e na bobina)";
            // 
            // LB_Texto
            // 
            this.LB_Texto.AutoSize = true;
            this.LB_Texto.Location = new System.Drawing.Point(16, 80);
            this.LB_Texto.Name = "LB_Texto";
            this.LB_Texto.Size = new System.Drawing.Size(118, 13);
            this.LB_Texto.TabIndex = 3;
            this.LB_Texto.Text = "Texto da Autenticacao:";
            // 
            // TB_Texto
            // 
            this.TB_Texto.Location = new System.Drawing.Point(140, 77);
            this.TB_Texto.Name = "TB_Texto";
            this.TB_Texto.Size = new System.Drawing.Size(382, 20);
            this.TB_Texto.TabIndex = 4;
            this.TB_Texto.Text = "<sn><c>DARUMA AUTENTICA��O</c> (D:<dt></dt> H:<hr></hr>)</sn>";
            // 
            // LB_TempoEtiqueta
            // 
            this.LB_TempoEtiqueta.AutoSize = true;
            this.LB_TempoEtiqueta.Location = new System.Drawing.Point(16, 123);
            this.LB_TempoEtiqueta.Name = "LB_TempoEtiqueta";
            this.LB_TempoEtiqueta.Size = new System.Drawing.Size(239, 13);
            this.LB_TempoEtiqueta.TabIndex = 5;
            this.LB_TempoEtiqueta.Text = "Tempo de espera para o posicionamento do doc:";
            // 
            // TB_TimeOut
            // 
            this.TB_TimeOut.Location = new System.Drawing.Point(261, 120);
            this.TB_TimeOut.Name = "TB_TimeOut";
            this.TB_TimeOut.Size = new System.Drawing.Size(55, 20);
            this.TB_TimeOut.TabIndex = 6;
            this.TB_TimeOut.Text = "10";
            // 
            // LB_SegundosEtiqueta
            // 
            this.LB_SegundosEtiqueta.AutoSize = true;
            this.LB_SegundosEtiqueta.Location = new System.Drawing.Point(322, 123);
            this.LB_SegundosEtiqueta.Name = "LB_SegundosEtiqueta";
            this.LB_SegundosEtiqueta.Size = new System.Drawing.Size(55, 13);
            this.LB_SegundosEtiqueta.TabIndex = 7;
            this.LB_SegundosEtiqueta.Text = "Segundos";
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(382, 168);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(78, 22);
            this.BT_Enviar.TabIndex = 8;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(466, 168);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(78, 22);
            this.BT_Fechar.TabIndex = 9;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 205);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.LB_SegundosEtiqueta);
            this.Controls.Add(this.TB_TimeOut);
            this.Controls.Add(this.LB_TempoEtiqueta);
            this.Controls.Add(this.TB_Texto);
            this.Controls.Add(this.LB_Texto);
            this.Controls.Add(this.LB_Etiqueta);
            this.Controls.Add(this.TB_Local);
            this.Controls.Add(this.LB_Local);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework";
            this.Text = "M�todo iAutenticarDocumento_DUAL_DarumaFramework                                 " +
                " Daruma DDC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_Local;
        private System.Windows.Forms.TextBox TB_Local;
        private System.Windows.Forms.Label LB_Etiqueta;
        private System.Windows.Forms.Label LB_Texto;
        private System.Windows.Forms.TextBox TB_Texto;
        private System.Windows.Forms.Label LB_TempoEtiqueta;
        private System.Windows.Forms.TextBox TB_TimeOut;
        private System.Windows.Forms.Label LB_SegundosEtiqueta;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
    }
}