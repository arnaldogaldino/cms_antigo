﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_eAcionarGuilhotina_ECF_Daruma : Form
    {
        public FR_FISCAL_eAcionarGuilhotina_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void RB_CorteParcial_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            if (RB_CorteParcial.Checked.Equals(true))
            { 
                Declaracoes.iRetorno = Declaracoes.eAcionarGuilhotina_ECF_Daruma("1");
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }else if (RB_CorteTotal.Checked.Equals(true))
            {
                Declaracoes.iRetorno = Declaracoes.eAcionarGuilhotina_ECF_Daruma("0");
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            
            }
        }

        private void RB_CorteParcial_Click(object sender, EventArgs e)
        {
           
        }

        private void RB_CorteTotal_Enter(object sender, EventArgs e)
        {
            if (RB_CorteTotal.Checked == true)
            {
                RB_CorteTotal.Checked = false;
                RB_CorteParcial.Checked = true;
            }
        }

        private void RB_CorteParcial_Enter(object sender, EventArgs e)
        {
            if (RB_CorteParcial.Checked == true)
            {
                RB_CorteParcial.Checked = false;
                RB_CorteTotal.Checked = true;
            }
        }
    }
}
