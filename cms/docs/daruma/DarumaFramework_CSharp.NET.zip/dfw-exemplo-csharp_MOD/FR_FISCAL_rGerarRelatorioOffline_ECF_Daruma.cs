﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma : Form
    {
        public FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma()
        {
            InitializeComponent();
        }
    
        private void BT_FECHAR_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_GerarRelatorio_Click(object sender, EventArgs e)
        {
            string Str_Tipo, Str_Inicial, Str_Final, Str_Relatorio, Str_ArquivoMF, Str_ArquivoMFD, Str_ArquivoInfo;
            Str_Relatorio = string.Empty;

            Str_ArquivoMF = TB_ArquivoMF.Text.Trim();
            Str_ArquivoMFD = TB_ArquivoMFD.Text.Trim();
            Str_ArquivoInfo = TB_ArquivoInformacoes.Text.Trim();

            if (CHK_NFP.Checked) { Str_Relatorio += "NFP|"; }
            if (CHK_NFPTDM.Checked) { Str_Relatorio += "NFPTDM|"; }
            if (CHK_MF.Checked) { Str_Relatorio += "MF|"; }
            if (CHK_MFD.Checked) { Str_Relatorio += "MFD|"; }
            if (CHK_TDM.Checked) { Str_Relatorio += "TDM|"; }
            if (CHK_Sintegra.Checked) { Str_Relatorio += "SINTEGRA|"; }

            if (CBO_Tipo.SelectedItem.Equals("COO"))
            {
                Str_Tipo = "COO";
                Str_Inicial = TB_Inicial.Text.Trim();
                Str_Final = TB_Final.Text.Trim();

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorioOffline_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final, Str_ArquivoMF, Str_ArquivoMFD, Str_ArquivoInfo);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (CBO_Tipo.SelectedItem.Equals("DATAM"))
            {
                Str_Tipo = "DATAM";
                DateTime Str_Inicial1 = Convert.ToDateTime(DTP_DataInicial.Text);
                Str_Inicial = Str_Inicial1.ToString("ddMMyyyy");
                DateTime Str_Final1 = Convert.ToDateTime(DTP_DataFinal.Text);
                Str_Final = Str_Final1.ToString("ddMMyyyy");

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorioOffline_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final, Str_ArquivoMF, Str_ArquivoMFD, Str_ArquivoInfo);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (CBO_Tipo.SelectedItem.Equals("CRZ"))
            {
                Str_Tipo = "CRZ";
                Str_Inicial = TB_Inicial.Text.Trim();
                Str_Final = TB_Final.Text.Trim();

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorioOffline_ECF_Daruma(Str_Relatorio, Str_Tipo, Str_Inicial, Str_Final, Str_ArquivoMF, Str_ArquivoMFD, Str_ArquivoInfo);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            }
        }

        private void BT_MF_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_ArquivoMF.Text = openFileDialog1.FileName;
            
        }

        private void BT_MFD_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_ArquivoMFD.Text = openFileDialog1.FileName;
        }

        private void BT_Informacoes_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_ArquivoInformacoes.Text = openFileDialog1.FileName;
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
