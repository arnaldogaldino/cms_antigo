﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_Operadora.Clear();
        }

        private void BT_Operadora_Click(object sender, EventArgs e)
        {
            StringBuilder sOperadora = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rRetornarOperadora_MODEM_DarumaFramework(sOperadora);

            if (Declaracoes.iRetorno == 1)
            {
                TB_Operadora.Text = sOperadora.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao tentar obter o Operadora", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -3: TB_Operadora.Text = "[-3] - Modem retornou caractere(s) inválido(s)";
                        break;
                    case -2: TB_Operadora.Text = "[-2] - Modem retornou erro";
                        break;
                    case -1: TB_Operadora.Text = "[-1] - Erro de comunicação serial";
                        break;
                }
            }

        }
    }
}
