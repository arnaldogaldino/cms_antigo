﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_eRSAAssinar : Form
    {
        public FR_FISCAL_eRSAAssinar()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Str_CaminhoArqAssinar= txtArquivo.Text;
            string Str_CaminhoChavePublica= txtChave.Text;
            Declaracoes.iRetorno = Declaracoes.eRSAAssinarArquivo_ECF_Daruma(Str_CaminhoArqAssinar, Str_CaminhoChavePublica);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
   
        }

        private void btnLocalArquivo_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            txtArquivo.Text= openFileDialog1.FileName.ToString();
            
        }

        private void btnLocalChave_Click(object sender, EventArgs e)
        {
            openFileDialog2.ShowDialog();
            txtChave.Text = openFileDialog2.FileName.ToString();
        }
    }
}
