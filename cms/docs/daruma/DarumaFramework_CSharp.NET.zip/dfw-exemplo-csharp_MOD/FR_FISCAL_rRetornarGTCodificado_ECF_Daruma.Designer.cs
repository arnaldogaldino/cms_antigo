﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_rRetornarGTCodificado_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TB_GTCodificado = new System.Windows.Forms.TextBox();
            this.BT_RetornaGTCodificado = new System.Windows.Forms.Button();
            this.BT_Voltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "GT Codificado:";
            // 
            // TB_GTCodificado
            // 
            this.TB_GTCodificado.Location = new System.Drawing.Point(15, 24);
            this.TB_GTCodificado.Name = "TB_GTCodificado";
            this.TB_GTCodificado.Size = new System.Drawing.Size(539, 20);
            this.TB_GTCodificado.TabIndex = 1;
            // 
            // BT_RetornaGTCodificado
            // 
            this.BT_RetornaGTCodificado.Location = new System.Drawing.Point(375, 55);
            this.BT_RetornaGTCodificado.Name = "BT_RetornaGTCodificado";
            this.BT_RetornaGTCodificado.Size = new System.Drawing.Size(75, 23);
            this.BT_RetornaGTCodificado.TabIndex = 2;
            this.BT_RetornaGTCodificado.Text = "Retornar GT";
            this.BT_RetornaGTCodificado.UseVisualStyleBackColor = true;
            this.BT_RetornaGTCodificado.Click += new System.EventHandler(this.button1_Click);
            // 
            // BT_Voltar
            // 
            this.BT_Voltar.Location = new System.Drawing.Point(478, 55);
            this.BT_Voltar.Name = "BT_Voltar";
            this.BT_Voltar.Size = new System.Drawing.Size(75, 23);
            this.BT_Voltar.TabIndex = 3;
            this.BT_Voltar.Text = "Voltar";
            this.BT_Voltar.UseVisualStyleBackColor = true;
            this.BT_Voltar.Click += new System.EventHandler(this.BT_Voltar_Click);
            // 
            // FR_FISCAL_rRetornarGTCodificado_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 90);
            this.Controls.Add(this.BT_Voltar);
            this.Controls.Add(this.BT_RetornaGTCodificado);
            this.Controls.Add(this.TB_GTCodificado);
            this.Controls.Add(this.label1);
            this.Name = "FR_FISCAL_rRetornarGTCodificado_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "rRetornarGTCodificado_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_GTCodificado;
        private System.Windows.Forms.Button BT_RetornaGTCodificado;
        private System.Windows.Forms.Button BT_Voltar;
    }
}