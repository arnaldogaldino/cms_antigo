using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using System.Threading;
using System.Diagnostics;
using System.Runtime.InteropServices;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MenuMODEM_Principal : Form
    {
        public FR_MenuMODEM_Principal()
        {
            InitializeComponent();

        }

        private const int VK_F18 = 0x81;

        private void FR_MODEM_MIN200_Load(object sender, EventArgs e)
        {

        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void MN_FecharJanela_Click(object sender, EventArgs e)
        {
            Close();
        }

      

        private void MN_regLerApagar_TRUE_Click(object sender, EventArgs e)
        {
            MN_regLerApagar_TRUE.Checked = false;
            MN_regLerApagar_FALSE.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regLerApagar_MODEM_DarumaFramework("TRUE");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regLerApagar_TRUE.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regLerApagar_FALSE_Click(object sender, EventArgs e)
        {
            MN_regLerApagar_TRUE.Checked = false;
            MN_regLerApagar_FALSE.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regLerApagar_MODEM_DarumaFramework("FALSE");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regLerApagar_FALSE.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regThread_TRUE_Click(object sender, EventArgs e)
        {
            MN_regThread_TRUE.Checked = false;
            MN_regThread_FALSE.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regThread_MODEM_DarumaFramework("TRUE");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regThread_TRUE.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regThread_FALSE_Click(object sender, EventArgs e)
        {
            MN_regThread_TRUE.Checked = false;
            MN_regThread_FALSE.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regThread_MODEM_DarumaFramework("FALSE");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regThread_FALSE.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regVelocidade_9600_Click(object sender, EventArgs e)
        {
            MN_regVelocidade_9600.Checked = false;
            MN_regVelocidade_38400.Checked = false;
            MN_regVelocidade_115200.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regVelocidade_MODEM_DarumaFramework("9600");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regVelocidade_9600.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regVelocidade_38400_Click(object sender, EventArgs e)
        {
            MN_regVelocidade_9600.Checked = false;
            MN_regVelocidade_38400.Checked = false;
            MN_regVelocidade_115200.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regVelocidade_MODEM_DarumaFramework("38400");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regVelocidade_38400.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regVelocidade_115200_Click(object sender, EventArgs e)
        {
            MN_regVelocidade_9600.Checked = false;
            MN_regVelocidade_38400.Checked = false;
            MN_regVelocidade_115200.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regVelocidade_MODEM_DarumaFramework("115200");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_regVelocidade_115200.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regPorta_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita a Porta de Comunica��o:", "COM1");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regPorta_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regPorta_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_fnInicializar_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eInicializar_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Modem Inicializado com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao Inicializar o Modem", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_fnFinalizar_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_MODEM_rNivelSinalRecebido_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rNivelSinalRecebido_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void MN_fnReseta_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eTrocarBandeja_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Bandeja trocada com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao tentar trocar a bandeja", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_fnApagarSMS_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_MODEM_eApagar_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_eApagar_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void MN_rLerSMS_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_MODEM_rListarSMS_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rListarSMS_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void MN_rLerUltimoSMS_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_MODEM_rReceberSMS_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rReceberSMS_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }



        private void MN_tEnviarSMS_MODEM_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_MODEM_tEnviarSMS_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_tEnviarSMS_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void MN_Metodos_Funcao_MODEM_Click(object sender, EventArgs e)
        {

        }

        private void MN_eDefinirProduto_Daruma_Click(object sender, EventArgs e)
        {

            string sProduto;

            sProduto = "MODEM";

            Declaracoes.iRetorno = Declaracoes.eDefinirProduto_Daruma(sProduto);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso, produto MODEM", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_NovasMensagens.Clear();
        }

        private void FR_MenuMODEM_Principal_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F18)
            {
                TB_NovasMensagens.Text = "Novas Mensagens!!!";
            }

            
        }

        private void MN_regRetornaValorChave_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework DarumaRetorna = new FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework();
            DarumaRetorna.Show();
        }

        private void m�todoRegCaptionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite o nome da Janela(Caption) que receber� o alerta de SMS UNREAD", "Modem - Daruma Telecom");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regCaptionWinAPP_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regCaptionWinAPP_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
 
        }

        private void m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita o intervalo de tempo para a thread verificar por SMS unread", "4000");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regTempoAlertar_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regTempoAlertar_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite SIM1 ou SIM2, para definir qual Bandeja o modem deve iniciar", "SIM1");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regBandejaInicio_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regBandejaInicio_MODEM_DarumaFramework(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_MODEM_rRetornarImei_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rRetornarImei_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void m�todoRRetornarImeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

        private void m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_MODEM_rReceberSMS_MODEM_DarumaFramework FormPrincipal = new FR_MODEM_rReceberSMS_MODEM_DarumaFramework();
            FormPrincipal.Show();
        }

       
        private void alertarSMSUNREADToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Process[] processes = Process.GetProcessesByName("Modem - Daruma Telecom");
            foreach (Process p in processes)
            {
           
                TB_NovasMensagens.Text = p.ProcessName.ToString() ;
                p.CloseMainWindow();
            }

        }

        private void servi�oCSDDarumaFrameworkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_MODEM_ServicoCSD_DarumaFramework FormPrincipal = new FR_MODEM_ServicoCSD_DarumaFramework();
            FormPrincipal.Show();

        }

    }
}