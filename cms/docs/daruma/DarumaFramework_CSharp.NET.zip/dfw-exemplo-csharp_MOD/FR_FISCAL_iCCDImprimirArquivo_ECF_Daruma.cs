﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCCDImprimirArquivo_ECF_Daruma : Form
    {
        public FR_FISCAL_iCCDImprimirArquivo_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Texto_Caminho;

            Str_Texto_Caminho = TB_Texto_Caminho.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCCDImprimirArquivo_ECF_Daruma(Str_Texto_Caminho);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
