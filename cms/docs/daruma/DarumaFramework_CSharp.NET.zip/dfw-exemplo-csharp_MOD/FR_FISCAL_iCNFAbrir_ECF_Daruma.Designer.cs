﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCNFAbrir_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Texto_Endereco = new System.Windows.Forms.TextBox();
            this.TB_Texto_Nome = new System.Windows.Forms.TextBox();
            this.TB_Texto_CPF = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(368, 123);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 105;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(286, 123);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 104;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 102;
            this.label4.Text = "Endereço";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 103;
            this.label3.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 101;
            this.label2.Text = "CPF";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 13);
            this.label1.TabIndex = 100;
            this.label1.Text = "Informe os Dados do Consumidor";
            // 
            // TB_Texto_Endereco
            // 
            this.TB_Texto_Endereco.Location = new System.Drawing.Point(71, 88);
            this.TB_Texto_Endereco.Name = "TB_Texto_Endereco";
            this.TB_Texto_Endereco.Size = new System.Drawing.Size(374, 20);
            this.TB_Texto_Endereco.TabIndex = 97;
            this.TB_Texto_Endereco.Text = "Av. Shishima Hifumi, 2911. 4 andar - Sala. 406  - São José dos Campos - São Paulo" +
                "";
            // 
            // TB_Texto_Nome
            // 
            this.TB_Texto_Nome.Location = new System.Drawing.Point(71, 58);
            this.TB_Texto_Nome.Name = "TB_Texto_Nome";
            this.TB_Texto_Nome.Size = new System.Drawing.Size(374, 20);
            this.TB_Texto_Nome.TabIndex = 98;
            this.TB_Texto_Nome.Text = "Daruma Developer Community";
            // 
            // TB_Texto_CPF
            // 
            this.TB_Texto_CPF.Location = new System.Drawing.Point(71, 32);
            this.TB_Texto_CPF.Name = "TB_Texto_CPF";
            this.TB_Texto_CPF.Size = new System.Drawing.Size(374, 20);
            this.TB_Texto_CPF.TabIndex = 99;
            this.TB_Texto_CPF.Text = "123.123.123-99";
            // 
            // FR_FISCAL_iCNFAbrir_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 149);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Texto_Endereco);
            this.Controls.Add(this.TB_Texto_Nome);
            this.Controls.Add(this.TB_Texto_CPF);
            this.Name = "FR_FISCAL_iCNFAbrir_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iCNFAbrir_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Texto_Endereco;
        private System.Windows.Forms.TextBox TB_Texto_Nome;
        private System.Windows.Forms.TextBox TB_Texto_CPF;
    }
}