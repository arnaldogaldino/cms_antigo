﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_RetornoECF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_Retorno = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.métodosRetornoECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRLerMeiosPagtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRLerRGECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.retornoCupomFiscalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodosDeStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodosEspeciaisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatórioDeConfiguraçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TB_Retorno);
            this.groupBox1.Location = new System.Drawing.Point(7, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(612, 203);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Daruma Framework Retornos da Impressora:";
            // 
            // TB_Retorno
            // 
            this.TB_Retorno.Location = new System.Drawing.Point(6, 19);
            this.TB_Retorno.Multiline = true;
            this.TB_Retorno.Name = "TB_Retorno";
            this.TB_Retorno.Size = new System.Drawing.Size(601, 178);
            this.TB_Retorno.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodosRetornoECFToolStripMenuItem,
            this.métodosDeStatusToolStripMenuItem,
            this.métodosEspeciaisToolStripMenuItem,
            this.relatórioDeConfiguraçãoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(623, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // métodosRetornoECFToolStripMenuItem
            // 
            this.métodosRetornoECFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem,
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem,
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem,
            this.métodoRLerMeiosPagtToolStripMenuItem,
            this.métodoRLerRGECFDarumaToolStripMenuItem,
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem,
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem,
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem,
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem,
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem,
            this.toolStripMenuItem2,
            this.retornoCupomFiscalToolStripMenuItem});
            this.métodosRetornoECFToolStripMenuItem.Name = "métodosRetornoECFToolStripMenuItem";
            this.métodosRetornoECFToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.métodosRetornoECFToolStripMenuItem.Text = "Métodos Retorno ECF";
            // 
            // métodoRRetornarInformacaoECFDarumaToolStripMenuItem
            // 
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem.Name = "métodoRRetornarInformacaoECFDarumaToolStripMenuItem";
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem.Text = "Método rRetornarInformacao_ECF_Daruma";
            this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRRetornarInformacaoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRLerAliquotasECFDarumaToolStripMenuItem
            // 
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem.Name = "métodoRLerAliquotasECFDarumaToolStripMenuItem";
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem.Text = "Método rLerAliquotas_ECF_Daruma";
            this.métodoRLerAliquotasECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRLerAliquotasECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRLerMeiosPagtToolStripMenuItem
            // 
            this.métodoRLerMeiosPagtToolStripMenuItem.Name = "métodoRLerMeiosPagtToolStripMenuItem";
            this.métodoRLerMeiosPagtToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRLerMeiosPagtToolStripMenuItem.Text = "Método rLerMeiosPagto_ECF_Daruma";
            this.métodoRLerMeiosPagtToolStripMenuItem.Click += new System.EventHandler(this.métodoRLerMeiosPagtToolStripMenuItem_Click);
            // 
            // métodoRLerRGECFDarumaToolStripMenuItem
            // 
            this.métodoRLerRGECFDarumaToolStripMenuItem.Name = "métodoRLerRGECFDarumaToolStripMenuItem";
            this.métodoRLerRGECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRLerRGECFDarumaToolStripMenuItem.Text = "Método rLerRG_ECF_Daruma";
            this.métodoRLerRGECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRLerRGECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRLerDecimaisECFDarumaToolStripMenuItem
            // 
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem.Name = "métodoRLerDecimaisECFDarumaToolStripMenuItem";
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem.Text = "Método rLerDecimais_ECF_Daruma";
            this.métodoRLerDecimaisECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRLerDecimaisECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRDataHoraImpressoraECFDarumaToolStripMenuItem
            // 
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem.Name = "métodoRDataHoraImpressoraECFDarumaToolStripMenuItem";
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem.Text = "Método rDataHoraImpressora_ECF_Daruma";
            this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRDataHoraImpressoraECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRVerificarReducaoZECFDarumaToolStripMenuItem
            // 
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem.Name = "métodoRVerificarReducaoZECFDarumaToolStripMenuItem";
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem.Text = "Método rVerificarReducaoZ_ECF_Daruma";
            this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRVerificarReducaoZECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem
            // 
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem.Name = "métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem";
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem.Text = "Método rVerificarImpressoraLigada_ECF_Daruma";
            this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem
            // 
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem.Name = "métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem";
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem.Text = "Método rRetornarDadosReducaoZ_ECF_Daruma";
            this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Enabled = false;
            this.toolStripMenuItem2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Underline);
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(354, 22);
            this.toolStripMenuItem2.Text = "----------------------------------------------------------------------";
            // 
            // retornoCupomFiscalToolStripMenuItem
            // 
            this.retornoCupomFiscalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem,
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1,
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1,
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem});
            this.retornoCupomFiscalToolStripMenuItem.Name = "retornoCupomFiscalToolStripMenuItem";
            this.retornoCupomFiscalToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.retornoCupomFiscalToolStripMenuItem.Text = "Retorno Cupom Fiscal";
            // 
            // métodoRCFSaldoAPagarECFDarumaToolStripMenuItem
            // 
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem.Name = "métodoRCFSaldoAPagarECFDarumaToolStripMenuItem";
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem.Text = "Método rCFSaldoAPagar_ECF_Daruma";
            this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRCFSaldoAPagarECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRCFSubTotalECFDarumaToolStripMenuItem1
            // 
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1.Name = "métodoRCFSubTotalECFDarumaToolStripMenuItem1";
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(291, 22);
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1.Text = "Método rCFSubTotal_ECF_Daruma";
            this.métodoRCFSubTotalECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoRCFSubTotalECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1
            // 
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1.Name = "métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1";
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(291, 22);
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1.Text = "Método rCMEfetuarCalculo_ECF_Daruma";
            this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoRCFVerificaStatusECFDarumaToolStripMenuItem
            // 
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem.Name = "métodoRCFVerificaStatusECFDarumaToolStripMenuItem";
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(291, 22);
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem.Text = "Método rCFVerificaStatus_ECF_Daruma";
            this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRCFVerificaStatusECFDarumaToolStripMenuItem_Click);
            // 
            // métodosDeStatusToolStripMenuItem
            // 
            this.métodosDeStatusToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem,
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem,
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem,
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem,
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem,
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem});
            this.métodosDeStatusToolStripMenuItem.Name = "métodosDeStatusToolStripMenuItem";
            this.métodosDeStatusToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.métodosDeStatusToolStripMenuItem.Text = "Métodos Status";
            // 
            // métodoRStatusImpressoraECFDarumaToolStripMenuItem
            // 
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem.Name = "métodoRStatusImpressoraECFDarumaToolStripMenuItem";
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem.Text = "Método rStatusImpressora_ECF_Daruma";
            this.métodoRStatusImpressoraECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRStatusImpressoraECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRStatusUltimoCmdECFDarumaToolStripMenuItem
            // 
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem.Name = "métodoRStatusUltimoCmdECFDarumaToolStripMenuItem";
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem.Text = "Método rStatusUltimoCmd_ECF_Daruma";
            this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRStatusUltimoCmdECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendidaECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendidaECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida_ECF_Daruma";
            this.métodoRInfoEstendidaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendidaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendida1ECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendida1ECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida1_ECF_Daruma";
            this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendida1ECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendida2ECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendida2ECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida2_ECF_Daruma";
            this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendida2ECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendida3ECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendida3ECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida3_ECF_Daruma";
            this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendida3ECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendida4ECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendida4ECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida4_ECF_Daruma";
            this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendida4ECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRInfoEstendida5ECFDarumaToolStripMenuItem
            // 
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem.Name = "métodoRInfoEstendida5ECFDarumaToolStripMenuItem";
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem.Text = "Método rInfoEstendida5_ECF_Daruma";
            this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRInfoEstendida5ECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem
            // 
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem.Name = "métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem";
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem.Text = "Método rStatusImpressoraBinario_ECF_Daruma";
            this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem
            // 
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem.Name = "métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem";
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem.Text = "Método rConsultaStatusImpressoraStr_ECF_Daruma";
            this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem_Click);
            // 
            // métodosEspeciaisToolStripMenuItem
            // 
            this.métodosEspeciaisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem,
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem,
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem});
            this.métodosEspeciaisToolStripMenuItem.Name = "métodosEspeciaisToolStripMenuItem";
            this.métodosEspeciaisToolStripMenuItem.Size = new System.Drawing.Size(116, 20);
            this.métodosEspeciaisToolStripMenuItem.Text = "Métodos Especiais";
            // 
            // métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem
            // 
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem.Name = "métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem";
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem.Text = "Método eBuscarPortaVelocidade_ECF_Daruma";
            this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem_Click);
            // 
            // métodoEVerificarVersaoECFDarumaToolStripMenuItem
            // 
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem.Name = "métodoEVerificarVersaoECFDarumaToolStripMenuItem";
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem.Text = "Método eVerificarVersaoDLL_Daruma";
            this.métodoEVerificarVersaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEVerificarVersaoECFDarumaToolStripMenuItem_Click);
            // 
            // eRetornarPortasCOMECFDarumaToolStripMenuItem
            // 
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem.Name = "eRetornarPortasCOMECFDarumaToolStripMenuItem";
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(318, 22);
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem.Text = "Método eRetornarPortasCOM_ECF_Daruma";
            this.eRetornarPortasCOMECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.eRetornarPortasCOMECFDarumaToolStripMenuItem_Click);
            // 
            // relatórioDeConfiguraçãoToolStripMenuItem
            // 
            this.relatórioDeConfiguraçãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem});
            this.relatórioDeConfiguraçãoToolStripMenuItem.Name = "relatórioDeConfiguraçãoToolStripMenuItem";
            this.relatórioDeConfiguraçãoToolStripMenuItem.Size = new System.Drawing.Size(157, 20);
            this.relatórioDeConfiguraçãoToolStripMenuItem.Text = "Relatório de Configuração";
            // 
            // iRelatorioConfiguracaoECFDarumaToolStripMenuItem
            // 
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem.Name = "iRelatorioConfiguracaoECFDarumaToolStripMenuItem";
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(268, 22);
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem.Text = "iRelatorioConfiguracao_ECF_Daruma";
            this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.iRelatorioConfiguracaoECFDarumaToolStripMenuItem_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(536, 238);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 2;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.button1_Click);
            // 
            // métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem
            // 
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem.Name = "métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem";
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(346, 22);
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem.Text = "Método rConsultaStatusImpressoraInt_ECF_Daruma";
            this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem
            // 
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem.Name = "métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem";
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(354, 22);
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem.Text = "Método rRetornarInformacaoSeparador_ECF_Daruma";
            this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem_Click);
            // 
            // FR_FISCAL_RetornoECF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 272);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FR_FISCAL_RetornoECF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FR_FISCAL_RetornoECF";
            this.Load += new System.EventHandler(this.FR_FISCAL_RetornoECF_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.TextBox TB_Retorno;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.ToolStripMenuItem métodosDeStatusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRStatusImpressoraECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRStatusUltimoCmdECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodosEspeciaisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendida1ECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendida2ECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendida3ECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendida4ECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendida5ECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEVerificarVersaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRInfoEstendidaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodosRetornoECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRRetornarInformacaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRLerAliquotasECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRLerMeiosPagtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRLerRGECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRLerDecimaisECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRDataHoraImpressoraECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRVerificarReducaoZECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem retornoCupomFiscalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRCFSaldoAPagarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRCFSubTotalECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoRCFVerificaStatusECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eRetornarPortasCOMECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatórioDeConfiguraçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iRelatorioConfiguracaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem;
    }
}