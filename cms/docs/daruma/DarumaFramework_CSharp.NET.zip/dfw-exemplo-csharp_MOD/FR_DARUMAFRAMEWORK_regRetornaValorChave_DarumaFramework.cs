using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework : Form
    {
        public FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            string stProduto, stChave;

            StringBuilder stValor = new StringBuilder();
                
            stProduto = TB_Produto.Text;
            stChave = TB_Chave.Text;

            Declaracoes.iRetorno = Declaracoes.regRetornaValorChave_DarumaFramework(stProduto, stChave, stValor);
            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Solicitacao concluida com sucesso, segue o conteudo da Chave.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_Valor.Text = stValor.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao solicitar as informacoes da Chave, verificar.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }
    }
}