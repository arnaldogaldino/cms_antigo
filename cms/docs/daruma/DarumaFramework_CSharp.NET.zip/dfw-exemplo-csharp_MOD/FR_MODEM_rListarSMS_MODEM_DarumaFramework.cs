using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;
using System.Threading;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rListarSMS_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rListarSMS_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rListarSms_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Mensagens Listadas com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao listar as mensagens.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -3: TB_RespostaModem.Text = "[-3] - Modem retornou caractere(s) inv�lido(s)";
                        break;
                    case -2: TB_RespostaModem.Text = "[-2] - Modem retornou erro";
                        break;
                    case -1: TB_RespostaModem.Text = "[-1] - Erro de comunica��o serial";
                        break;
                }

            }

        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_RespostaModem.Clear();
        }
    }
}