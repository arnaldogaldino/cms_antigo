namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_fnApagar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_NumeroSMS = new System.Windows.Forms.Label();
            this.TB_NumeroSMS = new System.Windows.Forms.TextBox();
            this.LB_RespostaModem = new System.Windows.Forms.Label();
            this.TB_RespostaModem = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LB_NumeroSMS
            // 
            this.LB_NumeroSMS.AutoSize = true;
            this.LB_NumeroSMS.Location = new System.Drawing.Point(2, 18);
            this.LB_NumeroSMS.Name = "LB_NumeroSMS";
            this.LB_NumeroSMS.Size = new System.Drawing.Size(189, 13);
            this.LB_NumeroSMS.TabIndex = 0;
            this.LB_NumeroSMS.Text = "Numero da Mensagem a ser Apagada:";
            // 
            // TB_NumeroSMS
            // 
            this.TB_NumeroSMS.Location = new System.Drawing.Point(6, 40);
            this.TB_NumeroSMS.Name = "TB_NumeroSMS";
            this.TB_NumeroSMS.Size = new System.Drawing.Size(185, 20);
            this.TB_NumeroSMS.TabIndex = 1;
            // 
            // LB_RespostaModem
            // 
            this.LB_RespostaModem.AutoSize = true;
            this.LB_RespostaModem.Location = new System.Drawing.Point(3, 73);
            this.LB_RespostaModem.Name = "LB_RespostaModem";
            this.LB_RespostaModem.Size = new System.Drawing.Size(157, 13);
            this.LB_RespostaModem.TabIndex = 2;
            this.LB_RespostaModem.Text = "Resposta Recebida do Modem:";
            // 
            // TB_RespostaModem
            // 
            this.TB_RespostaModem.Location = new System.Drawing.Point(6, 101);
            this.TB_RespostaModem.Multiline = true;
            this.TB_RespostaModem.Name = "TB_RespostaModem";
            this.TB_RespostaModem.ReadOnly = true;
            this.TB_RespostaModem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_RespostaModem.Size = new System.Drawing.Size(185, 129);
            this.TB_RespostaModem.TabIndex = 3;
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(197, 177);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 4;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(197, 206);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 5;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // FR_MODEM_fnApagar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(277, 239);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_RespostaModem);
            this.Controls.Add(this.LB_RespostaModem);
            this.Controls.Add(this.TB_NumeroSMS);
            this.Controls.Add(this.LB_NumeroSMS);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MODEM_fnApagar";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "M�todo para Apagar Mensagens";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_NumeroSMS;
        private System.Windows.Forms.TextBox TB_NumeroSMS;
        private System.Windows.Forms.Label LB_RespostaModem;
        private System.Windows.Forms.TextBox TB_RespostaModem;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
    }
}