using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework : Form
    {
        public FR_metodo_iAutenticarDocumento_DUAL_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string stLocal;
            string stTexto;
            string stTimeOut;

            stLocal = TB_Local.Text;
            stTexto = TB_Texto.Text;
            stTimeOut = TB_TimeOut.Text;

            Declaracoes.iAutenticarDocumento_DUAL_DarumaFramework(stTexto, stLocal, stTimeOut);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Autentica��o realizada com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao Autenticar Documento!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}