﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rRSAChavePublica : Form
    {
        public FR_FISCAL_rRSAChavePublica()
        {
            InitializeComponent();
        }

        private void FR_FISCAL_rRSAChavePublica_Load(object sender, EventArgs e)
        {
            
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            if (TB_CaminhoChavePrivada.Text != string.Empty)
            {
                string Str_CaminhoChavePrivada;
                string Str_ChavePublica = new string(' ', 257);
                string Str_ExpoentePublico = new string(' ', 257);

                Str_CaminhoChavePrivada = TB_CaminhoChavePrivada.Text.Trim();

                DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.rRSAChavePublica_ECF_Daruma(Str_CaminhoChavePrivada, ref Str_ChavePublica, ref Str_ExpoentePublico);
                DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.DarumaFramework_Mostrar_Retorno(DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno);

                TB_ChavePublica.Text = Str_ChavePublica.ToString();
                TB_ExpoentePublico.Text = Str_ExpoentePublico.ToString();
            }
            else
            {
                MessageBox.Show("Campo chave publica deve ser preenchido!", "DarumaFramework");
            }

        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BT_CaminhoChavePrivada_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_CaminhoChavePrivada.Text = openFileDialog1.FileName;
        }
    }
}
