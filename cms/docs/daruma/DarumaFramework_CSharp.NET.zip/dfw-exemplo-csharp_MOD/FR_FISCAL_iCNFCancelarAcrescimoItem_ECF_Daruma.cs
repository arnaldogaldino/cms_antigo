﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCNFCancelarAcrescimoItem_ECF_Daruma : Form
    {
        public FR_FISCAL_iCNFCancelarAcrescimoItem_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Indice;

            Str_Indice = TB_Indice.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCNFCancelarAcrescimoItem_ECF_Daruma(Str_Indice);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
