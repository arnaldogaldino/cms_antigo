using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using System.Threading;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_eApagar_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_eApagar_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {

            this.DestroyHandle();

        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            int iNumeroSMS;

            iNumeroSMS = 0;
         
            if (TB_NumeroSMS.Text == "" || int.Parse(TB_NumeroSMS.Text) == 0)
            {
                MessageBox.Show("� preciso digitar o numero do SMS diferente de 0", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                iNumeroSMS = int.Parse(TB_NumeroSMS.Text);
            }


            Declaracoes.iRetorno = Declaracoes.eApagarSms_MODEM_DarumaFramework(TB_NumeroSMS.Text);         
            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Mensagem apagada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao apagar a mensagem", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }

        }
    }
}