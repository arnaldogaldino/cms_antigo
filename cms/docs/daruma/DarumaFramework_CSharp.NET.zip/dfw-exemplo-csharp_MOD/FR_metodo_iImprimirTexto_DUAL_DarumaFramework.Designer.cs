namespace DarumaFramework_CSharp
{
    partial class FR_metodo_iImprimirTexto_DUAL_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GB_TextoImprimir = new System.Windows.Forms.GroupBox();
            this.TB_Texto = new System.Windows.Forms.TextBox();
            this.GB_TAGS = new System.Windows.Forms.GroupBox();
            this.LB_gui = new System.Windows.Forms.Label();
            this.LB_bmp = new System.Windows.Forms.Label();
            this.LB_Comandos = new System.Windows.Forms.Label();
            this.LB_pdf = new System.Windows.Forms.Label();
            this.LB_msi = new System.Windows.Forms.Label();
            this.LB_codabar = new System.Windows.Forms.Label();
            this.LB_code11 = new System.Windows.Forms.Label();
            this.LB_code93 = new System.Windows.Forms.Label();
            this.LB_code39 = new System.Windows.Forms.Label();
            this.LB_upc = new System.Windows.Forms.Label();
            this.LB_ean8 = new System.Windows.Forms.Label();
            this.LB_ean13 = new System.Windows.Forms.Label();
            this.LB_CdBarras = new System.Windows.Forms.Label();
            this.LB_da = new System.Windows.Forms.Label();
            this.LB_ad = new System.Windows.Forms.Label();
            this.LB_fe = new System.Windows.Forms.Label();
            this.LB_tb = new System.Windows.Forms.Label();
            this.LB_a = new System.Windows.Forms.Label();
            this.LB_g = new System.Windows.Forms.Label();
            this.LB_sn = new System.Windows.Forms.Label();
            this.LB_sp = new System.Windows.Forms.Label();
            this.LB_hr = new System.Windows.Forms.Label();
            this.LB_dt = new System.Windows.Forms.Label();
            this.LB_tc = new System.Windows.Forms.Label();
            this.LB_sl = new System.Windows.Forms.Label();
            this.LB_l = new System.Windows.Forms.Label();
            this.LB_n = new System.Windows.Forms.Label();
            this.LB_c = new System.Windows.Forms.Label();
            this.LB_e = new System.Windows.Forms.Label();
            this.LB_s = new System.Windows.Forms.Label();
            this.LB_i = new System.Windows.Forms.Label();
            this.LB_b = new System.Windows.Forms.Label();
            this.LB_ce = new System.Windows.Forms.Label();
            this.BT_Completo = new System.Windows.Forms.Button();
            this.BT_CompletoSeparado = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.LB_Code128 = new System.Windows.Forms.Label();
            this.LB_i2of5 = new System.Windows.Forms.Label();
            this.LB_s2of5 = new System.Windows.Forms.Label();
            this.GB_TextoImprimir.SuspendLayout();
            this.GB_TAGS.SuspendLayout();
            this.SuspendLayout();
            // 
            // GB_TextoImprimir
            // 
            this.GB_TextoImprimir.Controls.Add(this.TB_Texto);
            this.GB_TextoImprimir.Location = new System.Drawing.Point(4, 4);
            this.GB_TextoImprimir.Name = "GB_TextoImprimir";
            this.GB_TextoImprimir.Size = new System.Drawing.Size(310, 414);
            this.GB_TextoImprimir.TabIndex = 0;
            this.GB_TextoImprimir.TabStop = false;
            this.GB_TextoImprimir.Text = "Digite o texto:";
            // 
            // TB_Texto
            // 
            this.TB_Texto.Location = new System.Drawing.Point(11, 23);
            this.TB_Texto.Multiline = true;
            this.TB_Texto.Name = "TB_Texto";
            this.TB_Texto.Size = new System.Drawing.Size(284, 378);
            this.TB_Texto.TabIndex = 0;
            // 
            // GB_TAGS
            // 
            this.GB_TAGS.Controls.Add(this.LB_s2of5);
            this.GB_TAGS.Controls.Add(this.LB_i2of5);
            this.GB_TAGS.Controls.Add(this.LB_Code128);
            this.GB_TAGS.Controls.Add(this.LB_gui);
            this.GB_TAGS.Controls.Add(this.LB_bmp);
            this.GB_TAGS.Controls.Add(this.LB_Comandos);
            this.GB_TAGS.Controls.Add(this.LB_pdf);
            this.GB_TAGS.Controls.Add(this.LB_msi);
            this.GB_TAGS.Controls.Add(this.LB_codabar);
            this.GB_TAGS.Controls.Add(this.LB_code11);
            this.GB_TAGS.Controls.Add(this.LB_code93);
            this.GB_TAGS.Controls.Add(this.LB_code39);
            this.GB_TAGS.Controls.Add(this.LB_upc);
            this.GB_TAGS.Controls.Add(this.LB_ean8);
            this.GB_TAGS.Controls.Add(this.LB_ean13);
            this.GB_TAGS.Controls.Add(this.LB_CdBarras);
            this.GB_TAGS.Controls.Add(this.LB_da);
            this.GB_TAGS.Controls.Add(this.LB_ad);
            this.GB_TAGS.Controls.Add(this.LB_fe);
            this.GB_TAGS.Controls.Add(this.LB_tb);
            this.GB_TAGS.Controls.Add(this.LB_a);
            this.GB_TAGS.Controls.Add(this.LB_g);
            this.GB_TAGS.Controls.Add(this.LB_sn);
            this.GB_TAGS.Controls.Add(this.LB_sp);
            this.GB_TAGS.Controls.Add(this.LB_hr);
            this.GB_TAGS.Controls.Add(this.LB_dt);
            this.GB_TAGS.Controls.Add(this.LB_tc);
            this.GB_TAGS.Controls.Add(this.LB_sl);
            this.GB_TAGS.Controls.Add(this.LB_l);
            this.GB_TAGS.Controls.Add(this.LB_n);
            this.GB_TAGS.Controls.Add(this.LB_c);
            this.GB_TAGS.Controls.Add(this.LB_e);
            this.GB_TAGS.Controls.Add(this.LB_s);
            this.GB_TAGS.Controls.Add(this.LB_i);
            this.GB_TAGS.Controls.Add(this.LB_b);
            this.GB_TAGS.Controls.Add(this.LB_ce);
            this.GB_TAGS.Location = new System.Drawing.Point(320, 4);
            this.GB_TAGS.Name = "GB_TAGS";
            this.GB_TAGS.Size = new System.Drawing.Size(281, 527);
            this.GB_TAGS.TabIndex = 1;
            this.GB_TAGS.TabStop = false;
            this.GB_TAGS.Text = "TAGS:";
            // 
            // LB_gui
            // 
            this.LB_gui.AutoSize = true;
            this.LB_gui.Location = new System.Drawing.Point(6, 509);
            this.LB_gui.Name = "LB_gui";
            this.LB_gui.Size = new System.Drawing.Size(151, 13);
            this.LB_gui.TabIndex = 30;
            this.LB_gui.Text = "Acionar guilhotina <gui></gui>";
            // 
            // LB_bmp
            // 
            this.LB_bmp.AutoSize = true;
            this.LB_bmp.Location = new System.Drawing.Point(6, 496);
            this.LB_bmp.Name = "LB_bmp";
            this.LB_bmp.Size = new System.Drawing.Size(159, 13);
            this.LB_bmp.TabIndex = 29;
            this.LB_bmp.Text = "Carregar logotipo <bmp></bmp>";
            // 
            // LB_Comandos
            // 
            this.LB_Comandos.AutoSize = true;
            this.LB_Comandos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Comandos.Location = new System.Drawing.Point(6, 480);
            this.LB_Comandos.Name = "LB_Comandos";
            this.LB_Comandos.Size = new System.Drawing.Size(69, 13);
            this.LB_Comandos.TabIndex = 28;
            this.LB_Comandos.Text = "Comandos:";
            // 
            // LB_pdf
            // 
            this.LB_pdf.AutoSize = true;
            this.LB_pdf.Location = new System.Drawing.Point(6, 414);
            this.LB_pdf.Name = "LB_pdf";
            this.LB_pdf.Size = new System.Drawing.Size(90, 13);
            this.LB_pdf.TabIndex = 27;
            this.LB_pdf.Text = "<pdf>1234</pdf>";
            // 
            // LB_msi
            // 
            this.LB_msi.AutoSize = true;
            this.LB_msi.Location = new System.Drawing.Point(6, 388);
            this.LB_msi.Name = "LB_msi";
            this.LB_msi.Size = new System.Drawing.Size(120, 13);
            this.LB_msi.TabIndex = 26;
            this.LB_msi.Text = "<msi>123456789</msi>";
            // 
            // LB_codabar
            // 
            this.LB_codabar.AutoSize = true;
            this.LB_codabar.Location = new System.Drawing.Point(6, 375);
            this.LB_codabar.Name = "LB_codabar";
            this.LB_codabar.Size = new System.Drawing.Size(166, 13);
            this.LB_codabar.TabIndex = 25;
            this.LB_codabar.Text = "<codabar>CODABAR</codabar>";
            // 
            // LB_code11
            // 
            this.LB_code11.AutoSize = true;
            this.LB_code11.Location = new System.Drawing.Point(6, 401);
            this.LB_code11.Name = "LB_code11";
            this.LB_code11.Size = new System.Drawing.Size(174, 13);
            this.LB_code11.TabIndex = 25;
            this.LB_code11.Text = "<code11>12345678901</code11>";
            // 
            // LB_code93
            // 
            this.LB_code93.AutoSize = true;
            this.LB_code93.Location = new System.Drawing.Point(6, 362);
            this.LB_code93.Name = "LB_code93";
            this.LB_code93.Size = new System.Drawing.Size(153, 13);
            this.LB_code93.TabIndex = 24;
            this.LB_code93.Text = "<code93>CODE 93</code93>";
            // 
            // LB_code39
            // 
            this.LB_code39.AutoSize = true;
            this.LB_code39.Location = new System.Drawing.Point(6, 349);
            this.LB_code39.Name = "LB_code39";
            this.LB_code39.Size = new System.Drawing.Size(153, 13);
            this.LB_code39.TabIndex = 23;
            this.LB_code39.Text = "<code39>CODE 39</code39>";
            // 
            // LB_upc
            // 
            this.LB_upc.AutoSize = true;
            this.LB_upc.Location = new System.Drawing.Point(6, 336);
            this.LB_upc.Name = "LB_upc";
            this.LB_upc.Size = new System.Drawing.Size(156, 13);
            this.LB_upc.TabIndex = 22;
            this.LB_upc.Text = "<upc-a>12345678901</upc-a>";
            // 
            // LB_ean8
            // 
            this.LB_ean8.AutoSize = true;
            this.LB_ean8.Location = new System.Drawing.Point(6, 323);
            this.LB_ean8.Name = "LB_ean8";
            this.LB_ean8.Size = new System.Drawing.Size(126, 13);
            this.LB_ean8.TabIndex = 21;
            this.LB_ean8.Text = "<ean8>1234567</ean8>";
            // 
            // LB_ean13
            // 
            this.LB_ean13.AutoSize = true;
            this.LB_ean13.Location = new System.Drawing.Point(6, 310);
            this.LB_ean13.Name = "LB_ean13";
            this.LB_ean13.Size = new System.Drawing.Size(168, 13);
            this.LB_ean13.TabIndex = 20;
            this.LB_ean13.Text = "<ean13>123456789012</ean13>";
            // 
            // LB_CdBarras
            // 
            this.LB_CdBarras.AutoSize = true;
            this.LB_CdBarras.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_CdBarras.Location = new System.Drawing.Point(6, 288);
            this.LB_CdBarras.Name = "LB_CdBarras";
            this.LB_CdBarras.Size = new System.Drawing.Size(178, 13);
            this.LB_CdBarras.TabIndex = 19;
            this.LB_CdBarras.Text = "Imprimindo Codigos de Barras:";
            // 
            // LB_da
            // 
            this.LB_da.AutoSize = true;
            this.LB_da.Location = new System.Drawing.Point(6, 250);
            this.LB_da.Name = "LB_da";
            this.LB_da.Size = new System.Drawing.Size(195, 13);
            this.LB_da.TabIndex = 18;
            this.LB_da.Text = "Duplica a Altura do caracter <da></da>";
            // 
            // LB_ad
            // 
            this.LB_ad.AutoSize = true;
            this.LB_ad.Location = new System.Drawing.Point(6, 237);
            this.LB_ad.Name = "LB_ad";
            this.LB_ad.Size = new System.Drawing.Size(152, 13);
            this.LB_ad.TabIndex = 17;
            this.LB_ad.Text = "Alinhando a Direita <ad></ad>";
            // 
            // LB_fe
            // 
            this.LB_fe.AutoSize = true;
            this.LB_fe.Location = new System.Drawing.Point(6, 263);
            this.LB_fe.Name = "LB_fe";
            this.LB_fe.Size = new System.Drawing.Size(207, 13);
            this.LB_fe.TabIndex = 17;
            this.LB_fe.Text = "Habilita o Modo Fonte Elite <fe>texto</fe>";
            // 
            // LB_tb
            // 
            this.LB_tb.AutoSize = true;
            this.LB_tb.Location = new System.Drawing.Point(6, 224);
            this.LB_tb.Name = "LB_tb";
            this.LB_tb.Size = new System.Drawing.Size(167, 13);
            this.LB_tb.TabIndex = 16;
            this.LB_tb.Text = "Usando as Tabulacoes <tb></tb>";
            // 
            // LB_a
            // 
            this.LB_a.AutoSize = true;
            this.LB_a.Location = new System.Drawing.Point(6, 211);
            this.LB_a.Name = "LB_a";
            this.LB_a.Size = new System.Drawing.Size(213, 13);
            this.LB_a.TabIndex = 15;
            this.LB_a.Text = "Aguardar o Termino da Impress�o: <a></a>";
            // 
            // LB_g
            // 
            this.LB_g.AutoSize = true;
            this.LB_g.Location = new System.Drawing.Point(6, 198);
            this.LB_g.Name = "LB_g";
            this.LB_g.Size = new System.Drawing.Size(170, 13);
            this.LB_g.TabIndex = 14;
            this.LB_g.Text = "Abrir Gaveta de Dinheiro: <g></g>";
            // 
            // LB_sn
            // 
            this.LB_sn.AutoSize = true;
            this.LB_sn.Location = new System.Drawing.Point(6, 185);
            this.LB_sn.Name = "LB_sn";
            this.LB_sn.Size = new System.Drawing.Size(157, 13);
            this.LB_sn.TabIndex = 13;
            this.LB_sn.Text = "Sinal Sonoro, Apitar: <sn></sn>";
            // 
            // LB_sp
            // 
            this.LB_sp.AutoSize = true;
            this.LB_sp.Location = new System.Drawing.Point(6, 172);
            this.LB_sp.Name = "LB_sp";
            this.LB_sp.Size = new System.Drawing.Size(206, 13);
            this.LB_sp.TabIndex = 12;
            this.LB_sp.Text = "Inserir Espa�os em Branco: <sp>NN</sp>";
            // 
            // LB_hr
            // 
            this.LB_hr.AutoSize = true;
            this.LB_hr.Location = new System.Drawing.Point(6, 159);
            this.LB_hr.Name = "LB_hr";
            this.LB_hr.Size = new System.Drawing.Size(148, 13);
            this.LB_hr.TabIndex = 11;
            this.LB_hr.Text = "Imprimir Hora Atual: <hr></hr>";
            // 
            // LB_dt
            // 
            this.LB_dt.AutoSize = true;
            this.LB_dt.Location = new System.Drawing.Point(6, 146);
            this.LB_dt.Name = "LB_dt";
            this.LB_dt.Size = new System.Drawing.Size(148, 13);
            this.LB_dt.TabIndex = 10;
            this.LB_dt.Text = "Imprimir Data Atual: <dt></dt>";
            // 
            // LB_tc
            // 
            this.LB_tc.AutoSize = true;
            this.LB_tc.Location = new System.Drawing.Point(6, 133);
            this.LB_tc.Name = "LB_tc";
            this.LB_tc.Size = new System.Drawing.Size(244, 13);
            this.LB_tc.TabIndex = 9;
            this.LB_tc.Text = "Riscar Linha com Caracter Especifico: <tc>C</tc>";
            // 
            // LB_sl
            // 
            this.LB_sl.AutoSize = true;
            this.LB_sl.Location = new System.Drawing.Point(6, 120);
            this.LB_sl.Name = "LB_sl";
            this.LB_sl.Size = new System.Drawing.Size(256, 13);
            this.LB_sl.TabIndex = 8;
            this.LB_sl.Text = "Saltar varias Linhas: <sl>NN</sl>Saltar varias Linhas";
            // 
            // LB_l
            // 
            this.LB_l.AutoSize = true;
            this.LB_l.Location = new System.Drawing.Point(6, 107);
            this.LB_l.Name = "LB_l";
            this.LB_l.Size = new System.Drawing.Size(216, 13);
            this.LB_l.TabIndex = 7;
            this.LB_l.Text = "Saltar uma Linha: <l></l>Salto de uma Linha";
            // 
            // LB_n
            // 
            this.LB_n.AutoSize = true;
            this.LB_n.Location = new System.Drawing.Point(6, 94);
            this.LB_n.Name = "LB_n";
            this.LB_n.Size = new System.Drawing.Size(150, 13);
            this.LB_n.TabIndex = 6;
            this.LB_n.Text = "Texto Normal: <n>Normal</n>";
            // 
            // LB_c
            // 
            this.LB_c.AutoSize = true;
            this.LB_c.Location = new System.Drawing.Point(6, 81);
            this.LB_c.Name = "LB_c";
            this.LB_c.Size = new System.Drawing.Size(204, 13);
            this.LB_c.TabIndex = 5;
            this.LB_c.Text = "Texto Condensado: <c>Condensado</c>";
            // 
            // LB_e
            // 
            this.LB_e.AutoSize = true;
            this.LB_e.Location = new System.Drawing.Point(6, 68);
            this.LB_e.Name = "LB_e";
            this.LB_e.Size = new System.Drawing.Size(184, 13);
            this.LB_e.TabIndex = 4;
            this.LB_e.Text = "Texto Expandido: <e>Expandido</e>";
            // 
            // LB_s
            // 
            this.LB_s.AutoSize = true;
            this.LB_s.Location = new System.Drawing.Point(6, 55);
            this.LB_s.Name = "LB_s";
            this.LB_s.Size = new System.Drawing.Size(205, 13);
            this.LB_s.TabIndex = 3;
            this.LB_s.Text = "Texto em Sublinhado: <s>Sublinhado</s>";
            // 
            // LB_i
            // 
            this.LB_i.AutoSize = true;
            this.LB_i.Location = new System.Drawing.Point(6, 42);
            this.LB_i.Name = "LB_i";
            this.LB_i.Size = new System.Drawing.Size(149, 13);
            this.LB_i.TabIndex = 2;
            this.LB_i.Text = "Texto em Italico: <i>Italico</i>";
            // 
            // LB_b
            // 
            this.LB_b.AutoSize = true;
            this.LB_b.Location = new System.Drawing.Point(6, 29);
            this.LB_b.Name = "LB_b";
            this.LB_b.Size = new System.Drawing.Size(169, 13);
            this.LB_b.TabIndex = 1;
            this.LB_b.Text = "Texto em Negrito: <b>Negrito</b>";
            // 
            // LB_ce
            // 
            this.LB_ce.AutoSize = true;
            this.LB_ce.Location = new System.Drawing.Point(6, 16);
            this.LB_ce.Name = "LB_ce";
            this.LB_ce.Size = new System.Drawing.Size(211, 13);
            this.LB_ce.TabIndex = 0;
            this.LB_ce.Text = "Texto centralizado: <ce>Centralizado</ce>";
            // 
            // BT_Completo
            // 
            this.BT_Completo.Location = new System.Drawing.Point(15, 438);
            this.BT_Completo.Name = "BT_Completo";
            this.BT_Completo.Size = new System.Drawing.Size(96, 26);
            this.BT_Completo.TabIndex = 2;
            this.BT_Completo.Text = "Teste (Completo)";
            this.BT_Completo.UseVisualStyleBackColor = true;
            this.BT_Completo.Click += new System.EventHandler(this.BT_Completo_Click);
            // 
            // BT_CompletoSeparado
            // 
            this.BT_CompletoSeparado.Location = new System.Drawing.Point(174, 438);
            this.BT_CompletoSeparado.Name = "BT_CompletoSeparado";
            this.BT_CompletoSeparado.Size = new System.Drawing.Size(105, 26);
            this.BT_CompletoSeparado.TabIndex = 3;
            this.BT_CompletoSeparado.Text = "Teste (Separado)";
            this.BT_CompletoSeparado.UseVisualStyleBackColor = true;
            this.BT_CompletoSeparado.Click += new System.EventHandler(this.BT_CompletoSeparado_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(174, 471);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(105, 26);
            this.BT_Fechar.TabIndex = 4;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(15, 471);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(96, 26);
            this.BT_Enviar.TabIndex = 5;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // LB_Code128
            // 
            this.LB_Code128.AutoSize = true;
            this.LB_Code128.Location = new System.Drawing.Point(6, 427);
            this.LB_Code128.Name = "LB_Code128";
            this.LB_Code128.Size = new System.Drawing.Size(236, 13);
            this.LB_Code128.TabIndex = 31;
            this.LB_Code128.Text = "<code128>123456789123-A-B-*_%-&</code128>";
            // 
            // LB_i2of5
            // 
            this.LB_i2of5.AutoSize = true;
            this.LB_i2of5.Location = new System.Drawing.Point(6, 441);
            this.LB_i2of5.Name = "LB_i2of5";
            this.LB_i2of5.Size = new System.Drawing.Size(106, 13);
            this.LB_i2of5.TabIndex = 32;
            this.LB_i2of5.Text = "<i2of5>1234</i2of5>";
            // 
            // LB_s2of5
            // 
            this.LB_s2of5.AutoSize = true;
            this.LB_s2of5.Location = new System.Drawing.Point(6, 454);
            this.LB_s2of5.Name = "LB_s2of5";
            this.LB_s2of5.Size = new System.Drawing.Size(136, 13);
            this.LB_s2of5.TabIndex = 33;
            this.LB_s2of5.Text = "<s2of5>12345678</s2of5>";
            // 
            // FR_metodo_iImprimirTexto_DUAL_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 531);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_CompletoSeparado);
            this.Controls.Add(this.BT_Completo);
            this.Controls.Add(this.GB_TAGS);
            this.Controls.Add(this.GB_TextoImprimir);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_metodo_iImprimirTexto_DUAL_DarumaFramework";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "M�todo iImprimirTexto_DUAL_DarumaFramework                                       " +
                "  Daruma DDC";
            this.GB_TextoImprimir.ResumeLayout(false);
            this.GB_TextoImprimir.PerformLayout();
            this.GB_TAGS.ResumeLayout(false);
            this.GB_TAGS.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox GB_TextoImprimir;
        private System.Windows.Forms.TextBox TB_Texto;
        private System.Windows.Forms.GroupBox GB_TAGS;
        private System.Windows.Forms.Button BT_Completo;
        private System.Windows.Forms.Button BT_CompletoSeparado;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label LB_gui;
        private System.Windows.Forms.Label LB_bmp;
        private System.Windows.Forms.Label LB_Comandos;
        private System.Windows.Forms.Label LB_pdf;
        private System.Windows.Forms.Label LB_msi;
        private System.Windows.Forms.Label LB_codabar;
        private System.Windows.Forms.Label LB_code11;
        private System.Windows.Forms.Label LB_code93;
        private System.Windows.Forms.Label LB_code39;
        private System.Windows.Forms.Label LB_upc;
        private System.Windows.Forms.Label LB_ean8;
        private System.Windows.Forms.Label LB_ean13;
        private System.Windows.Forms.Label LB_CdBarras;
        private System.Windows.Forms.Label LB_da;
        private System.Windows.Forms.Label LB_ad;
        private System.Windows.Forms.Label LB_fe;
        private System.Windows.Forms.Label LB_tb;
        private System.Windows.Forms.Label LB_a;
        private System.Windows.Forms.Label LB_g;
        private System.Windows.Forms.Label LB_sn;
        private System.Windows.Forms.Label LB_sp;
        private System.Windows.Forms.Label LB_hr;
        private System.Windows.Forms.Label LB_dt;
        private System.Windows.Forms.Label LB_tc;
        private System.Windows.Forms.Label LB_sl;
        private System.Windows.Forms.Label LB_l;
        private System.Windows.Forms.Label LB_n;
        private System.Windows.Forms.Label LB_c;
        private System.Windows.Forms.Label LB_e;
        private System.Windows.Forms.Label LB_s;
        private System.Windows.Forms.Label LB_i;
        private System.Windows.Forms.Label LB_b;
        private System.Windows.Forms.Label LB_ce;
        private System.Windows.Forms.Label LB_s2of5;
        private System.Windows.Forms.Label LB_i2of5;
        private System.Windows.Forms.Label LB_Code128;
    }
}