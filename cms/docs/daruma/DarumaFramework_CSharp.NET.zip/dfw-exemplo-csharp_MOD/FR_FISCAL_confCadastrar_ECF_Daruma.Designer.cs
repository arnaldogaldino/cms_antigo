﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_confCadastrar_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Valor = new System.Windows.Forms.TextBox();
            this.CBO_TipoCadastro = new System.Windows.Forms.ComboBox();
            this.TB_Separador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(182, 93);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 29;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(101, 93);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 28;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 27;
            this.label2.Text = "Valor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Tipo Cadastro:";
            // 
            // TB_Valor
            // 
            this.TB_Valor.Location = new System.Drawing.Point(91, 41);
            this.TB_Valor.Name = "TB_Valor";
            this.TB_Valor.Size = new System.Drawing.Size(100, 20);
            this.TB_Valor.TabIndex = 25;
            this.TB_Valor.Text = "T05,00";
            // 
            // CBO_TipoCadastro
            // 
            this.CBO_TipoCadastro.FormattingEnabled = true;
            this.CBO_TipoCadastro.Items.AddRange(new object[] {
            "ALIQUOTA",
            "TNF",
            "RG",
            "FPGTO"});
            this.CBO_TipoCadastro.Location = new System.Drawing.Point(91, 14);
            this.CBO_TipoCadastro.Name = "CBO_TipoCadastro";
            this.CBO_TipoCadastro.Size = new System.Drawing.Size(121, 21);
            this.CBO_TipoCadastro.TabIndex = 24;
            this.CBO_TipoCadastro.Text = "Aliquota";
            // 
            // TB_Separador
            // 
            this.TB_Separador.Location = new System.Drawing.Point(91, 67);
            this.TB_Separador.Name = "TB_Separador";
            this.TB_Separador.Size = new System.Drawing.Size(100, 20);
            this.TB_Separador.TabIndex = 25;
            this.TB_Separador.Text = "|";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Separador:";
            // 
            // FR_FISCAL_confCadastrar_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(262, 123);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Separador);
            this.Controls.Add(this.TB_Valor);
            this.Controls.Add(this.CBO_TipoCadastro);
            this.Name = "FR_FISCAL_confCadastrar_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "confCadastrar_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Valor;
        private System.Windows.Forms.ComboBox CBO_TipoCadastro;
        private System.Windows.Forms.TextBox TB_Separador;
        private System.Windows.Forms.Label label3;
    }
}