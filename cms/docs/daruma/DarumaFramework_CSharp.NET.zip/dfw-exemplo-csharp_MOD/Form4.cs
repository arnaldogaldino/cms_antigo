﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_DLL;

namespace DarumaDarumaFramework_Declaracoes_CSharp
{
    public partial class Form4 : Form
    {
        DateTime TimeInicial; //recebe a hora inicial que foi iniciado o cupom
        DateTime TimeFinal; //recebe a hora final do cupom
        TimeSpan TempoCupom; //Recebe TimeInicial-TimeFinal

        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
                string Str_NumeroItens;
                int iRetorno;
                int Int_Qtd_Itens; //Guarda a Quantidade de Item desejado
                

                Str_NumeroItens = TB_NumeroItem.Text.Trim();

                if (Str_NumeroItens.Equals(string.Empty))
                {
                    MessageBox.Show("É Necessário que o campo quantidade item seja preenchido!");

                }
                else
                {              

                     iRetorno = DarumaFramework_Declaracoes_CSharp.regAlterarValor_Daruma("ECF\\CF\\ModoPreVenda", "1");
                    long Int_Codigo = 1234567890;

                    TimeInicial = DateTime.Now;
                    
                         Int_Qtd_Itens = int.Parse(TB_NumeroItem.Text.Trim());
                        //AbreCupom
                        DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_Declaracoes_CSharp.iCFAbrirPadrao_ECF_Daruma();
                        for (int i = 1; i <= Int_Qtd_Itens;i++ )  //Laço que faz a venda dos itens
                        {
                            //Vende Item
                            DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iCFVenderResumido_ECF_Daruma("F1", "1,00", Int_Codigo.ToString(), "Item" + i.ToString() + "Teste Venda" + i.ToString());
                            Int_Codigo = Int_Codigo + 1;
                        }

                        DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_Declaracoes_CSharp.iCFTotalizarCupomPadrao_ECF_Daruma();
                        DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_Declaracoes_CSharp.iCFEfetuarPagamentoPadrao_ECF_Daruma();
                        DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_Declaracoes_CSharp.iCFEncerrarPadrao_ECF_Daruma();

                    }
                TimeFinal = DateTime.Now;
                TempoCupom = TimeFinal.Subtract(TimeInicial);
                iRetorno = DarumaFramework_Declaracoes_CSharp.regAlterarValor_Daruma("ECF\\CF\\ModoPreVenda", "0");
                MessageBox.Show("Tempo emitindo o cupom: " + TempoCupom.ToString(), "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                   DarumaFramework_Declaracoes_CSharp.DarumaFramework_Mostrar_Retorno(DarumaFramework_Declaracoes_CSharp.iRetorno);

                }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
        }

    }

