﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rRetornarInformacaoSeparador_ECF_Daruma : Form
    {
        public FR_FISCAL_rRetornarInformacaoSeparador_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Str_indice;
            string Str_VSignificativo;
            StringBuilder Str_Informacao = new StringBuilder(2200);
            
            Str_indice = TB_Indice.Text.Trim();
            Str_VSignificativo = TB_ValorSignificativo.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.rRetornarInformacaoSeparador_ECF_Daruma(Str_indice, Str_VSignificativo, Str_Informacao);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            TB_Retorno.Text = Str_Informacao.ToString().Trim();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
