﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFBPAbrir_ECF_Daruma : Form
    {
        public FR_FISCAL_iCFBPAbrir_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Origem, Str_Destino, Str_Destino_UF,
                    Str_Percurso, Str_Prestadora, Str_Plataforma, Str_Poltrona,
                    Str_Modalidade, Str_Categoria, Str_DataHora_Embarque,
                    Str_RGPassageiro, Str_NomePassageiro, Str_EnderecoPassageiro;

            Str_Origem = TB_Origem.Text.Trim();// Str_Origem_UF = TB_Origem_UF.Text.Trim();
            Str_Destino = TB_Destino.Text.Trim();
            Str_Destino_UF = TB_Destino_UF.Text.Trim();
            Str_Percurso = TB_Percurso.Text.Trim();
            Str_Prestadora = TB_Prestadora.Text.Trim();
            Str_Plataforma = TB_Plataforma.Text.Trim();
            Str_Poltrona = TB_Poltrona.Text.Trim();
            Str_Modalidade = (CBO_Modalidade.SelectedIndex + 1).ToString();
            Str_Categoria = (CBO_Categoria.SelectedIndex + 2).ToString();
            Str_DataHora_Embarque = TB_DataHora_Embarque.Text.Trim();
            Str_RGPassageiro = TB_RGPassageiro.Text.Trim();
            Str_NomePassageiro = TB_NomePassageiro.Text.Trim();
            Str_EnderecoPassageiro = TB_EnderecoPassageiro.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCFBPAbrir_ECF_Daruma(
                //Parametros do metodo
                   Str_Origem, Str_Destino, Str_Destino_UF,
                   Str_Percurso, Str_Prestadora, Str_Plataforma, Str_Poltrona,
                   Str_Modalidade, Str_Categoria, Str_DataHora_Embarque,
                   Str_RGPassageiro, Str_NomePassageiro, Str_EnderecoPassageiro);

            Declaracoes.TrataRetorno(Declaracoes.iRetorno);



        }
    }
}
