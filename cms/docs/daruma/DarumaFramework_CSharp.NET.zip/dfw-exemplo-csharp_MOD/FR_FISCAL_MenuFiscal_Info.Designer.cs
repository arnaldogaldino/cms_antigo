﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_MenuFiscal_Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FR_FISCAL_MenuFiscal_Info));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.BT_Voltar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(491, 307);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // BT_Voltar
            // 
            this.BT_Voltar.Location = new System.Drawing.Point(428, 325);
            this.BT_Voltar.Name = "BT_Voltar";
            this.BT_Voltar.Size = new System.Drawing.Size(75, 23);
            this.BT_Voltar.TabIndex = 1;
            this.BT_Voltar.Text = "Voltar";
            this.BT_Voltar.UseVisualStyleBackColor = true;
            this.BT_Voltar.Click += new System.EventHandler(this.BT_Voltar_Click);
            // 
            // FR_FISCAL_MenuFiscal_Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 357);
            this.Controls.Add(this.BT_Voltar);
            this.Controls.Add(this.textBox1);
            this.Name = "FR_FISCAL_MenuFiscal_Info";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FR_FISCAL_MenuFiscal_Info";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button BT_Voltar;
    }
}