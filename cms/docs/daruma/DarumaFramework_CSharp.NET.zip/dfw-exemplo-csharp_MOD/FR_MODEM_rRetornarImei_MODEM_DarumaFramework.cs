﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rRetornarImei_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rRetornarImei_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_IMEI.Clear();
        }

        private void BT_IMEI_Click(object sender, EventArgs e)
        {
            StringBuilder sImei = new StringBuilder();
            
            Declaracoes.iRetorno = Declaracoes.rRetornarImei_MODEM_DarumaFramework(sImei); 
            
             if (Declaracoes.iRetorno == 1)
             {
                 TB_IMEI.Text = sImei.ToString();
             }
             else
             {
                 MessageBox.Show("Erro ao tentar obter o imei", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                 switch (Declaracoes.iRetorno)
                 {
                     case -3: TB_IMEI.Text = "[-3] - Modem retornou caractere(s) inválido(s)";
                         break;
                     case -2: TB_IMEI.Text = "[-2] - Modem retornou erro";
                         break;
                     case -1: TB_IMEI.Text = "[-1] - Erro de comunicação serial";
                         break;
                 }
             }
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
