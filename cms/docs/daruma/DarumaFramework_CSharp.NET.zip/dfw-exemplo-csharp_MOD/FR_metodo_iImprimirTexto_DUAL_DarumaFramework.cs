using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_metodo_iImprimirTexto_DUAL_DarumaFramework : Form
    {
        public FR_metodo_iImprimirTexto_DUAL_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            string iTextoVazio;

            if (TB_Texto.Text == string.Empty)
            {
                MessageBox.Show("Digite um Texto!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            else
            {
                iTextoVazio = TB_Texto.Text;
                Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework(iTextoVazio, 0);
                if (Declaracoes.iRetorno == 1)
                {
                    MessageBox.Show("Impress�o realizada com sucesso.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }         
                    else
                    MessageBox.Show("Erro ao Imprimir o texto, verifique a impressora!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
        
            }
            

        }

        private void BT_CompletoSeparado_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sn><e><b>Teste Formata��o DHTM</b></e></sn>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<n>Estes s�o os car�cteres que voc� poder� utilizar<n><l>Voc� poder� a qualquer monento combinar as formata��es!!", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<b>><</b>> Para sinalizar Negrito", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<i>><</i>> Para sinalizar It�lico", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<s>><</s>> Para sinalizar Sublinhado", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<e>><</e>> Para sinalizar Expandido", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<c>><</c>> Para sinalizar Condensado", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<n>><</n>> Para sinalizar Normal", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<l>><</l>> Para Saltar Uma Linha", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<ad>><</ad>> Para alinhar a direita", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<ft>>n1,n2,...,n6<</ft>> Para habilitar tabula��o", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<tb>><</tb>> Para saltar at� a proxima tabula��o", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<sl>>NN<</sl>> Para Saltar V�rias Linhas", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<tc>>C<</tc>>Riscar Linha com Car�cter Espec�fico", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<ce>><</ce>> Para Centralizar", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<dt>><</dt>> Para Imprimir Data Atual", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<hr>><</hr>> Para Imprimir Hora Atual", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<sp>>NN<</sp>> Inserir NN Espa�os em Branco", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<sn>><</sn>> Sinal Sonoro, Apitar", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<g>><</g>> Abre a Gaveta", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<a>><</a>> Aguardar at� o T�rmino da Impress�o", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<tc>>_<</tc>> Gerar uma linha tachada", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sl>01</sl>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<e>TABULA��O</e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ft>05,10,15,20,30,40</ft>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>5</tb><tb>10</tb><tb>15</tb><tb>20</tb><tb>30</tb><tb>40</tb>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>5</tb><tb>10</tb><tb>15</tb><tb>20</tb><tb>30</tb><tb>40</tb>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>5</tb><tb>10</tb><tb>15</tb><tb>20</tb><tb>30</tb><tb>40</tb>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb>5</tb><tb>10</tb><tb>15</tb><tb>20</tb><tb>30</tb><tb>40</tb>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("Data<tb>Veiculo<tb>Cor<tb>Placa<tb>Hora", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<dt></dt><tb>Golf<tb>Branca<tb>AJY5231<tb>10:15</tb>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<dt></dt><tb>Focus<tb></tb>Vermelha<tb></tb>APG2013<tb></tb>13:45", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<dt></dt><tb></tb>Megane<tb></tb>Cinza<tb></tb>AAR5414<tb></tb>14:30", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<dt></dt><tb></tb>Corsa<tb></tb>Preto<tb></tb>AWK0189<tb></tb>20:40", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><tc>_</tc>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><e>DATA:<dt></dt></e><l></l><e>Hora:<hr></hr></e><l></l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>Anvan�ando 3 Linhas</ce><sl>3</sl>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>Anvan�ando 1 Linha</ce><sl>1</sl>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l>Inserindo</l><sp>10</sp>10 espa�os em Branco", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>Formata��o Normal</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><n>DARUMA AUTOMA��O!!</n></l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGR+ITAL+SUBL+EXPAND</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><i><s><e>DARUMA AUTOMA��O!!</b></i></s></e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGR+ITAL+SUBL+CONDENSADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><i><s><c>DARUMA AUTOMA��O!!</b></i></s></c>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGR+ITAL+SUBL+NORMAL</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><i><s><n>DARUMA AUTOMA��O!!</b></i></s></n>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<e>DARUMA AUTOMA��O!!<e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>CONDENSADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<c>CONDENSADO</c>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>DARUMA AUTOMA��O!!</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGRITO+EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><e>DARUMA AUTOMA��O!!</b></e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>IT�LICO+EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<i><e>DARUMA AUTOMA��O!!</i></e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><dt></dt>SUBLINHADO+EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<fe>Ativa o modo Fonte Elite</fe>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<s><e>DARUMA AUTOMA��O!!</s></e>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGRITO+CONDENSADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><c>DARUMA AUTOMA��O!!</b></c>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>IT�LICO+CONDENSADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<i><c>DARUMA AUTOMA��O!!</i></c>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>SUBLINHADO+CONDENSADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<s><c>DARUMA AUTOMA��O!!</s></c>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>NEGRITO+NORMAL</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<b><n>DARUMA AUTOMA��O!!</b></n>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>IT�LICO+NORMAL</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><i><n>DARUMA AUTOMA��O!!</i></n></l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>SUBLINHADO+NORMAL</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<s><n>DARUMA AUTOMA��O!!</s></n><l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>ALINHADO A DIREITA</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ad>DARUMA AUTOMA��O!!</ad><l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>ALINHADO A DIREITA + EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<e><ad>DARUMA AUTOMA��O!!</ad></e><l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>ALINHADO A DIREITA + SUBLINHADO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ad><s>DARUMA AUTOMA��O!!</s></ad><l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>CENTRALIZADO + EXPANDIDO</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<e><ce>DARUMA AUTOMA��O!!</ce></e><l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ft>05,10,15,20,30,40</ft>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>TABULADO NA COLUNA 10</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb></tb><tb></tb>DARUMA<l>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce>TABULADO NA COLUNA 30</ce>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<tb></tb><tb></tb><tb></tb><tb></tb><tb></tb>DARUMA", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<n><e>C�digos de Barras</e></n>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ean13>123456789012</ean13><ean8>1234567</ean8>" +
            "<upc-a>12345678901</upc-a><code39>CODE 39</code39><code93>CODE 93</code93>" +
            "<codabar>CODABAR</codabar><msi>123456789</msi><code11>12345678901</code11><pdf>1234</pdf>", 0);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro ao realizar a impress�o das TAGS!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void BT_Completo_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><e><b>BUFFER COMPLETO</e></b>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<<e>>DATA:<<dt>><</dt>><</e>><<l>><<l/>><<e>>Hora:<<hr>><</hr>><</e>><<l>><<l/>><<ce>>" +
            "Anvan�ando 5 Linhas<</ce>><<sl>>5<</sl>>Inserindo<<sp>>10<</sp>>10 espa�os em Branco<<l>>" +
            "<<ce>>Formata��o Normal<</ce>><<n>>DARUMA AUTOMA��O!!<</n>><<l>><<ce>>NEGR+ITAL+SUBL+EXPAND<</ce>>" +
            "<<b>><<i>><<s>><<e>>DARUMA AUTOMA��O!!<</b>><</i>><</s>><</e>><<l>><<ce>>NEGR+ITAL+SUBL+CONDENSADO<</ce>>" +
            "<<b>><<i>><<s>><<c>>DARUMA AUTOMA��O!!<</b>><</i>><</s>><</c>><<l>><<ce>>NEGR+ITAL+SUBL+NORMAL<</ce>><<b>>" +
            "<<i>><<s>><<n>>DARUMA AUTOMA��O!!<</b>><</i>><</s>><</n>><<l>><<ce>>EXPANDIDO<</ce>><<e>>DARUMA AUTOMA��O!!" +
            "<<e>><<l>><<ce>>CONDENSADO<</ce>><<c>>DARUMA AUTOMA��O!!<</c>><<l>><<ce>>NEGRITO+EXPANDIDO<</ce>><<b>><<e>>DARUMA AUTOMA��O!!" +
            "<</b>><</e>><<l>><<ce>>It�lico+EXPANDIDO<</ce>><<i>><<e>>DARUMA AUTOMA��O!!<</i>><</e>><<l>><<ce>>SUBLINHADO+EXPANDIDO<</ce>>" +
            "<<s>><<e>>DARUMA AUTOMA��O!!<</s>><</e>><<l>><<ce>>NEGRITO+CONDENSADO<</ce>><<b>><<c>>DARUMA AUTOMA��O!!<</b>><</c>><<l>>" +
            "<<ce>>It�lico+CONDENSADO<</ce>><<i>><<c>>DARUMA AUTOMA��O!!<</i>><</c>><<l>><<ce>>SUBLINHADO+CONDENSADO<</ce>><<s>><<c>>" +
            "DARUMA AUTOMA��O!!<</s>><</c>><<l>><<ce>>NEGRITO+NORMAL<</ce>><<b>><<n>>DARUMA AUTOMA��O!!<</b>><</n>><<l>><<ce>>It�lico+NORMAL" +
            "<</ce>><<l>><<i>><<n>>DARUMA AUTOMA��O!!<</i>><</n>><<l>><<ce>>SUBLINHADO+NORMAL<</ce>><<s>><<n>>DARUMA AUTOMA��O!!<</s>><</n>>" +
            "<<l>><<ce>>ALINHADO A DIREITA<</ce>><<ad>>DARUMA AUTOMA��O!!<</ad>><<l>><<ce>>ALINHADO A DIREITA + EXPANDIDO<</ce>>" +
            "<<e>><<ad>>DARUMA AUTOMA��O!!<</ad>><</e>><<l>><<ce>>ALINHADO A DIREITA + SUBLINHADO<</ce>><<ad>><<s>>DARUMA AUTOMA��O!!<</s>><</ad>>" +
            "<<l>><<ce>>CENTRALIZADO + EXPANDIDO<</ce>><<e>><<ce>>DARUMA AUTOMA��O!!<</ce>><</e>><<l>><<ce>>TABULADO NA COLUNA 10<</ce>> <<tb>><</tb>>" +
            " <<tb>><</tb>>DARUMA<<l>><<ce>>TABULADO NA COLUNA 30<</ce>> <<tb>><</tb>> <<tb>><</tb>> <<tb>><</tb>> <<tb>><</tb>> <<tb>><</tb>>DARUMA<<sl>>10<</sl>>" +
            "<<ean13>>123456789012<</ean13>><<ean8>>1234567<</ean8>><<upc-a>>12345678901<</upc-a>><<code39>>CODE 39<</code39>><<code93>>CODE 93<</code93>>" +
            "<<codabar>>CODABAR<</codabar>><<msi>>123456789<</msi>><<code11>>12345678901<</code11>><<pdf>>1234<<pdf>>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<fe>Ativa o modo Fonte Elite</fe>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<l><e><b>FIM BUFFER COMPLETO</e></b>", 0);
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sl>03</sl>", 0);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro ao realizar a impress�o das TAGS!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}