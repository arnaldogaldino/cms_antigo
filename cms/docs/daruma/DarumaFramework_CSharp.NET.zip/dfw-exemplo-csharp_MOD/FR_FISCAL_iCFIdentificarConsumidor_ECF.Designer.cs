﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFIdentificarConsumidor_ECF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Endereço = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Nome = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Documento = new System.Windows.Forms.TextBox();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Informe os dados do consumidor:";
            // 
            // TB_Endereço
            // 
            this.TB_Endereço.Location = new System.Drawing.Point(84, 102);
            this.TB_Endereço.Name = "TB_Endereço";
            this.TB_Endereço.Size = new System.Drawing.Size(347, 20);
            this.TB_Endereço.TabIndex = 16;
            this.TB_Endereço.Text = "Av. Shishima Hifumi, 2911. 4 andar - Sala. 406  - São José dos Campos - São Paulo" +
                "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Endereço:";
            // 
            // TB_Nome
            // 
            this.TB_Nome.Location = new System.Drawing.Point(84, 45);
            this.TB_Nome.Name = "TB_Nome";
            this.TB_Nome.Size = new System.Drawing.Size(347, 20);
            this.TB_Nome.TabIndex = 14;
            this.TB_Nome.Text = "Daruma Developer Community";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Nome:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Documento:";
            // 
            // TB_Documento
            // 
            this.TB_Documento.Location = new System.Drawing.Point(84, 73);
            this.TB_Documento.Name = "TB_Documento";
            this.TB_Documento.Size = new System.Drawing.Size(347, 20);
            this.TB_Documento.TabIndex = 11;
            this.TB_Documento.Text = "123.123.123-99";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(356, 130);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 10;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(275, 130);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 9;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // FR_FISCAL_iCFIdentificarConsumidor_ECF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 163);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_Endereço);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TB_Nome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Documento);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_iCFIdentificarConsumidor_ECF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iCFIdentificarConsumidor_ECF";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_Endereço;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Nome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Documento;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
    }
}