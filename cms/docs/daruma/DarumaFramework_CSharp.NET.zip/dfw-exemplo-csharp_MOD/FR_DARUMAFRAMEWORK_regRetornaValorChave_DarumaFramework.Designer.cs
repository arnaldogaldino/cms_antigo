namespace DarumaFramework_CSharp
{
    partial class FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Produto = new System.Windows.Forms.Label();
            this.TB_Produto = new System.Windows.Forms.TextBox();
            this.LB_Chave = new System.Windows.Forms.Label();
            this.TB_Chave = new System.Windows.Forms.TextBox();
            this.LB_Valor = new System.Windows.Forms.Label();
            this.TB_Valor = new System.Windows.Forms.TextBox();
            this.GB_Produtos = new System.Windows.Forms.GroupBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.LB_TA2000 = new System.Windows.Forms.Label();
            this.LB_DUAL = new System.Windows.Forms.Label();
            this.LB_Modem = new System.Windows.Forms.Label();
            this.LB_ECF = new System.Windows.Forms.Label();
            this.GB_Produtos.SuspendLayout();
            this.SuspendLayout();
            // 
            // LB_Produto
            // 
            this.LB_Produto.AutoSize = true;
            this.LB_Produto.Location = new System.Drawing.Point(2, 9);
            this.LB_Produto.Name = "LB_Produto";
            this.LB_Produto.Size = new System.Drawing.Size(199, 13);
            this.LB_Produto.TabIndex = 0;
            this.LB_Produto.Text = "Informe abaixo qual produto ira trabalhar:";
            // 
            // TB_Produto
            // 
            this.TB_Produto.Location = new System.Drawing.Point(5, 26);
            this.TB_Produto.Name = "TB_Produto";
            this.TB_Produto.Size = new System.Drawing.Size(203, 20);
            this.TB_Produto.TabIndex = 1;
            // 
            // LB_Chave
            // 
            this.LB_Chave.AutoSize = true;
            this.LB_Chave.Location = new System.Drawing.Point(5, 53);
            this.LB_Chave.Name = "LB_Chave";
            this.LB_Chave.Size = new System.Drawing.Size(277, 13);
            this.LB_Chave.TabIndex = 2;
            this.LB_Chave.Text = "Informe a chave no qual gostaria de verificar o conteudo:";
            // 
            // TB_Chave
            // 
            this.TB_Chave.Location = new System.Drawing.Point(8, 70);
            this.TB_Chave.Name = "TB_Chave";
            this.TB_Chave.Size = new System.Drawing.Size(200, 20);
            this.TB_Chave.TabIndex = 3;
            // 
            // LB_Valor
            // 
            this.LB_Valor.AutoSize = true;
            this.LB_Valor.Location = new System.Drawing.Point(5, 97);
            this.LB_Valor.Name = "LB_Valor";
            this.LB_Valor.Size = new System.Drawing.Size(84, 13);
            this.LB_Valor.TabIndex = 4;
            this.LB_Valor.Text = "Valor resgatado:";
            // 
            // TB_Valor
            // 
            this.TB_Valor.Location = new System.Drawing.Point(8, 114);
            this.TB_Valor.Name = "TB_Valor";
            this.TB_Valor.Size = new System.Drawing.Size(100, 20);
            this.TB_Valor.TabIndex = 5;
            // 
            // GB_Produtos
            // 
            this.GB_Produtos.Controls.Add(this.LB_ECF);
            this.GB_Produtos.Controls.Add(this.LB_Modem);
            this.GB_Produtos.Controls.Add(this.LB_DUAL);
            this.GB_Produtos.Controls.Add(this.LB_TA2000);
            this.GB_Produtos.Location = new System.Drawing.Point(303, 2);
            this.GB_Produtos.Name = "GB_Produtos";
            this.GB_Produtos.Size = new System.Drawing.Size(200, 151);
            this.GB_Produtos.TabIndex = 6;
            this.GB_Produtos.TabStop = false;
            this.GB_Produtos.Text = "Nome dos Produtos:";
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(126, 112);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 7;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(207, 112);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 8;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // LB_TA2000
            // 
            this.LB_TA2000.AutoSize = true;
            this.LB_TA2000.Location = new System.Drawing.Point(17, 30);
            this.LB_TA2000.Name = "LB_TA2000";
            this.LB_TA2000.Size = new System.Drawing.Size(159, 13);
            this.LB_TA2000.TabIndex = 0;
            this.LB_TA2000.Text = "TA2000 - MiniTerminais TA2000";
            // 
            // LB_DUAL
            // 
            this.LB_DUAL.AutoSize = true;
            this.LB_DUAL.Location = new System.Drawing.Point(19, 56);
            this.LB_DUAL.Name = "LB_DUAL";
            this.LB_DUAL.Size = new System.Drawing.Size(123, 13);
            this.LB_DUAL.TabIndex = 1;
            this.LB_DUAL.Text = "DUAL - Mini-Impressoras";
            // 
            // LB_Modem
            // 
            this.LB_Modem.AutoSize = true;
            this.LB_Modem.Location = new System.Drawing.Point(20, 80);
            this.LB_Modem.Name = "LB_Modem";
            this.LB_Modem.Size = new System.Drawing.Size(161, 13);
            this.LB_Modem.TabIndex = 2;
            this.LB_Modem.Text = "MODEM - Modems MIN100/200";
            // 
            // LB_ECF
            // 
            this.LB_ECF.AutoSize = true;
            this.LB_ECF.Location = new System.Drawing.Point(20, 105);
            this.LB_ECF.Name = "LB_ECF";
            this.LB_ECF.Size = new System.Drawing.Size(138, 13);
            this.LB_ECF.TabIndex = 3;
            this.LB_ECF.Text = "FS600 - Impressoras Fiscais";
            // 
            // FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 156);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.GB_Produtos);
            this.Controls.Add(this.TB_Valor);
            this.Controls.Add(this.LB_Valor);
            this.Controls.Add(this.TB_Chave);
            this.Controls.Add(this.LB_Chave);
            this.Controls.Add(this.TB_Produto);
            this.Controls.Add(this.LB_Produto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework";
            this.Text = "M�todo regRetornaValorChave_DarumaFramework";
            this.GB_Produtos.ResumeLayout(false);
            this.GB_Produtos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_Produto;
        private System.Windows.Forms.TextBox TB_Produto;
        private System.Windows.Forms.Label LB_Chave;
        private System.Windows.Forms.TextBox TB_Chave;
        private System.Windows.Forms.Label LB_Valor;
        private System.Windows.Forms.TextBox TB_Valor;
        private System.Windows.Forms.GroupBox GB_Produtos;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Label LB_ECF;
        private System.Windows.Forms.Label LB_Modem;
        private System.Windows.Forms.Label LB_DUAL;
        private System.Windows.Forms.Label LB_TA2000;
    }
}