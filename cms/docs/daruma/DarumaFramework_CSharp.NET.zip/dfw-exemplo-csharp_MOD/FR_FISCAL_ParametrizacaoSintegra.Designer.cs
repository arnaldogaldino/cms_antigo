﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_ParametrizacaoSintegra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_NaturezaDasOperacoes = new System.Windows.Forms.TextBox();
            this.CBO_NaturezaDasOperacoes = new System.Windows.Forms.ComboBox();
            this.TB_IdentificaConvenio = new System.Windows.Forms.TextBox();
            this.CBO_IdentificaConvenio = new System.Windows.Forms.ComboBox();
            this.TB_Finalidade = new System.Windows.Forms.TextBox();
            this.CBO_Finalidade = new System.Windows.Forms.ComboBox();
            this.TB_NomeContato = new System.Windows.Forms.TextBox();
            this.TB_Fax = new System.Windows.Forms.TextBox();
            this.TB_Telefone = new System.Windows.Forms.TextBox();
            this.CBO_UF = new System.Windows.Forms.ComboBox();
            this.TB_Municipio = new System.Windows.Forms.TextBox();
            this.TB_Cep = new System.Windows.Forms.TextBox();
            this.TB_Bairro = new System.Windows.Forms.TextBox();
            this.TB_Complemento = new System.Windows.Forms.TextBox();
            this.TB_Numero = new System.Windows.Forms.TextBox();
            this.TB_Endereco = new System.Windows.Forms.TextBox();
            this.TB_Parametrizar = new System.Windows.Forms.Button();
            this.BT_Voltar = new System.Windows.Forms.Button();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TB_NaturezaDasOperacoes);
            this.groupBox1.Controls.Add(this.CBO_NaturezaDasOperacoes);
            this.groupBox1.Controls.Add(this.TB_IdentificaConvenio);
            this.groupBox1.Controls.Add(this.CBO_IdentificaConvenio);
            this.groupBox1.Controls.Add(this.TB_Finalidade);
            this.groupBox1.Controls.Add(this.CBO_Finalidade);
            this.groupBox1.Controls.Add(this.TB_NomeContato);
            this.groupBox1.Controls.Add(this.TB_Fax);
            this.groupBox1.Controls.Add(this.TB_Telefone);
            this.groupBox1.Controls.Add(this.CBO_UF);
            this.groupBox1.Controls.Add(this.TB_Municipio);
            this.groupBox1.Controls.Add(this.TB_Cep);
            this.groupBox1.Controls.Add(this.TB_Bairro);
            this.groupBox1.Controls.Add(this.TB_Complemento);
            this.groupBox1.Controls.Add(this.TB_Numero);
            this.groupBox1.Controls.Add(this.TB_Endereco);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(683, 299);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Parametrização Registry <SINTEGRA>:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 230);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Natureza das Operações:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 190);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 13);
            this.label11.TabIndex = 17;
            this.label11.Text = "Identif. do Convênio:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(86, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(58, 13);
            this.label10.TabIndex = 17;
            this.label10.Text = "Finalidade:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(410, 60);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(57, 13);
            this.label14.TabIndex = 17;
            this.label14.Text = "Município:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(321, 98);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Nome Contato:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(173, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Fax:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 97);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Telefone:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(609, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "UF:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(321, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "CEP:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Bairro:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(389, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Complemento:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(321, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Número:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Endereço:";
            // 
            // TB_NaturezaDasOperacoes
            // 
            this.TB_NaturezaDasOperacoes.Enabled = false;
            this.TB_NaturezaDasOperacoes.Location = new System.Drawing.Point(192, 228);
            this.TB_NaturezaDasOperacoes.Name = "TB_NaturezaDasOperacoes";
            this.TB_NaturezaDasOperacoes.Size = new System.Drawing.Size(467, 20);
            this.TB_NaturezaDasOperacoes.TabIndex = 15;
            // 
            // CBO_NaturezaDasOperacoes
            // 
            this.CBO_NaturezaDasOperacoes.FormattingEnabled = true;
            this.CBO_NaturezaDasOperacoes.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.CBO_NaturezaDasOperacoes.Location = new System.Drawing.Point(150, 227);
            this.CBO_NaturezaDasOperacoes.Name = "CBO_NaturezaDasOperacoes";
            this.CBO_NaturezaDasOperacoes.Size = new System.Drawing.Size(36, 21);
            this.CBO_NaturezaDasOperacoes.TabIndex = 14;
            this.CBO_NaturezaDasOperacoes.SelectedIndexChanged += new System.EventHandler(this.CBO_NaturezaDasOperacoes_SelectedIndexChanged);
            // 
            // TB_IdentificaConvenio
            // 
            this.TB_IdentificaConvenio.Enabled = false;
            this.TB_IdentificaConvenio.Location = new System.Drawing.Point(192, 190);
            this.TB_IdentificaConvenio.Name = "TB_IdentificaConvenio";
            this.TB_IdentificaConvenio.Size = new System.Drawing.Size(467, 20);
            this.TB_IdentificaConvenio.TabIndex = 13;
            // 
            // CBO_IdentificaConvenio
            // 
            this.CBO_IdentificaConvenio.FormattingEnabled = true;
            this.CBO_IdentificaConvenio.Items.AddRange(new object[] {
            "1",
            "2",
            "3"});
            this.CBO_IdentificaConvenio.Location = new System.Drawing.Point(150, 190);
            this.CBO_IdentificaConvenio.Name = "CBO_IdentificaConvenio";
            this.CBO_IdentificaConvenio.Size = new System.Drawing.Size(36, 21);
            this.CBO_IdentificaConvenio.TabIndex = 12;
            this.CBO_IdentificaConvenio.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // TB_Finalidade
            // 
            this.TB_Finalidade.Enabled = false;
            this.TB_Finalidade.Location = new System.Drawing.Point(192, 155);
            this.TB_Finalidade.Name = "TB_Finalidade";
            this.TB_Finalidade.Size = new System.Drawing.Size(467, 20);
            this.TB_Finalidade.TabIndex = 11;
            this.TB_Finalidade.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // CBO_Finalidade
            // 
            this.CBO_Finalidade.FormattingEnabled = true;
            this.CBO_Finalidade.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.CBO_Finalidade.Location = new System.Drawing.Point(150, 154);
            this.CBO_Finalidade.Name = "CBO_Finalidade";
            this.CBO_Finalidade.Size = new System.Drawing.Size(36, 21);
            this.CBO_Finalidade.TabIndex = 10;
            this.CBO_Finalidade.SelectedIndexChanged += new System.EventHandler(this.CBO_Finalidade_SelectedIndexChanged);
            // 
            // TB_NomeContato
            // 
            this.TB_NomeContato.Location = new System.Drawing.Point(324, 113);
            this.TB_NomeContato.Name = "TB_NomeContato";
            this.TB_NomeContato.Size = new System.Drawing.Size(335, 20);
            this.TB_NomeContato.TabIndex = 9;
            this.TB_NomeContato.Text = "João";
            // 
            // TB_Fax
            // 
            this.TB_Fax.Location = new System.Drawing.Point(176, 113);
            this.TB_Fax.Name = "TB_Fax";
            this.TB_Fax.Size = new System.Drawing.Size(133, 20);
            this.TB_Fax.TabIndex = 8;
            this.TB_Fax.Text = "(xx41) 3361-6945";
            // 
            // TB_Telefone
            // 
            this.TB_Telefone.Location = new System.Drawing.Point(19, 113);
            this.TB_Telefone.Name = "TB_Telefone";
            this.TB_Telefone.Size = new System.Drawing.Size(131, 20);
            this.TB_Telefone.TabIndex = 7;
            this.TB_Telefone.Text = "(XX41) 3361-6005";
            // 
            // CBO_UF
            // 
            this.CBO_UF.FormattingEnabled = true;
            this.CBO_UF.Items.AddRange(new object[] {
            "AC",
            "AL",
            "AP",
            "AM",
            "BA",
            "CE",
            "DF",
            "ES",
            "GO",
            "MA",
            "MT",
            "MS",
            "MG",
            "PA",
            "PB",
            "PR",
            "PE",
            "PI",
            "RJ",
            "RN",
            "RS",
            "RO",
            "RR",
            "SC",
            "SP",
            "SE",
            "TO"});
            this.CBO_UF.Location = new System.Drawing.Point(612, 75);
            this.CBO_UF.Name = "CBO_UF";
            this.CBO_UF.Size = new System.Drawing.Size(47, 21);
            this.CBO_UF.TabIndex = 6;
            // 
            // TB_Municipio
            // 
            this.TB_Municipio.Location = new System.Drawing.Point(413, 75);
            this.TB_Municipio.Name = "TB_Municipio";
            this.TB_Municipio.Size = new System.Drawing.Size(186, 20);
            this.TB_Municipio.TabIndex = 5;
            this.TB_Municipio.Text = "São Paulo";
            this.TB_Municipio.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // TB_Cep
            // 
            this.TB_Cep.Location = new System.Drawing.Point(324, 75);
            this.TB_Cep.Name = "TB_Cep";
            this.TB_Cep.Size = new System.Drawing.Size(71, 20);
            this.TB_Cep.TabIndex = 4;
            this.TB_Cep.Text = "80215-090";
            // 
            // TB_Bairro
            // 
            this.TB_Bairro.Location = new System.Drawing.Point(19, 74);
            this.TB_Bairro.Name = "TB_Bairro";
            this.TB_Bairro.Size = new System.Drawing.Size(290, 20);
            this.TB_Bairro.TabIndex = 3;
            this.TB_Bairro.Text = "Jardim Botânico";
            this.TB_Bairro.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // TB_Complemento
            // 
            this.TB_Complemento.Location = new System.Drawing.Point(392, 37);
            this.TB_Complemento.Name = "TB_Complemento";
            this.TB_Complemento.Size = new System.Drawing.Size(267, 20);
            this.TB_Complemento.TabIndex = 2;
            this.TB_Complemento.Text = "4º andar - Sala. 406  ";
            // 
            // TB_Numero
            // 
            this.TB_Numero.Location = new System.Drawing.Point(324, 37);
            this.TB_Numero.Name = "TB_Numero";
            this.TB_Numero.Size = new System.Drawing.Size(53, 20);
            this.TB_Numero.TabIndex = 1;
            this.TB_Numero.Text = "2911";
            // 
            // TB_Endereco
            // 
            this.TB_Endereco.Location = new System.Drawing.Point(19, 37);
            this.TB_Endereco.Name = "TB_Endereco";
            this.TB_Endereco.Size = new System.Drawing.Size(290, 20);
            this.TB_Endereco.TabIndex = 0;
            this.TB_Endereco.Text = "Avenida Shishima Hifumi,";
            // 
            // TB_Parametrizar
            // 
            this.TB_Parametrizar.Location = new System.Drawing.Point(510, 325);
            this.TB_Parametrizar.Name = "TB_Parametrizar";
            this.TB_Parametrizar.Size = new System.Drawing.Size(75, 23);
            this.TB_Parametrizar.TabIndex = 1;
            this.TB_Parametrizar.Text = "Parametrizar";
            this.TB_Parametrizar.UseVisualStyleBackColor = true;
            this.TB_Parametrizar.Click += new System.EventHandler(this.TB_Parametrizar_Click);
            // 
            // BT_Voltar
            // 
            this.BT_Voltar.Location = new System.Drawing.Point(623, 325);
            this.BT_Voltar.Name = "BT_Voltar";
            this.BT_Voltar.Size = new System.Drawing.Size(75, 23);
            this.BT_Voltar.TabIndex = 2;
            this.BT_Voltar.Text = "Voltar";
            this.BT_Voltar.UseVisualStyleBackColor = true;
            this.BT_Voltar.Click += new System.EventHandler(this.button2_Click);
            // 
            // folderBrowserDialog1
            // 
            this.folderBrowserDialog1.HelpRequest += new System.EventHandler(this.folderBrowserDialog1_HelpRequest);
            // 
            // FR_FISCAL_ParametrizacaoSintegra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 360);
            this.Controls.Add(this.BT_Voltar);
            this.Controls.Add(this.TB_Parametrizar);
            this.Controls.Add(this.groupBox1);
            this.Name = "FR_FISCAL_ParametrizacaoSintegra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FR_FISCAL_ParametrizacaoSintegra";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TB_Municipio;
        private System.Windows.Forms.TextBox TB_Cep;
        private System.Windows.Forms.TextBox TB_Bairro;
        private System.Windows.Forms.TextBox TB_Complemento;
        private System.Windows.Forms.TextBox TB_Numero;
        private System.Windows.Forms.TextBox TB_Endereco;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_NaturezaDasOperacoes;
        private System.Windows.Forms.ComboBox CBO_NaturezaDasOperacoes;
        private System.Windows.Forms.TextBox TB_IdentificaConvenio;
        private System.Windows.Forms.ComboBox CBO_IdentificaConvenio;
        private System.Windows.Forms.TextBox TB_Finalidade;
        private System.Windows.Forms.ComboBox CBO_Finalidade;
        private System.Windows.Forms.TextBox TB_NomeContato;
        private System.Windows.Forms.TextBox TB_Fax;
        private System.Windows.Forms.TextBox TB_Telefone;
        private System.Windows.Forms.ComboBox CBO_UF;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button TB_Parametrizar;
        private System.Windows.Forms.Button BT_Voltar;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}