using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_DUAL_menuTestes_LoopingStatus : Form
    {
        public FR_DUAL_menuTestes_LoopingStatus()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            TM_Status.Enabled = true;
        }

        private void BT_Stop_Click(object sender, EventArgs e)
        {
            TM_Status.Enabled = false;
            TB_Status.Clear();
        }

        private void TM_Status_Tick(object sender, EventArgs e)
        {
            
            Declaracoes.iRetorno = Declaracoes.rStatusImpressora_DUAL_DarumaFramework();

            if (Declaracoes.iRetorno == 1 | Declaracoes.iRetorno == 0 | Declaracoes.iRetorno == -27 | Declaracoes.iRetorno == -50 | Declaracoes.iRetorno == 51 | Declaracoes.iRetorno == 52)
                switch (Declaracoes.iRetorno)
                {
                    case 0: TB_Status.Text = "0(zero) - Impressora Desligada!";
                        break;
                    case 1: TB_Status.Text = "1(um) - Impressora OK!";
                        break;
                    case -50: TB_Status.Text = "-50 - Impressora OFF-LINE!";
                        break;
                    case -51: TB_Status.Text = "-51 - Impressora Sem Papel!";
                        break;
                    case -27: TB_Status.Text = "-27 - Erro Generico!";
                        break;
                    case -52: TB_Status.Text = "-52 - Impressora inicializando!";
                        break;
                }

            else
            {
                TB_Status.Text = "Retorno n�o esperado!";
            }

        }
    }
}