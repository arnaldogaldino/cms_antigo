﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCNFReceber_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_ValorDescAcresc = new System.Windows.Forms.TextBox();
            this.CBO_TipoDesc_Acresc = new System.Windows.Forms.ComboBox();
            this.TB_ValorRecebimento = new System.Windows.Forms.TextBox();
            this.CBO_IndiceTotalizador = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(67, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 112;
            this.label4.Text = "Valor Desc./Acresc.:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 13);
            this.label3.TabIndex = 111;
            this.label3.Text = "Tipo Desconto/Acréscimo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(60, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 110;
            this.label2.Text = "Valor do Recebimento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(165, 13);
            this.label1.TabIndex = 109;
            this.label1.Text = "Índice do Totalizador Não Fiscal: ";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(228, 127);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 108;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(134, 127);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 107;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_ValorDescAcresc
            // 
            this.TB_ValorDescAcresc.Location = new System.Drawing.Point(180, 91);
            this.TB_ValorDescAcresc.Name = "TB_ValorDescAcresc";
            this.TB_ValorDescAcresc.Size = new System.Drawing.Size(100, 20);
            this.TB_ValorDescAcresc.TabIndex = 106;
            this.TB_ValorDescAcresc.Text = "0,10";
            // 
            // CBO_TipoDesc_Acresc
            // 
            this.CBO_TipoDesc_Acresc.FormattingEnabled = true;
            this.CBO_TipoDesc_Acresc.Items.AddRange(new object[] {
            "D%",
            "D$",
            "A%",
            "A$"});
            this.CBO_TipoDesc_Acresc.Location = new System.Drawing.Point(180, 61);
            this.CBO_TipoDesc_Acresc.Name = "CBO_TipoDesc_Acresc";
            this.CBO_TipoDesc_Acresc.Size = new System.Drawing.Size(55, 21);
            this.CBO_TipoDesc_Acresc.TabIndex = 105;
            // 
            // TB_ValorRecebimento
            // 
            this.TB_ValorRecebimento.Location = new System.Drawing.Point(180, 35);
            this.TB_ValorRecebimento.Name = "TB_ValorRecebimento";
            this.TB_ValorRecebimento.Size = new System.Drawing.Size(100, 20);
            this.TB_ValorRecebimento.TabIndex = 104;
            this.TB_ValorRecebimento.Text = "1,00";
            // 
            // CBO_IndiceTotalizador
            // 
            this.CBO_IndiceTotalizador.FormattingEnabled = true;
            this.CBO_IndiceTotalizador.Items.AddRange(new object[] {
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.CBO_IndiceTotalizador.Location = new System.Drawing.Point(181, 8);
            this.CBO_IndiceTotalizador.Name = "CBO_IndiceTotalizador";
            this.CBO_IndiceTotalizador.Size = new System.Drawing.Size(55, 21);
            this.CBO_IndiceTotalizador.TabIndex = 103;
            // 
            // FR_FISCAL_iCNFReceber_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 152);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_ValorDescAcresc);
            this.Controls.Add(this.CBO_TipoDesc_Acresc);
            this.Controls.Add(this.TB_ValorRecebimento);
            this.Controls.Add(this.CBO_IndiceTotalizador);
            this.Name = "FR_FISCAL_iCNFReceber_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCNFReceber_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_ValorDescAcresc;
        private System.Windows.Forms.ComboBox CBO_TipoDesc_Acresc;
        private System.Windows.Forms.TextBox TB_ValorRecebimento;
        private System.Windows.Forms.ComboBox CBO_IndiceTotalizador;
    }
}