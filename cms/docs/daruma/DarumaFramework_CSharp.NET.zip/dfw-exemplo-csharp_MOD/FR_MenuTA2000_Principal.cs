using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using DFW;
using System.IO;
using System.Web.Mobile;

namespace DarumaFramework_CSharp
{
    public partial class FR_MenuTA2000_Principal : Form
    {
        public FR_MenuTA2000_Principal()
        {
            InitializeComponent();
        }

        private void MN_FecharTA2000_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void FR_MenuTA2000_Principal_Load(object sender, EventArgs e)
        {
            
            string szTexto;
            StringBuilder szRetorno=new StringBuilder();

            Microsoft.Win32.RegistryKey key;
            key = Microsoft.Win32.Registry.LocalMachine.CreateSubKey("SOFTWARE\\DarumaFramework\\TA2000");
            key.SetValue("MensagemBoasVindasLinha1", "******BEM-VINDO AO TA2000 - DARUMA******");
            key.SetValue("MensagemBoasVindasLinha2", "****www.desenvolvedoresdaruma.com.br****");
            key.Close();

            szTexto = "";
      
            Declaracoes.iRetorno = Declaracoes.iEnviarDadosFormatados_TA2000_Daruma(szTexto, szRetorno);
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void MN_ImprimirTexto_Click(object sender, EventArgs e)
        {

            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><imprimir><texto>Texto</texto><linha>2</linha><coluna>11</coluna></imprimir>";

        }

        private void MN_LimparDisplay_Click(object sender, EventArgs e)
        {

            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar>";

        }

        private void MN_Edicao_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><edicao><eco>0</eco><tipo>3</tipo><tamanho>10</tamanho><esc>-27</esc><linha>1</linha><coluna>1</coluna></edicao>";
            
        }

        private void MN_CriarMenu_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><menu><estilo>2</estilo><direcao>V</direcao><opcao1>Cadastrar Item</opcao1><opcao2>Consultar Cadastro</opcao2><opcao3>Alterar Cadastro</opcao3><opcao4>Eliminar Cadastro</opcao4></menu>";

        }

        private void MN_Mascaras_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><edicao><mascara>R$#.###,## - Nome:!!!!!!!!!!!!!!!!!</mascara></edicao>";
        
        }

        private void MN_Encerrar_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<encerrar>3</encerrar>";

        }

        private void MN_Combo_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><imprimir><texto>Artigo:1234</texto><linha>1</linha><coluna>1</coluna></imprimir><imprimir><texto>Descr:Agua sem Gas</texto><linha>1</linha><coluna>15</coluna></imprimir><imprimir><texto>Valor:1234</texto><linha>2</linha><coluna>1</coluna></imprimir><imprimir><texto>Qtda:</texto><linha>2</linha><coluna>12</coluna></imprimir><campo><valor>1</valor><tipo>3</tipo><tamanho>1</tamanho><linha>2</linha><coluna>17</coluna></campo><modocursor>2</modocursor><setfocus>1</setfocus><getdadocampo>1</getdadocampo>";

        }

        private void MN_GetDadoCampo_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";

            TB_Comando.Text = "<limpar>0</limpar><imprimir><texto>Artigo:1234</texto><linha>1</linha><coluna>1</coluna></imprimir><imprimir><texto>Descr:Agua semGas</texto><linha>1</linha><coluna>15</coluna></imprimir><imprimir><texto>Valor:1234</texto><linha>2</linha><coluna>1</coluna></imprimir><imprimir><texto>Qtda:</texto><linha>2</linha><coluna>12</coluna></imprimir><campo><valor>1</valor><tipo>3</tipo><tamanho>1</tamanho><linha>2</linha><coluna>17</coluna></campo><modocursor>2</modocursor><setfocus>1</setfocus><getdadocampo>1</getdadocampo>";

        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_Comando.Text = "";
            TB_Resultado.Text = "";
          
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            StringBuilder szRetorno=new StringBuilder();
          
            Declaracoes.iRetorno = Declaracoes.iEnviarDadosFormatados_TA2000_Daruma(TB_Comando.Text,szRetorno);
            TB_Resultado.Text = szRetorno.ToString();

            if (Declaracoes.iRetorno == 1)
                MessageBox.Show("Dados enviados com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                MessageBox.Show("Erro no envio dos dados", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            
        }

        private void MS_Geral_TA2000_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void MN_regPorta_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita a Porta de Comunica��o:", "LPT0");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regPorta_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regPorta_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMensagemBoasVindasLinha1_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita a mensagem de Boas-Vindas (1 Linha):", "*******BemVindo ao TA2000 Daruma******");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMensagemBoasVindasLinha1_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMensagemBoasVindasLinha1_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMensagemBoasVindasLinha2_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digita a mensagem de Boas-Vindas (2 Linha):", "****www.desenvolvedoresdaruma.com.br****");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMensagemBoasVindasLinha2_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMensagemBoasVindasLinha2_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMarcadorOpcao_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite a opcao para ser o Marcador do seu display:", "*");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMarcadorOpcao_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMarcadorOpcao_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMascara_TA2000_Daruma_Click_1(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite a Mascara a ser utilizada:", "");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMascara_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMascara_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMascaraLetra_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite o tipo da mascara letra a ser utilizada:", "!");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMascaraLetra_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMascaraLetra_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMascaraNumero_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite o tipo da mascara numero a ser utilizada:", "#");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMascaraNumero_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMascaraNumero_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_regMascaraEco_TA2000_Daruma_Click(object sender, EventArgs e)
        {
            string STR_Retorno_CaixaInput;

            STR_Retorno_CaixaInput = Declaracoes.InputBox("Digite o tipo da mascara eco a ser utilizada:", "0");

            if (STR_Retorno_CaixaInput != "Erro ao incluir dados no Registro(Registry)!" | Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Realizando Configura��o...", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                Declaracoes.iRetorno = Declaracoes.regMascaraEco_TA2000_Daruma(STR_Retorno_CaixaInput);
            }
            if (Declaracoes.iRetorno == 1)
            {
                Declaracoes.iRetorno = Declaracoes.regMascaraEco_TA2000_Daruma(STR_Retorno_CaixaInput);
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_DesativarAuditoria_Click(object sender, EventArgs e)
        {
            MN_DesativarAuditoria.Checked = false;
            MN_AtivarAuditoria.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regAuditoria_TA2000_Daruma("0");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_DesativarAuditoria.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_AtivarAuditoria_Click(object sender, EventArgs e)
        {
            MN_DesativarAuditoria.Checked = false;
            MN_AtivarAuditoria.Checked = false;
            Declaracoes.iRetorno = Declaracoes.regAuditoria_TA2000_Daruma("1");

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                MN_AtivarAuditoria.Checked = true;
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MN_eDefinirProduto_Daruma_Click(object sender, EventArgs e)
        {

            string sProduto;

            sProduto = "TA2000";

            Declaracoes.iRetorno = Declaracoes.eDefinirProduto_Daruma(sProduto);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Configura��o realizada com sucesso, produto TA2000", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao incluir dados no Registro(Registry)!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void MN_regRetornaValorChave_DarumaFramework_Click(object sender, EventArgs e)
        {
            FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework DarumaRetorna = new FR_DARUMAFRAMEWORK_regRetornaValorChave_DarumaFramework();
            DarumaRetorna.Show();
        }

    }
}