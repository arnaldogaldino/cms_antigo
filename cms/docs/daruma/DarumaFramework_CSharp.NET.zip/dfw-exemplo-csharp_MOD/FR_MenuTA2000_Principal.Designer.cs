namespace DarumaFramework_CSharp
{
    partial class FR_MenuTA2000_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PN_LogoDDC = new System.Windows.Forms.Panel();
            this.lb_0800 = new System.Windows.Forms.Label();
            this.lb_duvidas = new System.Windows.Forms.Label();
            this.LB_DLL_TA2000 = new System.Windows.Forms.Label();
            this.LB_Trabalhando = new System.Windows.Forms.Label();
            this.PB_DDC = new System.Windows.Forms.PictureBox();
            this.MS_Geral_TA2000 = new System.Windows.Forms.MenuStrip();
            this.MN_MetodosDarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_eDefinirProduto_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_MetodosRegistro = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regAuditoria_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_DesativarAuditoria = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_AtivarAuditoria = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMarcadorOpcao_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMascara_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMascaraLetra_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMascaraNumero_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regMascaraEco_TA2000_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Exemplos = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_ImprimirTexto = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_LimparDisplay = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Edicao = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_CriarMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Mascaras = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Encerrar = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Combo = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_GetDadoCampo = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_FecharTA2000 = new System.Windows.Forms.ToolStripMenuItem();
            this.PN_TA2000 = new System.Windows.Forms.Panel();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_Resultado = new System.Windows.Forms.TextBox();
            this.TB_Comando = new System.Windows.Forms.TextBox();
            this.LB_Resultado = new System.Windows.Forms.Label();
            this.LB_Comando = new System.Windows.Forms.Label();
            this.GB_TAGs = new System.Windows.Forms.GroupBox();
            this.LB_menu = new System.Windows.Forms.Label();
            this.LB_Campo_2 = new System.Windows.Forms.Label();
            this.LB_Limpar = new System.Windows.Forms.Label();
            this.LB_modocursor = new System.Windows.Forms.Label();
            this.LB_edicao_2 = new System.Windows.Forms.Label();
            this.LB_edicao = new System.Windows.Forms.Label();
            this.LB_modocursor_2 = new System.Windows.Forms.Label();
            this.LB_pos = new System.Windows.Forms.Label();
            this.LB_setfocus = new System.Windows.Forms.Label();
            this.LB_encerrar = new System.Windows.Forms.Label();
            this.LB_combo = new System.Windows.Forms.Label();
            this.LB_getdadocampo = new System.Windows.Forms.Label();
            this.LB_getdadocombo = new System.Windows.Forms.Label();
            this.LB_imprimir = new System.Windows.Forms.Label();
            this.LB_apagar = new System.Windows.Forms.Label();
            this.LB_c = new System.Windows.Forms.Label();
            this.LB_campo = new System.Windows.Forms.Label();
            this.LB_ae = new System.Windows.Forms.Label();
            this.LB_ad = new System.Windows.Forms.Label();
            this.MN_regRetornaValorChave_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.PN_LogoDDC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).BeginInit();
            this.MS_Geral_TA2000.SuspendLayout();
            this.PN_TA2000.SuspendLayout();
            this.GB_TAGs.SuspendLayout();
            this.SuspendLayout();
            // 
            // PN_LogoDDC
            // 
            this.PN_LogoDDC.BackColor = System.Drawing.Color.White;
            this.PN_LogoDDC.Controls.Add(this.lb_0800);
            this.PN_LogoDDC.Controls.Add(this.lb_duvidas);
            this.PN_LogoDDC.Controls.Add(this.LB_DLL_TA2000);
            this.PN_LogoDDC.Controls.Add(this.LB_Trabalhando);
            this.PN_LogoDDC.Controls.Add(this.PB_DDC);
            this.PN_LogoDDC.Location = new System.Drawing.Point(600, 0);
            this.PN_LogoDDC.Name = "PN_LogoDDC";
            this.PN_LogoDDC.Size = new System.Drawing.Size(200, 499);
            this.PN_LogoDDC.TabIndex = 0;
            // 
            // lb_0800
            // 
            this.lb_0800.AutoSize = true;
            this.lb_0800.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_0800.Location = new System.Drawing.Point(44, 179);
            this.lb_0800.Name = "lb_0800";
            this.lb_0800.Size = new System.Drawing.Size(107, 13);
            this.lb_0800.TabIndex = 4;
            this.lb_0800.Text = "0800 770 33 20";
            // 
            // lb_duvidas
            // 
            this.lb_duvidas.AutoSize = true;
            this.lb_duvidas.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_duvidas.Location = new System.Drawing.Point(14, 156);
            this.lb_duvidas.Name = "lb_duvidas";
            this.lb_duvidas.Size = new System.Drawing.Size(166, 13);
            this.lb_duvidas.TabIndex = 3;
            this.lb_duvidas.Text = "Duvidas? Ligue Gratuito!";
            // 
            // LB_DLL_TA2000
            // 
            this.LB_DLL_TA2000.AutoSize = true;
            this.LB_DLL_TA2000.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DLL_TA2000.Location = new System.Drawing.Point(3, 34);
            this.LB_DLL_TA2000.Name = "LB_DLL_TA2000";
            this.LB_DLL_TA2000.Size = new System.Drawing.Size(183, 13);
            this.LB_DLL_TA2000.TabIndex = 2;
            this.LB_DLL_TA2000.Text = "DLL: DarumaFramework.dll";
            // 
            // LB_Trabalhando
            // 
            this.LB_Trabalhando.AutoSize = true;
            this.LB_Trabalhando.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Trabalhando.Location = new System.Drawing.Point(3, 9);
            this.LB_Trabalhando.Name = "LB_Trabalhando";
            this.LB_Trabalhando.Size = new System.Drawing.Size(169, 16);
            this.LB_Trabalhando.TabIndex = 1;
            this.LB_Trabalhando.Text = "Trabalhando o TA2000";
            // 
            // PB_DDC
            // 
            this.PB_DDC.Image = global::DarumaFramework_CSharp.Properties.Resources.logoDDCpeq2;
            this.PB_DDC.Location = new System.Drawing.Point(3, 370);
            this.PB_DDC.Name = "PB_DDC";
            this.PB_DDC.Size = new System.Drawing.Size(197, 100);
            this.PB_DDC.TabIndex = 0;
            this.PB_DDC.TabStop = false;
            // 
            // MS_Geral_TA2000
            // 
            this.MS_Geral_TA2000.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_MetodosDarumaFramework,
            this.MN_MetodosRegistro,
            this.MN_Exemplos,
            this.MN_FecharTA2000});
            this.MS_Geral_TA2000.Location = new System.Drawing.Point(0, 0);
            this.MS_Geral_TA2000.Name = "MS_Geral_TA2000";
            this.MS_Geral_TA2000.Size = new System.Drawing.Size(792, 24);
            this.MS_Geral_TA2000.TabIndex = 1;
            this.MS_Geral_TA2000.Text = "menuStrip1";
            this.MS_Geral_TA2000.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MS_Geral_TA2000_ItemClicked);
            // 
            // MN_MetodosDarumaFramework
            // 
            this.MN_MetodosDarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_eDefinirProduto_Daruma,
            this.MN_regRetornaValorChave_DarumaFramework});
            this.MN_MetodosDarumaFramework.Name = "MN_MetodosDarumaFramework";
            this.MN_MetodosDarumaFramework.Size = new System.Drawing.Size(196, 20);
            this.MN_MetodosDarumaFramework.Text = "&M�todos para DarumaFramework";
            // 
            // MN_eDefinirProduto_Daruma
            // 
            this.MN_eDefinirProduto_Daruma.Name = "MN_eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Size = new System.Drawing.Size(343, 22);
            this.MN_eDefinirProduto_Daruma.Text = "M�todo eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Click += new System.EventHandler(this.MN_eDefinirProduto_Daruma_Click);
            // 
            // MN_MetodosRegistro
            // 
            this.MN_MetodosRegistro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regAuditoria_TA2000_Daruma,
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma,
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma,
            this.MN_regMarcadorOpcao_TA2000_Daruma,
            this.MN_regMascara_TA2000_Daruma,
            this.MN_regMascaraLetra_TA2000_Daruma,
            this.MN_regMascaraNumero_TA2000_Daruma,
            this.MN_regMascaraEco_TA2000_Daruma});
            this.MN_MetodosRegistro.Name = "MN_MetodosRegistro";
            this.MN_MetodosRegistro.Size = new System.Drawing.Size(188, 20);
            this.MN_MetodosRegistro.Text = "&M�todos para Registro(Registry)";
            // 
            // MN_regAuditoria_TA2000_Daruma
            // 
            this.MN_regAuditoria_TA2000_Daruma.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_DesativarAuditoria,
            this.MN_AtivarAuditoria});
            this.MN_regAuditoria_TA2000_Daruma.Name = "MN_regAuditoria_TA2000_Daruma";
            this.MN_regAuditoria_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regAuditoria_TA2000_Daruma.Text = "M�todo regAuditoria_TA2000_Daruma";
            // 
            // MN_DesativarAuditoria
            // 
            this.MN_DesativarAuditoria.Name = "MN_DesativarAuditoria";
            this.MN_DesativarAuditoria.Size = new System.Drawing.Size(139, 22);
            this.MN_DesativarAuditoria.Text = "0 - Desativar";
            this.MN_DesativarAuditoria.Click += new System.EventHandler(this.MN_DesativarAuditoria_Click);
            // 
            // MN_AtivarAuditoria
            // 
            this.MN_AtivarAuditoria.Name = "MN_AtivarAuditoria";
            this.MN_AtivarAuditoria.Size = new System.Drawing.Size(139, 22);
            this.MN_AtivarAuditoria.Text = "1 - Ativar";
            this.MN_AtivarAuditoria.Click += new System.EventHandler(this.MN_AtivarAuditoria_Click);
            // 
            // MN_regMensagemBoasVindasLinha1_TA2000_Daruma
            // 
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma.Name = "MN_regMensagemBoasVindasLinha1_TA2000_Daruma";
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma.Text = "M�todo regMensagemBoasVindasLinha1_TA2000_Daruma";
            this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMensagemBoasVindasLinha1_TA2000_Daruma_Click);
            // 
            // MN_regMensagemBoasVindasLinha2_TA2000_Daruma
            // 
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma.Name = "MN_regMensagemBoasVindasLinha2_TA2000_Daruma";
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma.Text = "M�todo regMensagemBoasVindasLinha2_TA2000_Daruma";
            this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMensagemBoasVindasLinha2_TA2000_Daruma_Click);
            // 
            // MN_regMarcadorOpcao_TA2000_Daruma
            // 
            this.MN_regMarcadorOpcao_TA2000_Daruma.Name = "MN_regMarcadorOpcao_TA2000_Daruma";
            this.MN_regMarcadorOpcao_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMarcadorOpcao_TA2000_Daruma.Text = "M�todo regMarcadorOpcao_TA2000_Daruma";
            this.MN_regMarcadorOpcao_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMarcadorOpcao_TA2000_Daruma_Click);
            // 
            // MN_regMascara_TA2000_Daruma
            // 
            this.MN_regMascara_TA2000_Daruma.Name = "MN_regMascara_TA2000_Daruma";
            this.MN_regMascara_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMascara_TA2000_Daruma.Text = "M�todo regMascara_TA2000_Daruma";
            this.MN_regMascara_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMascara_TA2000_Daruma_Click_1);
            // 
            // MN_regMascaraLetra_TA2000_Daruma
            // 
            this.MN_regMascaraLetra_TA2000_Daruma.Name = "MN_regMascaraLetra_TA2000_Daruma";
            this.MN_regMascaraLetra_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMascaraLetra_TA2000_Daruma.Text = "M�todo regMascaraLetra_TA2000_Daruma";
            this.MN_regMascaraLetra_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMascaraLetra_TA2000_Daruma_Click);
            // 
            // MN_regMascaraNumero_TA2000_Daruma
            // 
            this.MN_regMascaraNumero_TA2000_Daruma.Name = "MN_regMascaraNumero_TA2000_Daruma";
            this.MN_regMascaraNumero_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMascaraNumero_TA2000_Daruma.Text = "M�todo regMascaraNumero_TA2000_Daruma";
            this.MN_regMascaraNumero_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMascaraNumero_TA2000_Daruma_Click);
            // 
            // MN_regMascaraEco_TA2000_Daruma
            // 
            this.MN_regMascaraEco_TA2000_Daruma.Name = "MN_regMascaraEco_TA2000_Daruma";
            this.MN_regMascaraEco_TA2000_Daruma.Size = new System.Drawing.Size(381, 22);
            this.MN_regMascaraEco_TA2000_Daruma.Text = "M�todo regMascaraEco_TA2000_Daruma";
            this.MN_regMascaraEco_TA2000_Daruma.Click += new System.EventHandler(this.MN_regMascaraEco_TA2000_Daruma_Click);
            // 
            // MN_Exemplos
            // 
            this.MN_Exemplos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_ImprimirTexto,
            this.MN_LimparDisplay,
            this.MN_Edicao,
            this.MN_CriarMenu,
            this.MN_Mascaras,
            this.MN_Encerrar,
            this.MN_Combo,
            this.MN_GetDadoCampo});
            this.MN_Exemplos.Name = "MN_Exemplos";
            this.MN_Exemplos.Size = new System.Drawing.Size(109, 20);
            this.MN_Exemplos.Text = "&Exemplo Pr�ticos";
            // 
            // MN_ImprimirTexto
            // 
            this.MN_ImprimirTexto.Name = "MN_ImprimirTexto";
            this.MN_ImprimirTexto.Size = new System.Drawing.Size(165, 22);
            this.MN_ImprimirTexto.Text = "Imprimir Texto";
            this.MN_ImprimirTexto.Click += new System.EventHandler(this.MN_ImprimirTexto_Click);
            // 
            // MN_LimparDisplay
            // 
            this.MN_LimparDisplay.Name = "MN_LimparDisplay";
            this.MN_LimparDisplay.Size = new System.Drawing.Size(165, 22);
            this.MN_LimparDisplay.Text = "Limpar Display";
            this.MN_LimparDisplay.Click += new System.EventHandler(this.MN_LimparDisplay_Click);
            // 
            // MN_Edicao
            // 
            this.MN_Edicao.Name = "MN_Edicao";
            this.MN_Edicao.Size = new System.Drawing.Size(165, 22);
            this.MN_Edicao.Text = "Edi��o";
            this.MN_Edicao.Click += new System.EventHandler(this.MN_Edicao_Click);
            // 
            // MN_CriarMenu
            // 
            this.MN_CriarMenu.Name = "MN_CriarMenu";
            this.MN_CriarMenu.Size = new System.Drawing.Size(165, 22);
            this.MN_CriarMenu.Text = "Criar Menu";
            this.MN_CriarMenu.Click += new System.EventHandler(this.MN_CriarMenu_Click);
            // 
            // MN_Mascaras
            // 
            this.MN_Mascaras.Name = "MN_Mascaras";
            this.MN_Mascaras.Size = new System.Drawing.Size(165, 22);
            this.MN_Mascaras.Text = "M�scaras";
            this.MN_Mascaras.Click += new System.EventHandler(this.MN_Mascaras_Click);
            // 
            // MN_Encerrar
            // 
            this.MN_Encerrar.Name = "MN_Encerrar";
            this.MN_Encerrar.Size = new System.Drawing.Size(165, 22);
            this.MN_Encerrar.Text = "Encerrar";
            this.MN_Encerrar.Click += new System.EventHandler(this.MN_Encerrar_Click);
            // 
            // MN_Combo
            // 
            this.MN_Combo.Name = "MN_Combo";
            this.MN_Combo.Size = new System.Drawing.Size(165, 22);
            this.MN_Combo.Text = "Combo";
            this.MN_Combo.Click += new System.EventHandler(this.MN_Combo_Click);
            // 
            // MN_GetDadoCampo
            // 
            this.MN_GetDadoCampo.Name = "MN_GetDadoCampo";
            this.MN_GetDadoCampo.Size = new System.Drawing.Size(165, 22);
            this.MN_GetDadoCampo.Text = "Get Dado Campo";
            this.MN_GetDadoCampo.Click += new System.EventHandler(this.MN_GetDadoCampo_Click);
            // 
            // MN_FecharTA2000
            // 
            this.MN_FecharTA2000.Name = "MN_FecharTA2000";
            this.MN_FecharTA2000.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F)));
            this.MN_FecharTA2000.Size = new System.Drawing.Size(89, 20);
            this.MN_FecharTA2000.Text = "&Fechar Janela";
            this.MN_FecharTA2000.Click += new System.EventHandler(this.MN_FecharTA2000_Click);
            // 
            // PN_TA2000
            // 
            this.PN_TA2000.BackColor = System.Drawing.SystemColors.ControlLight;
            this.PN_TA2000.Controls.Add(this.BT_Limpar);
            this.PN_TA2000.Controls.Add(this.BT_Fechar);
            this.PN_TA2000.Controls.Add(this.BT_Enviar);
            this.PN_TA2000.Controls.Add(this.TB_Resultado);
            this.PN_TA2000.Controls.Add(this.TB_Comando);
            this.PN_TA2000.Controls.Add(this.LB_Resultado);
            this.PN_TA2000.Controls.Add(this.LB_Comando);
            this.PN_TA2000.Location = new System.Drawing.Point(0, 27);
            this.PN_TA2000.Name = "PN_TA2000";
            this.PN_TA2000.Size = new System.Drawing.Size(600, 180);
            this.PN_TA2000.TabIndex = 7;
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(355, 117);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(110, 25);
            this.BT_Limpar.TabIndex = 14;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Limpar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(471, 117);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(110, 25);
            this.BT_Fechar.TabIndex = 13;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(239, 117);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(110, 25);
            this.BT_Enviar.TabIndex = 12;
            this.BT_Enviar.Text = "Enviar Comandos";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_Resultado
            // 
            this.TB_Resultado.Location = new System.Drawing.Point(129, 70);
            this.TB_Resultado.Name = "TB_Resultado";
            this.TB_Resultado.Size = new System.Drawing.Size(452, 20);
            this.TB_Resultado.TabIndex = 11;
            // 
            // TB_Comando
            // 
            this.TB_Comando.Location = new System.Drawing.Point(129, 35);
            this.TB_Comando.Name = "TB_Comando";
            this.TB_Comando.Size = new System.Drawing.Size(452, 20);
            this.TB_Comando.TabIndex = 10;
            // 
            // LB_Resultado
            // 
            this.LB_Resultado.AutoSize = true;
            this.LB_Resultado.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Resultado.Location = new System.Drawing.Point(20, 69);
            this.LB_Resultado.Name = "LB_Resultado";
            this.LB_Resultado.Size = new System.Drawing.Size(96, 18);
            this.LB_Resultado.TabIndex = 9;
            this.LB_Resultado.Text = "Resultado:";
            // 
            // LB_Comando
            // 
            this.LB_Comando.AutoSize = true;
            this.LB_Comando.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Comando.Location = new System.Drawing.Point(20, 34);
            this.LB_Comando.Name = "LB_Comando";
            this.LB_Comando.Size = new System.Drawing.Size(91, 18);
            this.LB_Comando.TabIndex = 8;
            this.LB_Comando.Text = "Comando:";
            // 
            // GB_TAGs
            // 
            this.GB_TAGs.Controls.Add(this.LB_menu);
            this.GB_TAGs.Controls.Add(this.LB_Campo_2);
            this.GB_TAGs.Controls.Add(this.LB_Limpar);
            this.GB_TAGs.Controls.Add(this.LB_modocursor);
            this.GB_TAGs.Controls.Add(this.LB_edicao_2);
            this.GB_TAGs.Controls.Add(this.LB_edicao);
            this.GB_TAGs.Controls.Add(this.LB_modocursor_2);
            this.GB_TAGs.Controls.Add(this.LB_pos);
            this.GB_TAGs.Controls.Add(this.LB_setfocus);
            this.GB_TAGs.Controls.Add(this.LB_encerrar);
            this.GB_TAGs.Controls.Add(this.LB_combo);
            this.GB_TAGs.Controls.Add(this.LB_getdadocampo);
            this.GB_TAGs.Controls.Add(this.LB_getdadocombo);
            this.GB_TAGs.Controls.Add(this.LB_imprimir);
            this.GB_TAGs.Controls.Add(this.LB_apagar);
            this.GB_TAGs.Controls.Add(this.LB_c);
            this.GB_TAGs.Controls.Add(this.LB_campo);
            this.GB_TAGs.Controls.Add(this.LB_ae);
            this.GB_TAGs.Controls.Add(this.LB_ad);
            this.GB_TAGs.Location = new System.Drawing.Point(3, 206);
            this.GB_TAGs.Name = "GB_TAGs";
            this.GB_TAGs.Size = new System.Drawing.Size(596, 293);
            this.GB_TAGs.TabIndex = 8;
            this.GB_TAGs.TabStop = false;
            this.GB_TAGs.Text = "Principais TAG\'s:                                -Caso solicite informacoes sobre" +
                " todas as TAG\'s verificar em nosso HELP.";
            // 
            // LB_menu
            // 
            this.LB_menu.AutoSize = true;
            this.LB_menu.Location = new System.Drawing.Point(11, 141);
            this.LB_menu.Name = "LB_menu";
            this.LB_menu.Size = new System.Drawing.Size(430, 13);
            this.LB_menu.TabIndex = 18;
            this.LB_menu.Text = "<menu></menu> - Esta tag permite criar menu din�micos para uso no Display do TA20" +
                "00.";
            // 
            // LB_Campo_2
            // 
            this.LB_Campo_2.AutoSize = true;
            this.LB_Campo_2.Location = new System.Drawing.Point(123, 89);
            this.LB_Campo_2.Name = "LB_Campo_2";
            this.LB_Campo_2.Size = new System.Drawing.Size(392, 13);
            this.LB_Campo_2.TabIndex = 17;
            this.LB_Campo_2.Text = "O campo pode aceitar at� todos os tipos de formatados, sendo letras ou n�meros.";
            // 
            // LB_Limpar
            // 
            this.LB_Limpar.AutoSize = true;
            this.LB_Limpar.Location = new System.Drawing.Point(11, 128);
            this.LB_Limpar.Name = "LB_Limpar";
            this.LB_Limpar.Size = new System.Drawing.Size(462, 13);
            this.LB_Limpar.TabIndex = 16;
            this.LB_Limpar.Text = "<limpar></limpar> - Esta tag permite limpar o cursor do Display na determinada li" +
                "nha selecionada.";
            // 
            // LB_modocursor
            // 
            this.LB_modocursor.AutoSize = true;
            this.LB_modocursor.Location = new System.Drawing.Point(11, 154);
            this.LB_modocursor.Name = "LB_modocursor";
            this.LB_modocursor.Size = new System.Drawing.Size(459, 13);
            this.LB_modocursor.TabIndex = 15;
            this.LB_modocursor.Text = "<modocursor></modocursor> - Esta tag permite configurar o Display do modo em qual" +
                " ser� mas ";
            // 
            // LB_edicao_2
            // 
            this.LB_edicao_2.AutoSize = true;
            this.LB_edicao_2.Location = new System.Drawing.Point(123, 115);
            this.LB_edicao_2.Name = "LB_edicao_2";
            this.LB_edicao_2.Size = new System.Drawing.Size(201, 13);
            this.LB_edicao_2.TabIndex = 14;
            this.LB_edicao_2.Text = "onde poder�o ser filtrados e/ou editados.";
            // 
            // LB_edicao
            // 
            this.LB_edicao.AutoSize = true;
            this.LB_edicao.Location = new System.Drawing.Point(11, 102);
            this.LB_edicao.Name = "LB_edicao";
            this.LB_edicao.Size = new System.Drawing.Size(416, 13);
            this.LB_edicao.TabIndex = 13;
            this.LB_edicao.Text = "<edicao></edicao> - Esta tag permite enviar dados formatados ao display do TA2000" +
                ", ";
            // 
            // LB_modocursor_2
            // 
            this.LB_modocursor_2.AutoSize = true;
            this.LB_modocursor_2.Location = new System.Drawing.Point(166, 167);
            this.LB_modocursor_2.Name = "LB_modocursor_2";
            this.LB_modocursor_2.Size = new System.Drawing.Size(236, 13);
            this.LB_modocursor_2.TabIndex = 12;
            this.LB_modocursor_2.Text = "atraente ao usu�rio ou/ao seu desenvolvimento.";
            // 
            // LB_pos
            // 
            this.LB_pos.AutoSize = true;
            this.LB_pos.Location = new System.Drawing.Point(11, 181);
            this.LB_pos.Name = "LB_pos";
            this.LB_pos.Size = new System.Drawing.Size(438, 13);
            this.LB_pos.TabIndex = 11;
            this.LB_pos.Text = "<pos></pos> - Esta tag permite posicionar o cursor do Display na linha ou coluna " +
                "desejada.";
            // 
            // LB_setfocus
            // 
            this.LB_setfocus.AutoSize = true;
            this.LB_setfocus.Location = new System.Drawing.Point(11, 196);
            this.LB_setfocus.Name = "LB_setfocus";
            this.LB_setfocus.Size = new System.Drawing.Size(339, 13);
            this.LB_setfocus.TabIndex = 10;
            this.LB_setfocus.Text = "<setfocus></setfocus> - Esta tag permite \'focar\' o campo selecionado.";
            // 
            // LB_encerrar
            // 
            this.LB_encerrar.AutoSize = true;
            this.LB_encerrar.Location = new System.Drawing.Point(11, 210);
            this.LB_encerrar.Name = "LB_encerrar";
            this.LB_encerrar.Size = new System.Drawing.Size(475, 13);
            this.LB_encerrar.TabIndex = 9;
            this.LB_encerrar.Text = "<encerrar></encerrar> - Esta tag permite que o usu�rio encerre ou finalize uma se" +
                "ss�o na maquina.";
            // 
            // LB_combo
            // 
            this.LB_combo.AutoSize = true;
            this.LB_combo.Location = new System.Drawing.Point(11, 225);
            this.LB_combo.Name = "LB_combo";
            this.LB_combo.Size = new System.Drawing.Size(388, 13);
            this.LB_combo.TabIndex = 8;
            this.LB_combo.Text = "<combo></combo> - Esta tag permite realizar inumeras fun��es numa unica vez.";
            // 
            // LB_getdadocampo
            // 
            this.LB_getdadocampo.AutoSize = true;
            this.LB_getdadocampo.Location = new System.Drawing.Point(11, 241);
            this.LB_getdadocampo.Name = "LB_getdadocampo";
            this.LB_getdadocampo.Size = new System.Drawing.Size(481, 13);
            this.LB_getdadocampo.TabIndex = 7;
            this.LB_getdadocampo.Text = "<getdadocampo></getdadocampo> - Esta tag permite armazenar o dado de um campo sel" +
                "ecionado.";
            // 
            // LB_getdadocombo
            // 
            this.LB_getdadocombo.AutoSize = true;
            this.LB_getdadocombo.Location = new System.Drawing.Point(11, 257);
            this.LB_getdadocombo.Name = "LB_getdadocombo";
            this.LB_getdadocombo.Size = new System.Drawing.Size(491, 13);
            this.LB_getdadocombo.TabIndex = 6;
            this.LB_getdadocombo.Text = "<getdadocombo></getdadocombo> - Esta tag permite armazenar os dados de um combo s" +
                "elecionado.";
            // 
            // LB_imprimir
            // 
            this.LB_imprimir.AutoSize = true;
            this.LB_imprimir.Location = new System.Drawing.Point(11, 271);
            this.LB_imprimir.Name = "LB_imprimir";
            this.LB_imprimir.Size = new System.Drawing.Size(288, 13);
            this.LB_imprimir.TabIndex = 5;
            this.LB_imprimir.Text = "<imprimir></imprimir> - Esta tag permite escrever no Display.";
            // 
            // LB_apagar
            // 
            this.LB_apagar.AutoSize = true;
            this.LB_apagar.Location = new System.Drawing.Point(11, 49);
            this.LB_apagar.Name = "LB_apagar";
            this.LB_apagar.Size = new System.Drawing.Size(378, 13);
            this.LB_apagar.TabIndex = 4;
            this.LB_apagar.Text = "<apagar></apagar> - Esta tag permite apagar o texto que antecede ao Cursor.";
            // 
            // LB_c
            // 
            this.LB_c.AutoSize = true;
            this.LB_c.Location = new System.Drawing.Point(11, 63);
            this.LB_c.Name = "LB_c";
            this.LB_c.Size = new System.Drawing.Size(374, 13);
            this.LB_c.TabIndex = 3;
            this.LB_c.Text = "<c></c> - Esta tag permite centralizar o texto na linha selecionada no Display.";
            // 
            // LB_campo
            // 
            this.LB_campo.AutoSize = true;
            this.LB_campo.Location = new System.Drawing.Point(11, 76);
            this.LB_campo.Name = "LB_campo";
            this.LB_campo.Size = new System.Drawing.Size(544, 13);
            this.LB_campo.TabIndex = 2;
            this.LB_campo.Text = "<campo></campo> - Esta tag permite criar um campo onde � poss�vel editar, a parti" +
                "r da ultima posi��o do cursor. ";
            // 
            // LB_ae
            // 
            this.LB_ae.AutoSize = true;
            this.LB_ae.Location = new System.Drawing.Point(11, 36);
            this.LB_ae.Name = "LB_ae";
            this.LB_ae.Size = new System.Drawing.Size(454, 13);
            this.LB_ae.TabIndex = 1;
            this.LB_ae.Text = "<ae></ae> - Esta tag permite alinhar ao lado esquerdo o texto na linha selecionad" +
                "a no Display.";
            // 
            // LB_ad
            // 
            this.LB_ad.AutoSize = true;
            this.LB_ad.Location = new System.Drawing.Point(11, 21);
            this.LB_ad.Name = "LB_ad";
            this.LB_ad.Size = new System.Drawing.Size(438, 13);
            this.LB_ad.TabIndex = 0;
            this.LB_ad.Text = "<ad></ad> - Esta tag permite alinhar ao lado direito o texto na linha selecionada" +
                " no Display.";
            // 
            // MN_regRetornaValorChave_DarumaFramework
            // 
            this.MN_regRetornaValorChave_DarumaFramework.Name = "MN_regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Size = new System.Drawing.Size(343, 22);
            this.MN_regRetornaValorChave_DarumaFramework.Text = "M�todo regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Click += new System.EventHandler(this.MN_regRetornaValorChave_DarumaFramework_Click);
            // 
            // FR_MenuTA2000_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 497);
            this.Controls.Add(this.GB_TAGs);
            this.Controls.Add(this.PN_TA2000);
            this.Controls.Add(this.PN_LogoDDC);
            this.Controls.Add(this.MS_Geral_TA2000);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.MS_Geral_TA2000;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MenuTA2000_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Painel de Simula��o do TA2000";
            this.Load += new System.EventHandler(this.FR_MenuTA2000_Principal_Load);
            this.PN_LogoDDC.ResumeLayout(false);
            this.PN_LogoDDC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).EndInit();
            this.MS_Geral_TA2000.ResumeLayout(false);
            this.MS_Geral_TA2000.PerformLayout();
            this.PN_TA2000.ResumeLayout(false);
            this.PN_TA2000.PerformLayout();
            this.GB_TAGs.ResumeLayout(false);
            this.GB_TAGs.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PN_LogoDDC;
        private System.Windows.Forms.PictureBox PB_DDC;
        private System.Windows.Forms.Label LB_Trabalhando;
        private System.Windows.Forms.Label LB_DLL_TA2000;
        private System.Windows.Forms.MenuStrip MS_Geral_TA2000;
        private System.Windows.Forms.ToolStripMenuItem MN_Exemplos;
        private System.Windows.Forms.ToolStripMenuItem MN_ImprimirTexto;
        private System.Windows.Forms.ToolStripMenuItem MN_LimparDisplay;
        private System.Windows.Forms.ToolStripMenuItem MN_Edicao;
        private System.Windows.Forms.ToolStripMenuItem MN_CriarMenu;
        private System.Windows.Forms.ToolStripMenuItem MN_Mascaras;
        private System.Windows.Forms.ToolStripMenuItem MN_Encerrar;
        private System.Windows.Forms.ToolStripMenuItem MN_Combo;
        private System.Windows.Forms.ToolStripMenuItem MN_GetDadoCampo;
        private System.Windows.Forms.ToolStripMenuItem MN_FecharTA2000;
        private System.Windows.Forms.Panel PN_TA2000;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_Resultado;
        private System.Windows.Forms.TextBox TB_Comando;
        private System.Windows.Forms.Label LB_Resultado;
        private System.Windows.Forms.Label LB_Comando;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.GroupBox GB_TAGs;
        private System.Windows.Forms.Label LB_menu;
        private System.Windows.Forms.Label LB_Campo_2;
        private System.Windows.Forms.Label LB_Limpar;
        private System.Windows.Forms.Label LB_modocursor;
        private System.Windows.Forms.Label LB_edicao_2;
        private System.Windows.Forms.Label LB_edicao;
        private System.Windows.Forms.Label LB_modocursor_2;
        private System.Windows.Forms.Label LB_pos;
        private System.Windows.Forms.Label LB_setfocus;
        private System.Windows.Forms.Label LB_encerrar;
        private System.Windows.Forms.Label LB_combo;
        private System.Windows.Forms.Label LB_getdadocampo;
        private System.Windows.Forms.Label LB_getdadocombo;
        private System.Windows.Forms.Label LB_imprimir;
        private System.Windows.Forms.Label LB_apagar;
        private System.Windows.Forms.Label LB_c;
        private System.Windows.Forms.Label LB_campo;
        private System.Windows.Forms.Label LB_ae;
        private System.Windows.Forms.Label LB_ad;
        private System.Windows.Forms.Label lb_duvidas;
        private System.Windows.Forms.Label lb_0800;
        private System.Windows.Forms.ToolStripMenuItem MN_MetodosRegistro;
        private System.Windows.Forms.ToolStripMenuItem MN_regAuditoria_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_DesativarAuditoria;
        private System.Windows.Forms.ToolStripMenuItem MN_AtivarAuditoria;
        private System.Windows.Forms.ToolStripMenuItem MN_regMensagemBoasVindasLinha1_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMensagemBoasVindasLinha2_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMarcadorOpcao_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMascara_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMascaraLetra_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMascaraNumero_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regMascaraEco_TA2000_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_MetodosDarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_eDefinirProduto_Daruma;
        private System.Windows.Forms.ToolStripMenuItem MN_regRetornaValorChave_DarumaFramework;
    }
}