﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_MenuFiscal_LMFC : Form
    {
        public FR_FISCAL_MenuFiscal_LMFC()
        {
            InitializeComponent();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            Declaracoes.regAlterarValor_Daruma(@"ECF\LMFCompleta", "1");
            
            string Str_Parametro_Inicial, Str_Parametro_Final;
            if (RB_Arquivo.Checked.Equals(true))
            {
                Str_Parametro_Inicial = TB_Parametro_Inicial.Text.Trim().Replace("/", "");
                Str_Parametro_Final = TB_Parametro_Final.Text.Trim().Replace("/", "");

                Declaracoes.iRetorno = Declaracoes.iMFLerSerial_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (RB_Impressa.Checked.Equals(true))
            {
                Str_Parametro_Inicial = TB_Parametro_Inicial.Text.Trim().Replace("/", "");
                Str_Parametro_Final = TB_Parametro_Final.Text.Trim().Replace("/", "");

                Declaracoes.iRetorno = Declaracoes.iMFLer_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            }
        }

        private void TB_Parametro_Inicial_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
