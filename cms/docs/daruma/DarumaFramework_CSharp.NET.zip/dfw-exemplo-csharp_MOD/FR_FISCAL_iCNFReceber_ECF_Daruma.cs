﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCNFReceber_ECF_Daruma : Form
    {
        public FR_FISCAL_iCNFReceber_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Indice, Str_Valor_Recebimento, Str_Tipo_Desc_Acresc, Str_Valor_Desc_Acresc;

            Str_Indice = CBO_IndiceTotalizador.Text.Trim();
            Str_Valor_Recebimento = TB_ValorRecebimento.Text.Trim();
            Str_Tipo_Desc_Acresc = CBO_TipoDesc_Acresc.Text.Trim();
            Str_Valor_Desc_Acresc = TB_ValorDescAcresc.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCNFReceber_ECF_Daruma(Str_Indice, Str_Valor_Recebimento, Str_Tipo_Desc_Acresc, Str_Valor_Desc_Acresc);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
