﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_confProgramarOperador_ECF_Daruma : Form
    {
        public FR_FISCAL_confProgramarOperador_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Operador;

            Str_Operador = TB_Operador.Text.Trim(); 

            Declaracoes.iRetorno = Declaracoes.confProgramarOperador_ECF_Daruma(Str_Operador);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
