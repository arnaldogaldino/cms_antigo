﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCNFAbrir_ECF_Daruma : Form
    {
        public FR_FISCAL_iCNFAbrir_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Texto_CPF, Str_Texto_Nome, Str_Texto_Endereço;

            Str_Texto_CPF = TB_Texto_CPF.Text.Trim();
            Str_Texto_Nome = TB_Texto_Nome.Text.Trim();
            Str_Texto_Endereço = TB_Texto_Endereco.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCNFAbrir_ECF_Daruma(Str_Texto_CPF, Str_Texto_Nome, Str_Texto_Endereço);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
