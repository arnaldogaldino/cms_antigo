﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCNFCancelarItem_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.Indice = new System.Windows.Forms.Label();
            this.TB_Indice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(177, 46);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 106;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(83, 46);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 105;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // Indice
            // 
            this.Indice.AutoSize = true;
            this.Indice.Location = new System.Drawing.Point(10, 9);
            this.Indice.Name = "Indice";
            this.Indice.Size = new System.Drawing.Size(129, 13);
            this.Indice.TabIndex = 104;
            this.Indice.Text = "Informe o Numero do Item";
            // 
            // TB_Indice
            // 
            this.TB_Indice.Location = new System.Drawing.Point(145, 6);
            this.TB_Indice.Name = "TB_Indice";
            this.TB_Indice.Size = new System.Drawing.Size(80, 20);
            this.TB_Indice.TabIndex = 103;
            this.TB_Indice.Text = "001";
            // 
            // FR_FISCAL_iCNFCancelarItem_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(256, 72);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.Indice);
            this.Controls.Add(this.TB_Indice);
            this.Name = "FR_FISCAL_iCNFCancelarItem_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCNFCancelarItem_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label Indice;
        private System.Windows.Forms.TextBox TB_Indice;
    }
}