﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_ParametrizacaoSintegra : Form
    {
        public FR_FISCAL_ParametrizacaoSintegra()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarRelatorio_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarRelatorio_ECF_Daruma();
            
            Close();
        }

    

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Str_IdentificacaoConvenio = CBO_IdentificaConvenio.Text;

            switch (Str_IdentificacaoConvenio.ToString())
            {                  
                case "1": TB_IdentificaConvenio.Text = "Convênio ICMS 31/99";
                    break;
                case "2": TB_IdentificaConvenio.Text = "Convênio ICMS 69/02 e 142/02";
                    break;
                case "3": TB_IdentificaConvenio.Text = "Convênio ICMS 76/03 e 20/04";
                    break;
                default:
                    TB_IdentificaConvenio.Text = "Opção Inválida";
                    break;
            }
        }

        private void TB_Parametrizar_Click(object sender, EventArgs e)
        {
            string Str_Endereco, Str_Numero, Str_Complemento, Str_Bairro, Str_Cep,
                   Str_Municipio, Str_UF, Str_Telefone, Str_Fax, Str_Nome, Str_CBFinalidade,
                   Str_CBIndentificaConvenio, Str_CBNatureza;

   Str_Endereco = TB_Endereco.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Logradouro", Str_Endereco);

   Str_Numero = TB_Numero.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Numero", Str_Numero);

   Str_Complemento = TB_Complemento.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Complemento", Str_Complemento);

   Str_Bairro = TB_Bairro.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Bairro", Str_Bairro);

   Str_Municipio = TB_Municipio.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Municipio", Str_Municipio);

   Str_UF = CBO_UF.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("UF", Str_UF);

   Str_Cep = TB_Cep.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("CEP", Str_Cep);

   Str_Telefone = TB_Telefone.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Contato_Telefone", Str_Telefone);

   Str_Fax = TB_Fax.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Fax", Str_Fax);

   Str_Nome = TB_NomeContato.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Contato_Nome", Str_Nome);

   Str_CBFinalidade = CBO_Finalidade.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Cod_Finalidade", Str_CBFinalidade);

   Str_CBIndentificaConvenio = CBO_IdentificaConvenio.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Cod_Convenio", Str_CBIndentificaConvenio);

   Str_CBNatureza = CBO_NaturezaDasOperacoes.Text;
   Declaracoes.iRetorno = Declaracoes.regSintegra_ECF_Daruma("Cod_Natureza", Str_CBNatureza);

   Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            
        }

        private void CBO_Finalidade_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Str_Finalidade;
            Str_Finalidade = CBO_Finalidade.Text;

            switch (Str_Finalidade.ToString())
            {

                case "1": TB_Finalidade.Text = "Normal";
                    break;
                case "2": TB_Finalidade.Text = "Retificação total de arquivo";
                    break;
                case "3": TB_Finalidade.Text = "Retificação aditiva de arquivo";
                    break;
                case "4": TB_Finalidade.Text = "Retificação corretiva";
                    break;
                case "5": TB_Finalidade.Text = "Desfazimento: arquivo de informação referente a operações/prestações não efetivadas";
                    break;
                default:
                    TB_Finalidade.Text = "Opção Inválida";
                    break;

            }
        }

        private void CBO_NaturezaDasOperacoes_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Str_Natureza = CBO_NaturezaDasOperacoes.Text;

            switch (Str_Natureza.ToString())

            {
                case "1": TB_NaturezaDasOperacoes.Text = "Interestaduais somente com substituição tributária";
                    break;
                case "2": TB_NaturezaDasOperacoes.Text = "Interestaduais com ou sem substituição tributária";
                    break;
                case "3": TB_NaturezaDasOperacoes.Text = "Totalidade das operações do informante";
                    break;
                default:
                    TB_NaturezaDasOperacoes.Text = "Opção Inválida";
                    break;
            }
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
