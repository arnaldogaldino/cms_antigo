namespace DarumaFramework_CSharp
{
    partial class FR_DUAL_menuTestes_LoopingStatus
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LB_Status = new System.Windows.Forms.Label();
            this.TB_Status = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Stop = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.TM_Status = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LB_Status
            // 
            this.LB_Status.AutoSize = true;
            this.LB_Status.Location = new System.Drawing.Point(10, 22);
            this.LB_Status.Name = "LB_Status";
            this.LB_Status.Size = new System.Drawing.Size(94, 13);
            this.LB_Status.TabIndex = 0;
            this.LB_Status.Text = "Status Impressora:";
            // 
            // TB_Status
            // 
            this.TB_Status.Location = new System.Drawing.Point(110, 19);
            this.TB_Status.Name = "TB_Status";
            this.TB_Status.Size = new System.Drawing.Size(263, 20);
            this.TB_Status.TabIndex = 1;
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(397, 16);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(83, 23);
            this.BT_Enviar.TabIndex = 2;
            this.BT_Enviar.Text = "Start";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Stop
            // 
            this.BT_Stop.Location = new System.Drawing.Point(397, 54);
            this.BT_Stop.Name = "BT_Stop";
            this.BT_Stop.Size = new System.Drawing.Size(83, 23);
            this.BT_Stop.TabIndex = 3;
            this.BT_Stop.Text = "Stop";
            this.BT_Stop.UseVisualStyleBackColor = true;
            this.BT_Stop.Click += new System.EventHandler(this.BT_Stop_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(397, 96);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(83, 23);
            this.BT_Fechar.TabIndex = 4;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // TM_Status
            // 
            this.TM_Status.Interval = 500;
            this.TM_Status.Tick += new System.EventHandler(this.TM_Status_Tick);
            // 
            // FR_DUAL_menuTestes_LoopingStatus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 136);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Stop);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_Status);
            this.Controls.Add(this.LB_Status);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DUAL_menuTestes_LoopingStatus";
            this.Text = "Verifica��o de Looping de Status                                 Daruma DDC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_Status;
        private System.Windows.Forms.TextBox TB_Status;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Stop;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Timer TM_Status;
    }
}