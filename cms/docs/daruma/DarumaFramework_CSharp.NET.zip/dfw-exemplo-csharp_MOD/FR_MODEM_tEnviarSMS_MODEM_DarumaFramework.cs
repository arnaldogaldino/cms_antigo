using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;
using System.Threading;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_tEnviarSMS_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_tEnviarSMS_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            string sNumeroTelefone;
            string sMensagem;
  
            sNumeroTelefone = TB_NumeroTelefone.Text;
            sMensagem = TB_Mensagem.Text;
  
            if (TB_NumeroTelefone.Text == "")
            {
                MessageBox.Show("� preciso digitar o numero do telefone para envio do SMS diferente de 0", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Declaracoes.iRetorno = Declaracoes.tEnviarSms_MODEM_DarumaFramework(sNumeroTelefone, sMensagem);
            }

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Mensagem Enviada com Sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao enviar a mensagem.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TB_RespostaModem.Text = Declaracoes.iRetorno.ToString();
            }

        }

        private void BT_Apagar_Click(object sender, EventArgs e)
        {
            TB_NumeroTelefone.Clear();
            TB_Mensagem.Clear();
            TB_RespostaModem.Clear();

        }
    }
}