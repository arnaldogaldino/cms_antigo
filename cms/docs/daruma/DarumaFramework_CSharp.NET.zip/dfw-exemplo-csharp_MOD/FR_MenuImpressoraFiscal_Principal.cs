﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MenuImpressoraFiscal_Principal : Form
    {
        public FR_MenuImpressoraFiscal_Principal()
        {
            InitializeComponent();
        }

        private void BT_fechar_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }

        private void métodoICFAbrirPadraoECFDarumaToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoiCFAbrir_ECF_Daruma_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFVenderECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVender_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVender_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFVenderSemDescECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVenderSemDesc_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVenderSemDesc_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFVenderResumidoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVenderResumido_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVenderResumido_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFLancarAcrescimoItemECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarAcrescimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarAcrescimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFLancarDescontoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarAcrescimoUltimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarAcrescimoUltimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFLancarDescontoUltimoItemECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarDescontoUltimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarDescontoUltimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFCancelarItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarItemParcialECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarItemParcial_ECF FormPrincipal = new FR_FISCAL_iCFCancelarItemParcial_ECF();
            FormPrincipal.Show();
        }

        private void métodoILeituraXECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iLeituraX_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarDescontoItemECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarDescontoItem_ECF FormPrincipal = new FR_FISCAL_iCFCancelarDescontoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarDescUltimoItemECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarDescUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFTotalizarCupomECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFTotalizarCupom_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFTotalizarCupom_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFTotalizarCupomPadraoECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFTotalizarCupomPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarDescontoSubtotalECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarDescontoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarAcrescimoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEfetuarPagamentoPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEfetuarPagamentoFormatado_ECF FormPrincipal = new FR_FISCAL_iCFEfetuarPagamentoFormatado_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEfetuarPagamento_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEfetuarPagamento_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEncerrarPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEncerrarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFFecharResumidoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEncerrarResumido_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEmitirCupomAdicionalECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEmitirCupomAdicional_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEncerrarConfigMsg_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEncerrarConfigMsg_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFEncerrarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEncerrar_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEncerrar_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFIdentificarConsumidorECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFIdentificarConsumidor_ECF FormPrincipal = new FR_FISCAL_iCFIdentificarConsumidor_ECF();
            FormPrincipal.Show();
        }

        private void métodoRLeituraXECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rLeituraX_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRLeituraXCustomizadaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rLeituraXCustomizada_ECF_Daruma FormPrincipal = new FR_FISCAL_rLeituraXCustomizada_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoISangriaPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iSangriaPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoISangriaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iSangria_ECF_Daruma FormPrincipal = new FR_FISCAL_iSangria_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoISuprimentoPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iSuprimentoPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoISuprimentoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iSuprimento_ECF_Daruma FormPrincipal = new FR_FISCAL_iSuprimento_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIReducaoZECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iReducaoZ_ECF_Daruma("","");
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoIMFLerSerialECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iMFLerSerial_ECF_Daruma FormPrincipal = new FR_FISCAL_iMFLerSerial_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIMFLerECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iMFLer_ECF_Daruma FormPrincipal = new FR_FISCAL_iMFLer_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGAbrirPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iRGAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoIRGFecharECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iRGFechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoIRGAbrirECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGAbrirIndiceECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGAbrirIndice_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGAbrirIndice_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGImprimirTextoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGImprimirTexto_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGImprimirTexto_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDAbrirPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICDAbrirECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void comprovanteNãoFiscalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDImprimirTexto_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDImprimirTexto_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDFecharECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDFechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICCDEstornarPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDEstornarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICCDEstornarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDEstornar_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDEstornar_ECF_Daruma();
            FormPrincipal.Show();
        }

       

        private void métodosExclusivosPAFToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void métodoRGerarRelatorioECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarRelatorio_ECF_Daruma FormGerarRelatorio = new FR_FISCAL_rGerarRelatorio_ECF_Daruma();
            FormGerarRelatorio.Show();
        }
                       
        private void métodoICFAbrirPadraoECFDarumaToolStripMenuItem2_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFVenderECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVender_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVender_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoiCFAbrir_ECF_Daruma_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFVenderSemDescECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVenderSemDesc_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVenderSemDesc_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFVenderResumidoECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFVenderResumido_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFVenderResumido_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFLancarAcrescimoItemECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarAcrescimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarAcrescimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFLancarDescontoItemECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFLancarDescontoItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarAcrescimoUltimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarAcrescimoUltimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFLancarDescontoUltimoItemECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFLancarDescontoUltimoItem_ECF FormPrincipal = new FR_FISCAL_iCFLancarDescontoUltimoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarItemECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFCancelarItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarItemParcialECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarItemParcial_ECF FormPrincipal = new FR_FISCAL_iCFCancelarItemParcial_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarUltimoItemParcialECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Tela com um parametro
        }

        private void métodoICFTotalizarCupomECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFTotalizarCupom_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFTotalizarCupom_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarDescontoItemECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFCancelarDescontoItem_ECF FormPrincipal = new FR_FISCAL_iCFCancelarDescontoItem_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFCancelarDescUltimoItemECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarDescUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFTotalizarCupomPadraoECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFTotalizarCupomPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarDescontoSubtotalECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarDescontoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelarAcrescimoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEfetuarPagamentoPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEfetuarPagamentoFormatado_ECF FormPrincipal = new FR_FISCAL_iCFEfetuarPagamentoFormatado_ECF();
            FormPrincipal.Show();
        }

        private void métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEfetuarPagamento_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEfetuarPagamento_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFEncerrarPadraoECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEncerrarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEncerrarConfigMsg_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEncerrarConfigMsg_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFEncerrarECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFEncerrar_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFEncerrar_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFFecharResumidoECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEncerrarResumido_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFEmitirCupomAdicionalECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFEmitirCupomAdicional_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void toolStripMenuItem10_Click(object sender, EventArgs e)
        {

        }

        private void métodoICFCancelarECFDarumaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCFCancelar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFIdentificarConsumidorECFToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_iCFIdentificarConsumidor_ECF FormPrincipal = new FR_FISCAL_iCFIdentificarConsumidor_ECF();
            FormPrincipal.Show();
        }

        private void toolStripMenuItem8_Click(object sender, EventArgs e)
        {

        }

        private void métodoICCDAbrirECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICCDImprimirTextoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDImprimirTexto_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDImprimirTexto_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDImprimirArquivoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDImprimirArquivo_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDImprimirArquivo_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICCDFecharECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDFechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICCDEstornoPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCCDEstornarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICCDEstornarECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCCDEstornar_ECF_Daruma FormPrincipal = new FR_FISCAL_iCCDEstornar_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFAbrirECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFAbrirPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFReceberECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFReceber_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFReceber_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFReceberSemDescECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFReceberSemDesc_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFReceberSemDesc_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFCancelarItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFCancelarItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFCancelarItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelarUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFCancelarAcrescimoItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFCancelarAcrescimoItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelarAcrescUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFCancelarDescontoItem_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFCancelarDescontoItem_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelarUltimoItem_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFTotalizarComprovante_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFTotalizarComprovante_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFTotalizarComprovPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelarAcrescimoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelarDescontoSubtotal_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void FR_MenuImpressoraFiscal_Principal_Load(object sender, EventArgs e)
        {

        }

        private void métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFEfetuarPagamento_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFEfetuarPagamento_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFEfetuarPagamentoFormatado_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFEfetuarPagamentoFormatado_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void MN_Metodos_Codigo_Barras_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
            //FR_FISCAL_iImprimirCodigoBarras_ECF_Daruma FormPrincipal = new FR_FISCAL_iImprimirCodigoBarras_ECF_Daruma();
            //FormPrincipal.Show();
        }

        private void métodoICNFEfetuarPagamentoPadrToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFEfetuarPagamentoPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICNFEncerrarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCNFEncerrar_ECF_Daruma FormPrincipal = new FR_FISCAL_iCNFEncerrar_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFEncerrarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void métodoICNFCancelarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iCNFCancelar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoIRGAbrirECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGAbrirIndice_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGAbrirIndice_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iRGAbrirPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoIRGImprimirTextoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iRGImprimirTexto_ECF_Daruma FormPrincipal = new FR_FISCAL_iRGImprimirTexto_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIRGFecharECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iRGFechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoICFAbrirECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFBPAbrir_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFBPAbrir_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFBPVenderECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iCFBPVender_ECF_Daruma FormPrincipal = new FR_FISCAL_iCFBPVender_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoILeituraXECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iLeituraX_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRLeituraXECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rLeituraX_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRLeituraXCustomizadaECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rLeituraXCustomizada_ECF_Daruma FormPrincipal = new FR_FISCAL_rLeituraXCustomizada_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIReducaoZECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iReducaoZ_ECF_Daruma("","");
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoISangriaPadraoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iSangriaPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoISangriaECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iSangria_ECF_Daruma FormPrincipal = new FR_FISCAL_iSangria_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoISuprimentoPadraoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iSuprimentoPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoISuprimentoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iSuprimento_ECF_Daruma FormPrincipal = new FR_FISCAL_iSuprimento_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIMFLerECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iMFLer_ECF_Daruma FormPrincipal = new FR_FISCAL_iMFLer_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoIMFLerSerialECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iMFLerSerial_ECF_Daruma FormPrincipal = new FR_FISCAL_iMFLerSerial_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoConfCadastrarPadraoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_confCadastrarPadrao_ECF_Daruma FormPrincipal = new FR_FISCAL_confCadastrarPadrao_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoICFBPProgramarUFECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_confCFBPProgramarUF_ECF_Daruma FormPrincipal = new FR_FISCAL_confCFBPProgramarUF_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoConfCadastrarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_confCadastrar_ECF_Daruma FormPrincipal = new FR_FISCAL_confCadastrar_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void habilitarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.confHabilitarHorarioVerao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void desabilitarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.confDesabilitarHorarioVerao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void habilitarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.confHabilitarModoPreVenda_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void desabilitarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.confDesabilitarModoPreVenda_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoConfProgramarIDLojaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_confProgramarIDLoja_ECF_Daruma FormPrincipal = new FR_FISCAL_confProgramarIDLoja_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Não Implementado no Exemplo");
        }

        private void métodoRGerarRelatorioECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void métodoIAbrirGavetaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_eAcionarGuilhotina_ECF_Daruma FormPrincipal = new FR_FISCAL_eAcionarGuilhotina_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRGerarRelatorioOffLineECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRAssinarRSAECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rAssinarRSA_ECF_Daruma FormPrincipal = new FR_FISCAL_rAssinarRSA_ECF_Daruma();
            FormPrincipal.Show();
        }   

        private void métToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rStatusImpressora_ECF_Daruma FormPrincipal = new FR_FISCAL_rStatusImpressora_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRStatusImpressoraIntECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void MS_Metodos_RetornosECF_Click(object sender, EventArgs e)
        {
            FR_FISCAL_RetornoECF FormPrincipal = new FR_FISCAL_RetornoECF();
            FormPrincipal.Show();
        }

        private void MN_Metodos_Cupom_ManiaRJ_Click(object sender, EventArgs e)
        {

        }

        private void métodoRCMGerarRelatorioECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarRelatorio_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarRelatorio_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRGerarRelatorioOffECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarRelatorioOffline_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRegAlterarValorECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void métodoEAbrirGavetaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eAbrirGaveta_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void MN_Metodos_Registry_Click(object sender, EventArgs e)
        {

        }

        private void especiaisDarumaFrameworkToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void lXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iLeituraX_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void lMDCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_LMFS FormPrincipal = new FR_FISCAL_MenuFiscal_LMFS();
            FormPrincipal.Show();
        }

        private void lMFSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_LMFC FormPrincipal = new FR_FISCAL_MenuFiscal_LMFC();
            FormPrincipal.Show();
            
        }

        private void modoPréVendaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void espelhoMFDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void MN_Metodos_MenuFiscal_Click(object sender, EventArgs e)
        {

        }

        private void MN_Metodos_Cheque_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void métodoConfProgramarOperadorECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_confProgramarOperador_ECF_Daruma FormPrincipal = new FR_FISCAL_confProgramarOperador_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void arqMFDToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tabProdToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tabProdToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void estoqueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void movimentoPorECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void meiosDePToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void identificaçãoDoPAFECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void vendasDoPeríodoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void tabIndiceTécnicoProduçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void arqMFDToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FR_FISCAL_ArquivoMFD FormPrincipal = new FR_FISCAL_ArquivoMFD();
            FormPrincipal.Show();
        }

        private void MN_Metodos_Relatorios_Fiscais_Click(object sender, EventArgs e)
        {

        }

        private void MN_Metodos_Programacao_Impressora_Click(object sender, EventArgs e)
        {

        }

        private void métodoRCalcularMD5EToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rCalcularMD5_ECF_Daruma FormPrincipal = new FR_FISCAL_rCalcularMD5_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rRetornarGTCodificado_ECF_Daruma FormPrincipal = new FR_FISCAL_rRetornarGTCodificado_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void dAVEmitidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void encerrantesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void transfMesasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void mesasAbertasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void manifestoFiscalDeViagemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_MenuFiscal_Info FormPrincipal = new FR_FISCAL_MenuFiscal_Info();
            FormPrincipal.Show();
        }

        private void MN_Metodos_TEF_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void exemplosToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void cNFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void cupomFiscalCompletoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void cupomFiscalResumidoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void cupomFiscalPreVendaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Métodos ainda não Implementados..Aguarde!!");
        }

        private void cupomManiaParaOEstadoDoRJToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void configuraçãoCupomManiaToolStripMenuItem_Click(object sender, EventArgs e)
        {
                   
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Path e a chave:", "Daruma Framework", @"ECF\CF\CupomMania", posX, posY);
            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor:", "Daruma Framework", "1", posX, posY);
            
            MessageBox.Show(Str_Produto_Chave + "=" + Str_Valor_Produto_Chave);

            Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(Str_Produto_Chave, Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string prompt = "Informe seu número de usuário";

            string titulo = "Número de Usuário";

            string padrao = "";

            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string ret = Microsoft.VisualBasic.Interaction.InputBox(prompt, titulo, padrao, posX, posY);



            MessageBox.Show(ret);
        }

        private void testedeVendadeItensSemPararBuferizandoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_TesteDeVendaDeItensSemPararBuferizando FormPrincipal = new FR_FISCAL_TesteDeVendaDeItensSemPararBuferizando();
            FormPrincipal.Show();
        }

        private void testeDeConsumoDeMFDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_Teste_Consumo_MFD FormPrincipal = new FR_FISCAL_Teste_Consumo_MFD();
            FormPrincipal.Show();
        }

        private void MN_Metodos_Cupom_Click(object sender, EventArgs e)
        {

        }

        private void métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);
                       
            string ValorGT = Microsoft.VisualBasic.Interaction.InputBox("Entre com GT Codificado:", "Daruma Framework", "", posX, posY).ToString();
           
            Declaracoes.iRetorno = Declaracoes.rVerificarGTCodificado_ECF_Daruma(ValorGT);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            
        }

        private void métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Serial = Microsoft.VisualBasic.Interaction.InputBox("Digite o Numero Serial Codificado:", "Daruma Framework", "", posX, posY);

            Declaracoes.iRetorno = Declaracoes.rVerificarNumeroSerieCodificado_ECF_Daruma(Str_Serial);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);



            
        }

        private void métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_SerialCodificado = new StringBuilder();
            Declaracoes.iRetorno = Declaracoes.rRetornarNumeroSerieCodificado_ECF_Daruma(Str_SerialCodificado);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Serial = Microsoft.VisualBasic.Interaction.InputBox("Numero Serial Codificado:", "Daruma Framework", Str_SerialCodificado.ToString(), posX, posY);
               
        }

        private void métodoRegAlterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Path e a chave:", "Daruma Framework", @"ECF\Auditoria", posX, posY);
            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor:", "Daruma Framework", "1", posX, posY);

            MessageBox.Show(Str_Produto_Chave + "=" + Str_Valor_Produto_Chave);

            Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(Str_Produto_Chave, Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegRetornaValorChaveECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);
            StringBuilder Str_Valor = new StringBuilder();
            string Str_Produto = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Produto:", "Daruma Framework", "ECF", posX, posY);
            string Str_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com a Chave:", "Daruma Framework", "Auditoria", posX, posY);

            

            Declaracoes.iRetorno = Declaracoes.regRetornaValorChave_DarumaFramework(Str_Produto,Str_Chave, Str_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            MessageBox.Show("Valor da Chave = " + Str_Valor);
        }

        private void métodoRegLoginDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave:", "Daruma Framework", "111111111111111111111", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFCupomAdicionalDllConfig_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave:", "Daruma Framework", "Via Motorista", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFCupomAdicionalDllConfig_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFCupomManiaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave:", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFCupomMania(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFFormaPgtoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Forma de Pagamento:", "Daruma Framework", "Dinheiro", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFFormaPgto_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);


        }

        private void métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com a Mensagem Promocional:", "Daruma Framework", "Obrigado e volte sempre!", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFMensagemPromocional_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFQuantidadeECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com a Quantidade:", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFQuantidade_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Tamanho Minimo da Descrição:", "Daruma Framework", "15", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFTamanhoMinimoDescricao_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o TipoAcrescimo ou Desconto:", "Daruma Framework", "$", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFTipoDescAcresc_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);    
        }

        private void métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com a Unidade de Medida:", "Daruma Framework", "UN", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFUnidadeMedida_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor do Desconto ou Acrescimo", "Daruma Framework", "0,10", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCFValorDescAcresc_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

     
        private void métodoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCCDDocOrigem_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métodoRegCCFormaPgtoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "Cartao", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCCDFormaPgto_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "4", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCCDLinhasTEF_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métodoRegCCDParcelasECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCCDParcelas_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métodoRegCCDValorECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor:", "Daruma Framework", "0,10", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regCCDValor_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFAguardarImpressao_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
    
        }

        private void métoRegECFArquivoLeituraECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", @"c:\", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFArquivoLeituraX_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFAuditoria_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
      
        }

        private void métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "|", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFCaracterSeparador_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "0", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFMaxFechamentoAutomatico_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", @"C:\", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFReceberAvisoEmArquivo_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "0", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFReceberErroEmArquivo_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "0", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFReceberInfoEstendida_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor da Chave", "Daruma Framework", "0", posX, posY);

            Declaracoes.iRetorno = Declaracoes.regECFReceberInfoEstendidaEmArquivo_ECF_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRegAtocotepeECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Path e a chave:", "Daruma Framework", "LocalArquivos", posX, posY);
            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Valor:", "Daruma Framework", @"C:\", posX, posY);

            MessageBox.Show(Str_Produto_Chave + "=" + Str_Valor_Produto_Chave);

            Declaracoes.iRetorno = Declaracoes.regAtocotepe_ECF_Daruma(Str_Produto_Chave, Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoEDefinirProdutoDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com o Produto:", "Daruma Framework", "FISCAL", posX, posY);

            Declaracoes.iRetorno = Declaracoes.eDefinirProduto_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoEDefinirModoRegistroDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Valor_Produto_Chave = Microsoft.VisualBasic.Interaction.InputBox("Entre com modo Registro:", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.eDefinirModoRegistro_Daruma(Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoERetornarAvisoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eRetornarAviso_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);


        }

        private void métodoERetornarErroECFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eRetornarErro_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eAguardarCompactacao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void iTEFFecharToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iTEF_Fechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void eTEFEsperarArquivoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma FormPrincipal = new FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void eTEFTravarTecladoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
            MessageBox.Show("Seu Teclado Ficara Travado por 5 segundos Pressione Enter para começar!!!", "DarumaFramework");
            Declaracoes.iRetorno = Declaracoes.eTEF_TravarTeclado_ECF_Daruma(true);
             Thread.Sleep(5000);
            Declaracoes.iRetorno = Declaracoes.eTEF_TravarTeclado_ECF_Daruma(false);
            MessageBox.Show("Seu Teclado foi Destravado!!!", "Daruma Framework");
        }

        private void eTEFSetarFocoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);

            string Str_Titulo = Microsoft.VisualBasic.Interaction.InputBox("Entre com o título da Janela que você deseja setar o foco:", "Daruma Framework", "", posX, posY);
           
           Declaracoes.iRetorno = Declaracoes.eTEF_SetarFoco_ECF_Daruma(Str_Titulo);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void iTEFImprimirRespostaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iTEF_ImprimirResposta_ECF_Daruma FormPrincipal = new FR_FISCAL_iTEF_ImprimirResposta_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_iTEF_ImprimirRespostaCartao_ECF_Daruma FormPrincipal = new FR_FISCAL_iTEF_ImprimirRespostaCartao_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoERSAAssinarArquivoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_eRSAAssinar FormPrincipal = new FR_FISCAL_eRSAAssinar();
            FormPrincipal.Show();
        }

        private void métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma FormPrincipal = new FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma();
            FormPrincipal.Show();
        }

               
    }
}
