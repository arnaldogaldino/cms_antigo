﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_eAcionarGuilhotina_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.GRB_AcionarGuilhotina = new System.Windows.Forms.GroupBox();
            this.RB_CorteTotal = new System.Windows.Forms.RadioButton();
            this.RB_CorteParcial = new System.Windows.Forms.RadioButton();
            this.GRB_AcionarGuilhotina.SuspendLayout();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(161, 105);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 91;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(80, 105);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(77, 23);
            this.BT_Enviar.TabIndex = 90;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // GRB_AcionarGuilhotina
            // 
            this.GRB_AcionarGuilhotina.Controls.Add(this.RB_CorteTotal);
            this.GRB_AcionarGuilhotina.Controls.Add(this.RB_CorteParcial);
            this.GRB_AcionarGuilhotina.Location = new System.Drawing.Point(12, 12);
            this.GRB_AcionarGuilhotina.Name = "GRB_AcionarGuilhotina";
            this.GRB_AcionarGuilhotina.Size = new System.Drawing.Size(226, 78);
            this.GRB_AcionarGuilhotina.TabIndex = 92;
            this.GRB_AcionarGuilhotina.TabStop = false;
            this.GRB_AcionarGuilhotina.Text = "Acionar Guilhotina";
            this.GRB_AcionarGuilhotina.Enter += new System.EventHandler(this.groupBox1_Enter_1);
            // 
            // RB_CorteTotal
            // 
            this.RB_CorteTotal.AutoSize = true;
            this.RB_CorteTotal.Location = new System.Drawing.Point(132, 37);
            this.RB_CorteTotal.Name = "RB_CorteTotal";
            this.RB_CorteTotal.Size = new System.Drawing.Size(77, 17);
            this.RB_CorteTotal.TabIndex = 1;
            this.RB_CorteTotal.TabStop = true;
            this.RB_CorteTotal.Text = "Corte Total";
            this.RB_CorteTotal.UseVisualStyleBackColor = true;
            this.RB_CorteTotal.Enter += new System.EventHandler(this.RB_CorteTotal_Enter);
            // 
            // RB_CorteParcial
            // 
            this.RB_CorteParcial.AutoSize = true;
            this.RB_CorteParcial.Location = new System.Drawing.Point(6, 37);
            this.RB_CorteParcial.Name = "RB_CorteParcial";
            this.RB_CorteParcial.Size = new System.Drawing.Size(85, 17);
            this.RB_CorteParcial.TabIndex = 0;
            this.RB_CorteParcial.TabStop = true;
            this.RB_CorteParcial.Text = "Corte Parcial";
            this.RB_CorteParcial.UseVisualStyleBackColor = true;
            this.RB_CorteParcial.Click += new System.EventHandler(this.RB_CorteParcial_Click);
            this.RB_CorteParcial.Enter += new System.EventHandler(this.RB_CorteParcial_Enter);
            this.RB_CorteParcial.CheckedChanged += new System.EventHandler(this.RB_CorteParcial_CheckedChanged);
            // 
            // FR_FISCAL_eAcionarGuilhotina_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(250, 140);
            this.Controls.Add(this.GRB_AcionarGuilhotina);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_eAcionarGuilhotina_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "eAcionarGuilhotina_ECF_Daruma";
            this.GRB_AcionarGuilhotina.ResumeLayout(false);
            this.GRB_AcionarGuilhotina.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.GroupBox GRB_AcionarGuilhotina;
        private System.Windows.Forms.RadioButton RB_CorteTotal;
        private System.Windows.Forms.RadioButton RB_CorteParcial;
    }
}