using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using System.Threading;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_tEnviarComando : Form
    {
        public FR_MODEM_tEnviarComando()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            string sComando;
            int iTamResposta;
            string sResposta;


            sResposta = new string(' ', 5000);

            sComando = TB_ComandoEnviado.Text + '\x0d';
            iTamResposta = int.Parse(TB_Tamanho.Text);

            if (TB_ComandoEnviado.Text == "")
            {
                MessageBox.Show("� preciso digitar o comando CMD para executar com o Modem", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {

                DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.tEnviarComando_MODEM_DarumaFramework(sComando, ref sResposta, iTamResposta);
            }
            
            if (DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno == 1)
            {
                MessageBox.Show("Comando executado com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_RespostaModem.Text = sResposta;
            }
            else
            {
                MessageBox.Show("Erro ao executar o comando.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TB_RespostaModem.Text = sResposta;
            }

        }
    }
}