﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFCancelarUltimoItemParcial_ECF : Form
    {
        public FR_FISCAL_iCFCancelarUltimoItemParcial_ECF()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Qtde;

            Str_Qtde = TB_Qtde.Text.Trim();
            Declaracoes.iRetorno = Declaracoes.iCFCancelarUltimoItemParcial_ECF_Daruma(Str_Qtde);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }
    }
}
