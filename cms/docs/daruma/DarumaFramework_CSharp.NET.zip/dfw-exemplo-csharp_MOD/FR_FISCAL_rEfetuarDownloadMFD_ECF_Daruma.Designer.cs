﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_rEfetuarDownloadMFD_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_FECHAR = new System.Windows.Forms.Button();
            this.BT_GerarRelatorio = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.BT_LocalArquivos = new System.Windows.Forms.Button();
            this.TB_LocalArquivos = new System.Windows.Forms.TextBox();
            this.TB_Final = new System.Windows.Forms.TextBox();
            this.TB_Inicial = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DTP_DataFinal = new System.Windows.Forms.DateTimePicker();
            this.DTP_DataInicial = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.CBO_Tipo = new System.Windows.Forms.ComboBox();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BT_FECHAR
            // 
            this.BT_FECHAR.Location = new System.Drawing.Point(197, 162);
            this.BT_FECHAR.Name = "BT_FECHAR";
            this.BT_FECHAR.Size = new System.Drawing.Size(75, 23);
            this.BT_FECHAR.TabIndex = 9;
            this.BT_FECHAR.Text = "Fechar";
            this.BT_FECHAR.UseVisualStyleBackColor = true;
            // 
            // BT_GerarRelatorio
            // 
            this.BT_GerarRelatorio.Location = new System.Drawing.Point(93, 162);
            this.BT_GerarRelatorio.Name = "BT_GerarRelatorio";
            this.BT_GerarRelatorio.Size = new System.Drawing.Size(91, 23);
            this.BT_GerarRelatorio.TabIndex = 8;
            this.BT_GerarRelatorio.Text = "Gerar Relatório";
            this.BT_GerarRelatorio.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.BT_LocalArquivos);
            this.groupBox2.Controls.Add(this.TB_LocalArquivos);
            this.groupBox2.Controls.Add(this.TB_Final);
            this.groupBox2.Controls.Add(this.TB_Inicial);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.DTP_DataFinal);
            this.groupBox2.Controls.Add(this.DTP_DataInicial);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.CBO_Tipo);
            this.groupBox2.Location = new System.Drawing.Point(6, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(281, 144);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Intervalo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Local Arquivo";
            // 
            // BT_LocalArquivos
            // 
            this.BT_LocalArquivos.Location = new System.Drawing.Point(208, 113);
            this.BT_LocalArquivos.Name = "BT_LocalArquivos";
            this.BT_LocalArquivos.Size = new System.Drawing.Size(30, 23);
            this.BT_LocalArquivos.TabIndex = 9;
            this.BT_LocalArquivos.Text = "...";
            this.BT_LocalArquivos.UseVisualStyleBackColor = true;
            // 
            // TB_LocalArquivos
            // 
            this.TB_LocalArquivos.Location = new System.Drawing.Point(18, 116);
            this.TB_LocalArquivos.Name = "TB_LocalArquivos";
            this.TB_LocalArquivos.Size = new System.Drawing.Size(179, 20);
            this.TB_LocalArquivos.TabIndex = 8;
            // 
            // TB_Final
            // 
            this.TB_Final.Location = new System.Drawing.Point(138, 65);
            this.TB_Final.Name = "TB_Final";
            this.TB_Final.Size = new System.Drawing.Size(100, 20);
            this.TB_Final.TabIndex = 7;
            this.TB_Final.Visible = false;
            // 
            // TB_Inicial
            // 
            this.TB_Inicial.Location = new System.Drawing.Point(18, 65);
            this.TB_Inicial.Name = "TB_Inicial";
            this.TB_Inicial.Size = new System.Drawing.Size(100, 20);
            this.TB_Inicial.TabIndex = 6;
            this.TB_Inicial.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(139, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Final";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Inicial";
            // 
            // DTP_DataFinal
            // 
            this.DTP_DataFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_DataFinal.Location = new System.Drawing.Point(138, 65);
            this.DTP_DataFinal.Name = "DTP_DataFinal";
            this.DTP_DataFinal.Size = new System.Drawing.Size(98, 20);
            this.DTP_DataFinal.TabIndex = 3;
            this.DTP_DataFinal.Value = new System.DateTime(2011, 1, 18, 0, 0, 0, 0);
            // 
            // DTP_DataInicial
            // 
            this.DTP_DataInicial.CustomFormat = "";
            this.DTP_DataInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_DataInicial.Location = new System.Drawing.Point(18, 65);
            this.DTP_DataInicial.Name = "DTP_DataInicial";
            this.DTP_DataInicial.Size = new System.Drawing.Size(100, 20);
            this.DTP_DataInicial.TabIndex = 2;
            this.DTP_DataInicial.Value = new System.DateTime(2011, 1, 18, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Por:";
            // 
            // CBO_Tipo
            // 
            this.CBO_Tipo.FormattingEnabled = true;
            this.CBO_Tipo.Items.AddRange(new object[] {
            "1_Intervalo de datas",
            "2_Intervalo de COO",
            "3_Intervalo de Data Movimento"});
            this.CBO_Tipo.Location = new System.Drawing.Point(47, 16);
            this.CBO_Tipo.Name = "CBO_Tipo";
            this.CBO_Tipo.Size = new System.Drawing.Size(169, 21);
            this.CBO_Tipo.TabIndex = 0;
            this.CBO_Tipo.Text = "1_Intervalo de datas";
            // 
            // FR_FISCAL_rEfetuarDownloadMFD_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 194);
            this.Controls.Add(this.BT_FECHAR);
            this.Controls.Add(this.BT_GerarRelatorio);
            this.Controls.Add(this.groupBox2);
            this.Name = "FR_FISCAL_rEfetuarDownloadMFD_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "rEfetuarDownloadMFD_ECF_Daruma";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BT_FECHAR;
        private System.Windows.Forms.Button BT_GerarRelatorio;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BT_LocalArquivos;
        private System.Windows.Forms.TextBox TB_LocalArquivos;
        private System.Windows.Forms.TextBox TB_Final;
        private System.Windows.Forms.TextBox TB_Inicial;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker DTP_DataFinal;
        private System.Windows.Forms.DateTimePicker DTP_DataInicial;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CBO_Tipo;
    }
}