﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_RetornoECF : Form
    {
        public FR_FISCAL_RetornoECF()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FR_FISCAL_RetornoECF_Load(object sender, EventArgs e)
        {

        }

        private void métodoRRetornarInformacaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rRetornarInformacao_ECF_Daruma FormPrincipal = new FR_FISCAL_rRetornarInformacao_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRLerAliquotasECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Aliquotas = new StringBuilder();
            
            Declaracoes.iRetorno = Declaracoes.rLerAliquotas_ECF_Daruma(Str_Aliquotas);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            
            TB_Retorno.Text  = Str_Aliquotas.ToString().Trim();

        }

        private void métodoRLerMeiosPagtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Pagamentos = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rLerMeiosPagto_ECF_Daruma(Str_Pagamentos);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            TB_Retorno.Text = Str_Pagamentos.ToString().Trim();
        }

        private void métodoRLerRGECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_RG = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rLerRG_ECF_Daruma(Str_RG);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Str_RG.ToString(); ;
        }

        private void métodoRLerDecimaisECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Quantidade = new StringBuilder();
            StringBuilder Str_Valor = new StringBuilder();
            int Int_Quantidade = new int();
            int Int_Valor = new int();

            Declaracoes.iRetorno = Declaracoes.rLerDecimais_ECF_Daruma(Str_Quantidade, Str_Valor,ref Int_Quantidade,ref Int_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = " String Quantidade: " + Str_Quantidade.ToString().Trim() + "  Valor: " + Str_Valor.ToString().Trim();
            TB_Retorno.Text += System.Environment.NewLine+" Inteiro Quantidade: " + Int_Quantidade + "  Valor: " + Int_Valor;
        }

        private void métodoRLerDecimaisIntECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int Int_Quantidade = new int();
            int Int_Valor = new int();

            Declaracoes.iRetorno = Declaracoes.rLerDecimaisInt_ECF_Daruma(ref Int_Quantidade, ref Int_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Quantidade: " + Int_Quantidade.ToString() + "  Valor: " + Int_Valor.ToString();

        }

        private void métodoRLerDecimaisStrECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Quantidade = new StringBuilder();
            StringBuilder Str_Valor = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rLerDecimaisStr_ECF_Daruma(Str_Quantidade, Str_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Quantidade: " + Str_Quantidade.ToString().Trim() + " Valor: " + Str_Valor.ToString().Trim();
        }

        private void métodoRDataHoraImpressoraECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Data = new StringBuilder();
            StringBuilder Str_Hora = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rDataHoraImpressora_ECF_Daruma(Str_Data, Str_Hora);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Data: " + Str_Data.ToString().Trim() + " Hora: " + Str_Hora.ToString().Trim();
        }

        private void métodoRVerificarReducaoZECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_ZPendente = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rVerificarReducaoZ_ECF_Daruma(Str_ZPendente);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Str_ZPendente.ToString().Trim();
            
        }

        private void métodoRRetornarDadosReducaoZECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_DadosReducaoZ = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rRetornarDadosReducaoZ_ECF_Daruma(Str_DadosReducaoZ);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Str_DadosReducaoZ.ToString();
        }

        private void métodoRStatusImpressoraECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Status = new StringBuilder(15);
 
            Declaracoes.iRetorno = Declaracoes.rStatusImpressora_ECF_Daruma(Str_Status);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Status Impressora String: " + Str_Status.ToString();
        }

        private void métodoRStatusUltimoCmdECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Erro = new StringBuilder();
            StringBuilder Str_Aviso = new StringBuilder();
            int Int_Erro = new int();
            int Int_Aviso = new int();

            Declaracoes.iRetorno = Declaracoes.rStatusUltimoCmd_ECF_Daruma(Str_Erro, Str_Aviso, ref Int_Erro, ref Int_Aviso);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Clear();
            TB_Retorno.Text += "Status String, Erro: " + Str_Erro;
            TB_Retorno.Text += " Aviso: " + Str_Aviso;
            TB_Retorno.Text += System.Environment.NewLine+"Status Inteiro, Erro: " + Int_Erro.ToString();
            TB_Retorno.Text += " Aviso: " + Int_Aviso.ToString();
           
        }

        private void métodoRStatusUltimoCmdIntECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int Int_Erro = new int();
            int Int_Aviso = new int();

            Declaracoes.iRetorno = Declaracoes.rStatusUltimoCmdInt_ECF_Daruma(ref Int_Erro, ref Int_Aviso);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Status Inteiro, Erro: " + Int_Erro.ToString() + "  Aviso: "+Int_Aviso.ToString();

        }

        private void métodoRStatusUltimoCmdStrECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Erro = new StringBuilder();
            StringBuilder Str_Aviso = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rStatusUltimoCmdStr_ECF_Daruma(Str_Erro, Str_Aviso);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Status String, Erro: " + Str_Erro.ToString().Trim();
            TB_Retorno.Text += System.Environment.NewLine + "Aviso: " + Str_Aviso.ToString().Trim();
        
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void métodoRCFSubTotalECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void métodoRSaldoAPagarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
                    }

        private void métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void métodoRStatusImpressoraStrECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Status = new StringBuilder();
            Declaracoes.iRetorno = Declaracoes.rStatusImpressoraStr_ECF_Daruma(Str_Status);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Str_Status.ToString();
        }

        private void métodoRStatusImpressoraIntECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int Int_Status = new int();

            Declaracoes.iRetorno = Declaracoes.rStatusImpressoraInt_ECF_Daruma(ref Int_Status);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Int_Status.ToString();
        }

        private void métodoRVerificarImpressoraLigadaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            if (Declaracoes.iRetorno.Equals(1))
            {
                TB_Retorno.Text = "1 - Impressora Ligada.";
            }

        }

        private void métodoRRetornarNumeroSerieECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void métodoRRetornarGTCodificadoECFDarumToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void métodoRCFSaldoAPagarECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_SaldoAPagar = new StringBuilder(18);
            Declaracoes.iRetorno = Declaracoes.rCFSaldoAPagar_ECF_Daruma(Str_SaldoAPagar);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Saldo a Pagar: " + Str_SaldoAPagar.ToString();

        }

        private void métodoRCFSubTotalECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder Str_SubTotal = new StringBuilder(13);

            Declaracoes.iRetorno = Declaracoes.rCFSubTotal_ECF_Daruma(Str_SubTotal);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = Str_SubTotal.ToString();
        }

        private void métodoRCMEfetuarCalculoECFDarumaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder Str_ISS = new StringBuilder(13);
            StringBuilder Str_ICMS = new StringBuilder(13);

            Declaracoes.iRetorno = Declaracoes.rCMEfetuarCalculo_ECF_Daruma(Str_ISS, Str_ICMS);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Calculo ISS:" + Str_ISS.ToString() + "  Calculo ICMS:" + Str_ICMS.ToString(); 
        }

        private void métodoEBuscarPortaVelocidadeECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eBuscarPortaVelocidade_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void métodoRCFVerificaStatusECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Status = new StringBuilder(2);
            int Int_Status = new int();
            Declaracoes.iRetorno = Declaracoes.rCFVerificarStatus_ECF_Daruma(Str_Status, ref Int_Status);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Status String: "+ Str_Status.ToString();
            TB_Retorno.Text += System.Environment.NewLine +"Status Inteiro: "+ Int_Status.ToString();
        }

        private void métodoEVerificarVersaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder  Str_Versao = new StringBuilder (10);
            Declaracoes.iRetorno = Declaracoes.eVerificarVersaoDLL_Daruma(Str_Versao);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Versão DLL: "+Str_Versao.ToString();
        }

        private void métodoRInfoEstendida1ECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Info = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rInfoEstentida1_ECF_Daruma(Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Daruma Resposta Estendida1: "+Str_Info.ToString();
        }

        private void métodoRInfoEstendidaECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Str_Info = new string(' ', 40);
            int Int_Info = 1;
            Declaracoes.iRetorno = Declaracoes.rInfoEstentida_ECF_Daruma(Int_Info,ref Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "String Resposta Estendida: "+Str_Info.ToString();
            TB_Retorno.Text += System.Environment.NewLine + "Int Resposta Estendida: " + Int_Info.ToString(); 
        }

        private void métodoRInfoEstendida2ECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Info = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rInfoEstentida2_ECF_Daruma(Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Daruma Resposta Estendida2: " + Str_Info.ToString();
        }

        private void métodoRInfoEstendida3ECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Info = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rInfoEstentida3_ECF_Daruma(Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Daruma Resposta Estendida3: " + Str_Info.ToString();
        }

        private void métodoRInfoEstendida4ECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Info = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rInfoEstentida4_ECF_Daruma(Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Daruma Resposta Estendida4: " + Str_Info.ToString();
        }

        private void métodoRInfoEstendida5ECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_Info = new StringBuilder();

            Declaracoes.iRetorno = Declaracoes.rInfoEstentida4_ECF_Daruma(Str_Info);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Daruma Resposta Estendida5: " + Str_Info.ToString();

        }

        private void eRetornarPortasCOMECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TB_Retorno.Text = string.Empty;
            StringBuilder Str_COM= new StringBuilder(50);
            Declaracoes.iRetorno= Declaracoes.eRetornarPortasCOM_ECF_Daruma(Str_COM);
            TB_Retorno.Text = Str_COM.ToString().Trim();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void iRelatorioConfiguracaoECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iRelatorioConfiguracao_ECF_Daruma();
             Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void métodoRStatusImpressoraBinarioECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder Str_StatusBin = new StringBuilder();
            Declaracoes.iRetorno = Declaracoes.rStatusImpressoraBinario_ECF_Daruma(Str_StatusBin);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Retorno.Text = "Status Binário da Impressora: " + Str_StatusBin.ToString();
        }

        private void métodoRRetornarInformacaoSeparadorECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FR_FISCAL_rRetornarInformacaoSeparador_ECF_Daruma FormPrincipal = new FR_FISCAL_rRetornarInformacaoSeparador_ECF_Daruma();
            FormPrincipal.Show();
        }

        private void métodoRConsultaStatusImpressoraStrECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);
            StringBuilder Str_Valor = new StringBuilder();
            string Str_Indice = Microsoft.VisualBasic.Interaction.InputBox("Informe o Índice desejado:", "Daruma Framework", "1", posX, posY);
            
            Declaracoes.iRetorno = Declaracoes.rConsultaStatusImpressoraStr_ECF_Daruma(Convert.ToInt32(Str_Indice), Str_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            MessageBox.Show("Status = " + Str_Valor);
        }

        private void métodoRConsultaStatusImpressoraIntECFDarumaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int posX = ((SystemInformation.WorkingArea.Width / 2) - 200);

            int posY = ((SystemInformation.WorkingArea.Height / 2) - 200);
            int Int_Valor = 0;
            string Str_Indice = Microsoft.VisualBasic.Interaction.InputBox("Informe o Índice desejado:", "Daruma Framework", "1", posX, posY);

            Declaracoes.iRetorno = Declaracoes.rConsultaStatusImpressoraInt_ECF_Daruma(Convert.ToInt32(Str_Indice), ref Int_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            MessageBox.Show("Status = " + Int_Valor.ToString());
        }

    }
}
