﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iTEF_ImprimirResposta_ECF_Daruma : Form
    {
        public FR_FISCAL_iTEF_ImprimirResposta_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_FecharDocumento_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.iTEF_Fechar_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void BT_CupomFiscal_Click(object sender, EventArgs e)
        {
           
            Declaracoes.iRetorno = Declaracoes.iCFAbrirPadrao_ECF_Daruma();
            Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("II", "0,10", "Produto Teste", "789567893456");
            Declaracoes.iRetorno = Declaracoes.iCFTotalizarCupomPadrao_ECF_Daruma();
            Declaracoes.iRetorno = Declaracoes.iCFEfetuarPagamentoFormatado_ECF_Daruma("2", "00000100");
            Declaracoes.iRetorno = Declaracoes.iCFEncerrarPadrao_ECF_Daruma();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void BT_Tef_Click(object sender, EventArgs e)
        {
            String Str_Path_Arquivo_Resp_TEF;

            Str_Path_Arquivo_Resp_TEF = TB_pathArquivoTEF.Text.Trim();

            if (RB_Sim.Checked == true)
            {
                Declaracoes.iRetorno = Declaracoes.iTEF_ImprimirRespostaCartao_ECF_Daruma(Str_Path_Arquivo_Resp_TEF, true, "2", "00000100");
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            }
            else
            {
                Declaracoes.iRetorno = Declaracoes.iTEF_ImprimirRespostaCartao_ECF_Daruma(Str_Path_Arquivo_Resp_TEF, false, "2", "00000100");
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            }   
        }

        private void BT_LocalArquivos_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string Str_LocalArquivos = openFileDialog1.FileName.ToString();

            TB_pathArquivoTEF.Text = Str_LocalArquivos;
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close(); 
        }
    }
}
