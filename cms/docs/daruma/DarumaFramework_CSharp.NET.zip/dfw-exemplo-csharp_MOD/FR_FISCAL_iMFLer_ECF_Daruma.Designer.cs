﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iMFLer_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_Parametro_Final = new System.Windows.Forms.TextBox();
            this.TB_Parametro_Inicial = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CB_Intervalo = new System.Windows.Forms.ComboBox();
            this.DTP_ParametroInicial = new System.Windows.Forms.DateTimePicker();
            this.DTP_ParametroFinal = new System.Windows.Forms.DateTimePicker();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.RB_Completa = new System.Windows.Forms.RadioButton();
            this.RB_Simplificada = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(354, 111);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 81;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(273, 111);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(77, 23);
            this.BT_Enviar.TabIndex = 80;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_Parametro_Final
            // 
            this.TB_Parametro_Final.Location = new System.Drawing.Point(188, 37);
            this.TB_Parametro_Final.Name = "TB_Parametro_Final";
            this.TB_Parametro_Final.Size = new System.Drawing.Size(98, 20);
            this.TB_Parametro_Final.TabIndex = 79;
            this.TB_Parametro_Final.Text = "000003";
            // 
            // TB_Parametro_Inicial
            // 
            this.TB_Parametro_Inicial.Location = new System.Drawing.Point(81, 37);
            this.TB_Parametro_Inicial.Name = "TB_Parametro_Inicial";
            this.TB_Parametro_Inicial.Size = new System.Drawing.Size(98, 20);
            this.TB_Parametro_Inicial.TabIndex = 78;
            this.TB_Parametro_Inicial.Text = "000001";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.DTP_ParametroFinal);
            this.groupBox1.Controls.Add(this.TB_Parametro_Final);
            this.groupBox1.Controls.Add(this.DTP_ParametroInicial);
            this.groupBox1.Controls.Add(this.TB_Parametro_Inicial);
            this.groupBox1.Controls.Add(this.CB_Intervalo);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 82);
            this.groupBox1.TabIndex = 82;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Intervalo:";
            // 
            // CB_Intervalo
            // 
            this.CB_Intervalo.FormattingEnabled = true;
            this.CB_Intervalo.Items.AddRange(new object[] {
            "DATA",
            "CRZ"});
            this.CB_Intervalo.Location = new System.Drawing.Point(6, 36);
            this.CB_Intervalo.Name = "CB_Intervalo";
            this.CB_Intervalo.Size = new System.Drawing.Size(69, 21);
            this.CB_Intervalo.TabIndex = 0;
            this.CB_Intervalo.Text = "DATA";
            this.CB_Intervalo.SelectedIndexChanged += new System.EventHandler(this.CB_Intervalo_SelectedIndexChanged);
            // 
            // DTP_ParametroInicial
            // 
            this.DTP_ParametroInicial.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_ParametroInicial.Location = new System.Drawing.Point(81, 37);
            this.DTP_ParametroInicial.Name = "DTP_ParametroInicial";
            this.DTP_ParametroInicial.Size = new System.Drawing.Size(98, 20);
            this.DTP_ParametroInicial.TabIndex = 1;
            this.DTP_ParametroInicial.Value = new System.DateTime(2011, 2, 24, 0, 0, 0, 0);
            // 
            // DTP_ParametroFinal
            // 
            this.DTP_ParametroFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DTP_ParametroFinal.Location = new System.Drawing.Point(188, 37);
            this.DTP_ParametroFinal.Name = "DTP_ParametroFinal";
            this.DTP_ParametroFinal.Size = new System.Drawing.Size(98, 20);
            this.DTP_ParametroFinal.TabIndex = 1;
            this.DTP_ParametroFinal.ValueChanged += new System.EventHandler(this.DT_ParametroFinal_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.RB_Simplificada);
            this.groupBox2.Controls.Add(this.RB_Completa);
            this.groupBox2.Location = new System.Drawing.Point(317, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(114, 82);
            this.groupBox2.TabIndex = 83;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tipo Leitura:";
            // 
            // RB_Completa
            // 
            this.RB_Completa.AutoSize = true;
            this.RB_Completa.Checked = true;
            this.RB_Completa.Location = new System.Drawing.Point(6, 19);
            this.RB_Completa.Name = "RB_Completa";
            this.RB_Completa.Size = new System.Drawing.Size(69, 17);
            this.RB_Completa.TabIndex = 0;
            this.RB_Completa.TabStop = true;
            this.RB_Completa.Text = "Completa";
            this.RB_Completa.UseVisualStyleBackColor = true;
            // 
            // RB_Simplificada
            // 
            this.RB_Simplificada.AutoSize = true;
            this.RB_Simplificada.Location = new System.Drawing.Point(6, 53);
            this.RB_Simplificada.Name = "RB_Simplificada";
            this.RB_Simplificada.Size = new System.Drawing.Size(81, 17);
            this.RB_Simplificada.TabIndex = 0;
            this.RB_Simplificada.Text = "Simplificada";
            this.RB_Simplificada.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 13);
            this.label1.TabIndex = 77;
            this.label1.Text = "Parâmetro Inicial:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(185, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 78;
            this.label2.Text = "Parâmetro Final:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 84;
            this.label3.Text = "Por:";
            // 
            // FR_FISCAL_iMFLer_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(439, 142);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_iMFLer_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iMFLer_ECF_Daruma";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_Parametro_Final;
        private System.Windows.Forms.TextBox TB_Parametro_Inicial;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox CB_Intervalo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker DTP_ParametroFinal;
        private System.Windows.Forms.DateTimePicker DTP_ParametroInicial;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton RB_Simplificada;
        private System.Windows.Forms.RadioButton RB_Completa;
    }
}