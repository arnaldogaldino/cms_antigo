﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iTEF_ImprimirRespostaCartao_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BT_FecharDocumento = new System.Windows.Forms.Button();
            this.BT_Tef = new System.Windows.Forms.Button();
            this.BT_CupomFiscal = new System.Windows.Forms.Button();
            this.BT_LocalArquivos = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_pathArquivoTEF = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RB_Nao = new System.Windows.Forms.RadioButton();
            this.RB_Sim = new System.Windows.Forms.RadioButton();
            this.TB_ValorPagto = new System.Windows.Forms.TextBox();
            this.TB_FormaPagto = new System.Windows.Forms.TextBox();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BT_FecharDocumento);
            this.groupBox1.Controls.Add(this.BT_Tef);
            this.groupBox1.Controls.Add(this.BT_CupomFiscal);
            this.groupBox1.Controls.Add(this.BT_LocalArquivos);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TB_pathArquivoTEF);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.TB_ValorPagto);
            this.groupBox1.Controls.Add(this.TB_FormaPagto);
            this.groupBox1.Location = new System.Drawing.Point(5, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 315);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Imprimindo a Resposta do Cartão";
            // 
            // BT_FecharDocumento
            // 
            this.BT_FecharDocumento.Location = new System.Drawing.Point(268, 282);
            this.BT_FecharDocumento.Name = "BT_FecharDocumento";
            this.BT_FecharDocumento.Size = new System.Drawing.Size(117, 23);
            this.BT_FecharDocumento.TabIndex = 16;
            this.BT_FecharDocumento.Text = "Fechar o Documento";
            this.BT_FecharDocumento.UseVisualStyleBackColor = true;
            this.BT_FecharDocumento.Click += new System.EventHandler(this.BT_FecharDocumento_Click);
            // 
            // BT_Tef
            // 
            this.BT_Tef.Location = new System.Drawing.Point(268, 240);
            this.BT_Tef.Name = "BT_Tef";
            this.BT_Tef.Size = new System.Drawing.Size(117, 23);
            this.BT_Tef.TabIndex = 15;
            this.BT_Tef.Text = "Impressão TEF";
            this.BT_Tef.UseVisualStyleBackColor = true;
            this.BT_Tef.Click += new System.EventHandler(this.BT_Tef_Click);
            // 
            // BT_CupomFiscal
            // 
            this.BT_CupomFiscal.Location = new System.Drawing.Point(268, 199);
            this.BT_CupomFiscal.Name = "BT_CupomFiscal";
            this.BT_CupomFiscal.Size = new System.Drawing.Size(117, 23);
            this.BT_CupomFiscal.TabIndex = 14;
            this.BT_CupomFiscal.Text = "Imp. Cupom Fiscal";
            this.BT_CupomFiscal.UseVisualStyleBackColor = true;
            this.BT_CupomFiscal.Click += new System.EventHandler(this.BT_CupomFiscal_Click);
            // 
            // BT_LocalArquivos
            // 
            this.BT_LocalArquivos.Location = new System.Drawing.Point(391, 34);
            this.BT_LocalArquivos.Name = "BT_LocalArquivos";
            this.BT_LocalArquivos.Size = new System.Drawing.Size(30, 23);
            this.BT_LocalArquivos.TabIndex = 13;
            this.BT_LocalArquivos.Text = "...";
            this.BT_LocalArquivos.UseVisualStyleBackColor = true;
            this.BT_LocalArquivos.Click += new System.EventHandler(this.BT_LocalArquivos_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "1) Escolha o Diretorio e o Nome do Arquivo de Resposta:";
            // 
            // TB_pathArquivoTEF
            // 
            this.TB_pathArquivoTEF.Location = new System.Drawing.Point(21, 37);
            this.TB_pathArquivoTEF.Name = "TB_pathArquivoTEF";
            this.TB_pathArquivoTEF.Size = new System.Drawing.Size(364, 20);
            this.TB_pathArquivoTEF.TabIndex = 11;
            this.TB_pathArquivoTEF.Text = "C:\\Tef_Dial\\Resp\\Intpos.001";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(127, 177);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "(obrigatorio)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(127, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "(obrigatorio)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(323, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "(obrigatorio)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(176, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "(obrigatorio)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 287);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(244, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "7) Clique aqui para fechar Vinculado ou Gerencial:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 247);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(206, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "6) Para impressao da resposta clique aqui:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 209);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(229, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "5) Para impressao de Cupom Fiscal clique aqui:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 154);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(103, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "4) Valor Pagamento:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 113);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(123, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "3) Forma de Pagamento:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "2) Deseja Travar Teclado ?";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.RB_Nao);
            this.panel1.Controls.Add(this.RB_Sim);
            this.panel1.Location = new System.Drawing.Point(21, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(149, 28);
            this.panel1.TabIndex = 6;
            // 
            // RB_Nao
            // 
            this.RB_Nao.AutoSize = true;
            this.RB_Nao.Location = new System.Drawing.Point(100, 6);
            this.RB_Nao.Name = "RB_Nao";
            this.RB_Nao.Size = new System.Drawing.Size(48, 17);
            this.RB_Nao.TabIndex = 3;
            this.RB_Nao.Text = "NÃO";
            this.RB_Nao.UseVisualStyleBackColor = true;
            // 
            // RB_Sim
            // 
            this.RB_Sim.AutoSize = true;
            this.RB_Sim.Checked = true;
            this.RB_Sim.Location = new System.Drawing.Point(13, 6);
            this.RB_Sim.Name = "RB_Sim";
            this.RB_Sim.Size = new System.Drawing.Size(44, 17);
            this.RB_Sim.TabIndex = 2;
            this.RB_Sim.TabStop = true;
            this.RB_Sim.Text = "SIM";
            this.RB_Sim.UseVisualStyleBackColor = true;
            // 
            // TB_ValorPagto
            // 
            this.TB_ValorPagto.Location = new System.Drawing.Point(21, 170);
            this.TB_ValorPagto.Name = "TB_ValorPagto";
            this.TB_ValorPagto.Size = new System.Drawing.Size(100, 20);
            this.TB_ValorPagto.TabIndex = 1;
            // 
            // TB_FormaPagto
            // 
            this.TB_FormaPagto.Location = new System.Drawing.Point(21, 129);
            this.TB_FormaPagto.Name = "TB_FormaPagto";
            this.TB_FormaPagto.Size = new System.Drawing.Size(100, 20);
            this.TB_FormaPagto.TabIndex = 1;
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(349, 326);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 76;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FR_FISCAL_iTEF_ImprimirRespostaCartao_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(440, 356);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.groupBox1);
            this.Name = "FR_FISCAL_iTEF_ImprimirRespostaCartao_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iTEF_ImprimirRespostaCartao_ECF_Daruma";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TB_ValorPagto;
        private System.Windows.Forms.TextBox TB_FormaPagto;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RB_Nao;
        private System.Windows.Forms.RadioButton RB_Sim;
        private System.Windows.Forms.Button BT_LocalArquivos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_pathArquivoTEF;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button BT_FecharDocumento;
        private System.Windows.Forms.Button BT_Tef;
        private System.Windows.Forms.Button BT_CupomFiscal;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}