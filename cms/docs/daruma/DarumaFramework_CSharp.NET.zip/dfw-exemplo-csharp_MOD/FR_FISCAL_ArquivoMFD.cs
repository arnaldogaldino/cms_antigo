﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_ArquivoMFD : Form
    {
        public FR_FISCAL_ArquivoMFD()
        {
            InitializeComponent();
        }

        private void FR_FISCAL_ArquivoMFD_Load(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void CBO_Tipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CBO_Tipo.SelectedItem.Equals("DATAM"))
            {
                DTP_DataInicial.Visible = true;
                DTP_DataFinal.Visible = true;
                TB_Inicial.Visible = false;
                TB_Final.Visible = false;
            }
            else if (CBO_Tipo.SelectedItem.Equals("COO"))
            {
                DTP_DataInicial.Visible = false;
                DTP_DataFinal.Visible = false;
                TB_Inicial.Visible = true;
                TB_Final.Visible = true;
            }
            else if (CBO_Tipo.SelectedItem.Equals("CRZ"))
            {
                DTP_DataInicial.Visible = false;
                DTP_DataFinal.Visible = false;
                TB_Inicial.Visible = true;
                TB_Final.Visible = true;
            }
        }

        private void BT_FECHAR_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_GerarRelatorio_Click(object sender, EventArgs e)
        {
            string Str_Tipo, Str_ArquivoAtoCotepe,Str_Inicial, Str_Final, Str_Relatorio;
            Str_Relatorio = Str_ArquivoAtoCotepe = string.Empty;

            Str_ArquivoAtoCotepe = TB_ArquivoMF_MFD_TDM.Text;
            if (Str_ArquivoAtoCotepe != null)
            {
                Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"ECF\AtoCotepe\LocalArquivos", Str_ArquivoAtoCotepe);//.regAlterarValor_Daruma(@"ECF\AtoCotepe\LocalArquivos", Str_ArquivoAtoCotepe);
            }

            if (CBO_Tipo.SelectedItem.Equals("COO"))
            {
                Str_Tipo = "COO";
                Str_Inicial = TB_Inicial.Text.Trim();
                Str_Final = TB_Final.Text.Trim();

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorio_ECF_Daruma("MFD+", Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (CBO_Tipo.SelectedItem.Equals("DATAM"))
            {
                Str_Tipo = "DATAM";
                Str_Inicial = DTP_DataInicial.Text.Trim().Replace("/", "");
                Str_Final = DTP_DataFinal.Text.Trim().Replace("/", "");

                Declaracoes.iRetorno = Declaracoes.rGerarRelatorio_ECF_Daruma("MFD+", Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }




        }
    }
}
