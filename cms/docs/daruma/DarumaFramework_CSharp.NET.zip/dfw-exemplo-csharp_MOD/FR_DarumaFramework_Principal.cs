using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using DFW;
using System.Diagnostics;

namespace DarumaFramework_CSharp
{
    public partial class FR_DarumaFramework_Principal : Form
    {
        public FR_DarumaFramework_Principal()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {

            this.DestroyHandle(); //Fechar

        }

        private void BT_HelpOnline_Click(object sender, EventArgs e)
        {

            
            DialogResult stConfirma = MessageBox.Show("Help Online, para acessa-lo � necess�rio conex�o na Internet, caso n�o tenha e necessite do Help entrar em contato com nossa Equipe de Suporte ao Desenvolvedor - 0800 77 0 33 20", "Daruma DLL Framework", MessageBoxButtons.YesNo, MessageBoxIcon.Information);


            if (stConfirma == DialogResult.Yes)
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();

                process.StartInfo.FileName = "http://www.desenvolvedoresdaruma.com.br/home/downloads/Site_2009/HelpOnline/Daruma_Framework.htm";

                process.Start();
            }
           
        }

        private void BT_TA2000_Click(object sender, EventArgs e)
        {

            Declaracoes.eDefinirProduto_Daruma("TA2000");
            FR_MenuTA2000_Principal FormPrincipal = new FR_MenuTA2000_Principal();
            FormPrincipal.Show(); //Abrir Formulario TA2000.
            
        }

        private void BT_NFiscal_Click(object sender, EventArgs e)
        {
            
            Declaracoes.eDefinirProduto_Daruma("DUAL");
            FR_MenuImpressoraDual_Principal FormPrincipal = new FR_MenuImpressoraDual_Principal();
            FormPrincipal.Show(); //Abrir Formulario ImpressoraDual.

        }

        private void FR_DarumaFramework_Principal_Load(object sender, EventArgs e)
        {

        }

        private void BT_Min200_Click(object sender, EventArgs e)
        {
            Declaracoes.eDefinirProduto_Daruma("MODEM");
            FR_MenuMODEM_Principal FormPrincipal = new FR_MenuMODEM_Principal();
            FormPrincipal.Show(); //Abrir Formulario Modem */
        }
         
        private void BT_Fiscal_Click(object sender, EventArgs e)
        {
            Declaracoes.eDefinirProduto_Daruma("ECF");
            FR_MenuImpressoraFiscal_Principal FormPrincipal = new FR_MenuImpressoraFiscal_Principal();
            FormPrincipal.Show(); //Abrir Formulario Impressora Fiscal */

        }

  }

        
  
}
