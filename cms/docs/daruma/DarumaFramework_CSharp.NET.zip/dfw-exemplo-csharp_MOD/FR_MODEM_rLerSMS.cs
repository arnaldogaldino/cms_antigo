using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DarumaFramework_CSharp;
using System.Threading;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rLerSMS : Form
    {
        public FR_MODEM_rLerSMS()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {

            string sResposta;
            int iNumeroSMS;

            iNumeroSMS = 0;
            sResposta = new string(' ', 5000);

            if (TB_NumeroSMS.Text == "")
            {
                MessageBox.Show("� preciso digitar o numero do SMS a ser lido ou 0 para todos os SMS", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                iNumeroSMS = int.Parse(TB_NumeroSMS.Text);
            }

            DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno = DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.rLerSMS_MODEM_DarumaFramework(iNumeroSMS, ref sResposta);

            if (DarumaFramework_DLL.DarumaFramework_Declaracoes_CSharp.iRetorno == 1)
            {
                MessageBox.Show("Mensagens Listadas com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                TB_RespostaModem.Text = sResposta;
            }
            else
            {
                MessageBox.Show("Erro ao listar as mensagens.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                TB_RespostaModem.Text = sResposta;
            }

        }
    }
}