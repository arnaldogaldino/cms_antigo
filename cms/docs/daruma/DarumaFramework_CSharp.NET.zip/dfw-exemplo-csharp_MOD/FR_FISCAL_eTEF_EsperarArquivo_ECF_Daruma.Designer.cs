﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BT_LocalArquivos = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_Tempo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.RB_Nao = new System.Windows.Forms.RadioButton();
            this.RB_Sim = new System.Windows.Forms.RadioButton();
            this.TB_pathArquivoTEF = new System.Windows.Forms.TextBox();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BT_LocalArquivos);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.TB_Tempo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Controls.Add(this.TB_pathArquivoTEF);
            this.groupBox1.Location = new System.Drawing.Point(6, 8);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(444, 174);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Testando o eTEF_EsperarArquivo_ECF_Daruma";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // BT_LocalArquivos
            // 
            this.BT_LocalArquivos.Location = new System.Drawing.Point(389, 32);
            this.BT_LocalArquivos.Name = "BT_LocalArquivos";
            this.BT_LocalArquivos.Size = new System.Drawing.Size(30, 23);
            this.BT_LocalArquivos.TabIndex = 10;
            this.BT_LocalArquivos.Text = "...";
            this.BT_LocalArquivos.UseVisualStyleBackColor = true;
            this.BT_LocalArquivos.Click += new System.EventHandler(this.BT_LocalArquivos_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(125, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "(obrigatorio)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(321, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(62, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "(obrigatorio)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(174, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "(obrigatorio)";
            // 
            // TB_Tempo
            // 
            this.TB_Tempo.Location = new System.Drawing.Point(19, 137);
            this.TB_Tempo.Name = "TB_Tempo";
            this.TB_Tempo.Size = new System.Drawing.Size(100, 20);
            this.TB_Tempo.TabIndex = 4;
            this.TB_Tempo.Text = "10";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(292, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "3) Tempo em espera pelo arquivo de resposta em segundos:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "2) Deseja Travar Teclado ?";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "1) Escolha o Diretorio e o Nome do Arquivo de Resposta:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.RB_Nao);
            this.panel1.Controls.Add(this.RB_Sim);
            this.panel1.Location = new System.Drawing.Point(19, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(149, 28);
            this.panel1.TabIndex = 1;
            // 
            // RB_Nao
            // 
            this.RB_Nao.AutoSize = true;
            this.RB_Nao.Location = new System.Drawing.Point(100, 6);
            this.RB_Nao.Name = "RB_Nao";
            this.RB_Nao.Size = new System.Drawing.Size(48, 17);
            this.RB_Nao.TabIndex = 3;
            this.RB_Nao.Text = "NÃO";
            this.RB_Nao.UseVisualStyleBackColor = true;
            // 
            // RB_Sim
            // 
            this.RB_Sim.AutoSize = true;
            this.RB_Sim.Checked = true;
            this.RB_Sim.Location = new System.Drawing.Point(13, 6);
            this.RB_Sim.Name = "RB_Sim";
            this.RB_Sim.Size = new System.Drawing.Size(44, 17);
            this.RB_Sim.TabIndex = 2;
            this.RB_Sim.TabStop = true;
            this.RB_Sim.Text = "SIM";
            this.RB_Sim.UseVisualStyleBackColor = true;
            // 
            // TB_pathArquivoTEF
            // 
            this.TB_pathArquivoTEF.Location = new System.Drawing.Point(19, 35);
            this.TB_pathArquivoTEF.Name = "TB_pathArquivoTEF";
            this.TB_pathArquivoTEF.Size = new System.Drawing.Size(364, 20);
            this.TB_pathArquivoTEF.TabIndex = 0;
            this.TB_pathArquivoTEF.Text = "C:\\Tef_Dial\\Resp\\Intpos.001";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(366, 188);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 75;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(285, 188);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(77, 23);
            this.BT_Enviar.TabIndex = 74;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(455, 216);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.groupBox1);
            this.Name = "FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "eTEF_EsperarArquivo_ECF_Daruma";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox TB_pathArquivoTEF;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton RB_Nao;
        private System.Windows.Forms.RadioButton RB_Sim;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_Tempo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BT_LocalArquivos;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}