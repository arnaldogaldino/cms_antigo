﻿namespace DarumaFramework_CSharp
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_limparRetorno = new System.Windows.Forms.Button();
            this.ED_RetornoDeFuncoes = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.BT_limparRecebe = new System.Windows.Forms.Button();
            this.BT_rReceberDadosCsd = new System.Windows.Forms.Button();
            this.BT_tEnviarDadosCsd = new System.Windows.Forms.Button();
            this.BT_limparEnvio = new System.Windows.Forms.Button();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.ED_DadosRecebidos = new System.Windows.Forms.TextBox();
            this.ED_dadosEnviados = new System.Windows.Forms.TextBox();
            this.BT_eFinalizarChamadaCsd = new System.Windows.Forms.Button();
            this.BT_eRealizarChamadaCsd = new System.Windows.Forms.Button();
            this.ED_NumTelefone = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.BT_eAtivarConexaoCsd = new System.Windows.Forms.Button();
            this.Label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(524, 444);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(134, 24);
            this.BT_Fechar.TabIndex = 35;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            // 
            // BT_limparRetorno
            // 
            this.BT_limparRetorno.Location = new System.Drawing.Point(384, 444);
            this.BT_limparRetorno.Name = "BT_limparRetorno";
            this.BT_limparRetorno.Size = new System.Drawing.Size(134, 24);
            this.BT_limparRetorno.TabIndex = 34;
            this.BT_limparRetorno.Text = "limparRetorno";
            this.BT_limparRetorno.UseVisualStyleBackColor = true;
            // 
            // ED_RetornoDeFuncoes
            // 
            this.ED_RetornoDeFuncoes.Location = new System.Drawing.Point(166, 418);
            this.ED_RetornoDeFuncoes.Name = "ED_RetornoDeFuncoes";
            this.ED_RetornoDeFuncoes.Size = new System.Drawing.Size(492, 20);
            this.ED_RetornoDeFuncoes.TabIndex = 33;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(18, 421);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(147, 13);
            this.Label5.TabIndex = 32;
            this.Label5.Text = "RETORNOS DAS FUNÇÕES";
            // 
            // BT_limparRecebe
            // 
            this.BT_limparRecebe.Location = new System.Drawing.Point(524, 356);
            this.BT_limparRecebe.Name = "BT_limparRecebe";
            this.BT_limparRecebe.Size = new System.Drawing.Size(134, 33);
            this.BT_limparRecebe.TabIndex = 31;
            this.BT_limparRecebe.Text = "limparRecebe";
            this.BT_limparRecebe.UseVisualStyleBackColor = true;
            // 
            // BT_rReceberDadosCsd
            // 
            this.BT_rReceberDadosCsd.Location = new System.Drawing.Point(356, 356);
            this.BT_rReceberDadosCsd.Name = "BT_rReceberDadosCsd";
            this.BT_rReceberDadosCsd.Size = new System.Drawing.Size(134, 33);
            this.BT_rReceberDadosCsd.TabIndex = 30;
            this.BT_rReceberDadosCsd.Text = "rReceberDadosCsd";
            this.BT_rReceberDadosCsd.UseVisualStyleBackColor = true;
            // 
            // BT_tEnviarDadosCsd
            // 
            this.BT_tEnviarDadosCsd.Location = new System.Drawing.Point(197, 355);
            this.BT_tEnviarDadosCsd.Name = "BT_tEnviarDadosCsd";
            this.BT_tEnviarDadosCsd.Size = new System.Drawing.Size(134, 33);
            this.BT_tEnviarDadosCsd.TabIndex = 29;
            this.BT_tEnviarDadosCsd.Text = "tEnviarDadosCsd";
            this.BT_tEnviarDadosCsd.UseVisualStyleBackColor = true;
            // 
            // BT_limparEnvio
            // 
            this.BT_limparEnvio.Location = new System.Drawing.Point(21, 354);
            this.BT_limparEnvio.Name = "BT_limparEnvio";
            this.BT_limparEnvio.Size = new System.Drawing.Size(134, 35);
            this.BT_limparEnvio.TabIndex = 28;
            this.BT_limparEnvio.Text = "limparEnvio";
            this.BT_limparEnvio.UseVisualStyleBackColor = true;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(453, 174);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(110, 13);
            this.Label4.TabIndex = 27;
            this.Label4.Text = "DADOS RECEBIDOS";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(112, 174);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(103, 13);
            this.Label3.TabIndex = 26;
            this.Label3.Text = "DADOS ENVIADOS";
            // 
            // ED_DadosRecebidos
            // 
            this.ED_DadosRecebidos.Location = new System.Drawing.Point(356, 193);
            this.ED_DadosRecebidos.Multiline = true;
            this.ED_DadosRecebidos.Name = "ED_DadosRecebidos";
            this.ED_DadosRecebidos.Size = new System.Drawing.Size(302, 142);
            this.ED_DadosRecebidos.TabIndex = 25;
            // 
            // ED_dadosEnviados
            // 
            this.ED_dadosEnviados.Location = new System.Drawing.Point(21, 193);
            this.ED_dadosEnviados.Multiline = true;
            this.ED_dadosEnviados.Name = "ED_dadosEnviados";
            this.ED_dadosEnviados.Size = new System.Drawing.Size(310, 142);
            this.ED_dadosEnviados.TabIndex = 24;
            // 
            // BT_eFinalizarChamadaCsd
            // 
            this.BT_eFinalizarChamadaCsd.Location = new System.Drawing.Point(491, 98);
            this.BT_eFinalizarChamadaCsd.Name = "BT_eFinalizarChamadaCsd";
            this.BT_eFinalizarChamadaCsd.Size = new System.Drawing.Size(167, 33);
            this.BT_eFinalizarChamadaCsd.TabIndex = 23;
            this.BT_eFinalizarChamadaCsd.Text = "eFinalizarChamadaCsd";
            this.BT_eFinalizarChamadaCsd.UseVisualStyleBackColor = true;
            // 
            // BT_eRealizarChamadaCsd
            // 
            this.BT_eRealizarChamadaCsd.Location = new System.Drawing.Point(308, 98);
            this.BT_eRealizarChamadaCsd.Name = "BT_eRealizarChamadaCsd";
            this.BT_eRealizarChamadaCsd.Size = new System.Drawing.Size(166, 33);
            this.BT_eRealizarChamadaCsd.TabIndex = 22;
            this.BT_eRealizarChamadaCsd.Text = "eRealizarChamadaCsd";
            this.BT_eRealizarChamadaCsd.UseVisualStyleBackColor = true;
            // 
            // ED_NumTelefone
            // 
            this.ED_NumTelefone.Location = new System.Drawing.Point(137, 111);
            this.ED_NumTelefone.Name = "ED_NumTelefone";
            this.ED_NumTelefone.Size = new System.Drawing.Size(156, 20);
            this.ED_NumTelefone.TabIndex = 21;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(18, 111);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(113, 13);
            this.Label2.TabIndex = 20;
            this.Label2.Text = "Número a ser discado:";
            // 
            // BT_eAtivarConexaoCsd
            // 
            this.BT_eAtivarConexaoCsd.Location = new System.Drawing.Point(236, 33);
            this.BT_eAtivarConexaoCsd.Name = "BT_eAtivarConexaoCsd";
            this.BT_eAtivarConexaoCsd.Size = new System.Drawing.Size(180, 32);
            this.BT_eAtivarConexaoCsd.TabIndex = 19;
            this.BT_eAtivarConexaoCsd.Text = "eAtivarConexaoCsd";
            this.BT_eAtivarConexaoCsd.UseVisualStyleBackColor = true;
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(163, 17);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(311, 13);
            this.Label1.TabIndex = 18;
            this.Label1.Text = "Configuração inicial para o modem que receberá a chamada csd";
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 484);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_limparRetorno);
            this.Controls.Add(this.ED_RetornoDeFuncoes);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.BT_limparRecebe);
            this.Controls.Add(this.BT_rReceberDadosCsd);
            this.Controls.Add(this.BT_tEnviarDadosCsd);
            this.Controls.Add(this.BT_limparEnvio);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.ED_DadosRecebidos);
            this.Controls.Add(this.ED_dadosEnviados);
            this.Controls.Add(this.BT_eFinalizarChamadaCsd);
            this.Controls.Add(this.BT_eRealizarChamadaCsd);
            this.Controls.Add(this.ED_NumTelefone);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.BT_eAtivarConexaoCsd);
            this.Controls.Add(this.Label1);
            this.Name = "Form3";
            this.Text = "Serviço CSD - DarumaFramework";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BT_Fechar;
        internal System.Windows.Forms.Button BT_limparRetorno;
        internal System.Windows.Forms.TextBox ED_RetornoDeFuncoes;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Button BT_limparRecebe;
        internal System.Windows.Forms.Button BT_rReceberDadosCsd;
        internal System.Windows.Forms.Button BT_tEnviarDadosCsd;
        internal System.Windows.Forms.Button BT_limparEnvio;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox ED_DadosRecebidos;
        internal System.Windows.Forms.TextBox ED_dadosEnviados;
        internal System.Windows.Forms.Button BT_eFinalizarChamadaCsd;
        internal System.Windows.Forms.Button BT_eRealizarChamadaCsd;
        internal System.Windows.Forms.TextBox ED_NumTelefone;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Button BT_eAtivarConexaoCsd;
        internal System.Windows.Forms.Label Label1;
    }
}