﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_MenuFiscal_Info : Form
    {
        public FR_FISCAL_MenuFiscal_Info()
        {
            InitializeComponent();
        }

        private void BT_Voltar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
