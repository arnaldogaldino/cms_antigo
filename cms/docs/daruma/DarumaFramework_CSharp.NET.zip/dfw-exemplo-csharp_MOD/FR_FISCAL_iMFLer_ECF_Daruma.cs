﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iMFLer_ECF_Daruma : Form
    {
        public FR_FISCAL_iMFLer_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Parametro_Inicial, Str_Parametro_Final;

            if (CB_Intervalo.Text == "DATA")
            {
                Str_Parametro_Inicial = DTP_ParametroInicial.Text.Trim().Replace("/", "");
                Str_Parametro_Final = DTP_ParametroFinal.Text.Trim().Replace("/", "");

                if (RB_Completa.Checked == true)
                {
                    Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"ECF\LMFCompleta", "1");
                    Declaracoes.iRetorno = Declaracoes.iMFLer_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                    Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                }
                else
                {
                    Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"ECF\LMFCompleta", "0");
                    Declaracoes.iRetorno = Declaracoes.iMFLer_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                    Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                }
            }
            else if (CB_Intervalo.Text == "CRZ")
            {
                Str_Parametro_Inicial = TB_Parametro_Inicial.Text.Trim();
                Str_Parametro_Final = TB_Parametro_Final.Text.Trim();
                if (RB_Completa.Checked == true)
                {
                    Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"ECF\LMFCompleta", "1");
                    Declaracoes.iRetorno = Declaracoes.iMFLer_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                    Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                }
                else
                {
                    Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(@"ECF\LMFCompleta", "0");
                    Declaracoes.iRetorno = Declaracoes.iMFLer_ECF_Daruma(Str_Parametro_Inicial, Str_Parametro_Final);
                    Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                }
            }
           
        }

        private void DT_ParametroFinal_ValueChanged(object sender, EventArgs e)
        {

        }

        private void CB_Intervalo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CB_Intervalo.SelectedItem.Equals("CRZ"))
            {
                DTP_ParametroInicial.Visible = false;
                DTP_ParametroFinal.Visible = false;
                TB_Parametro_Inicial.Text = "000001";
                TB_Parametro_Final.Text = "000003";
            }
            else if (CB_Intervalo.SelectedItem.Equals ("DATA"))
            {
                DTP_ParametroInicial.Visible = true;
                DTP_ParametroFinal.Visible = true;
            }
        }
    }
}
