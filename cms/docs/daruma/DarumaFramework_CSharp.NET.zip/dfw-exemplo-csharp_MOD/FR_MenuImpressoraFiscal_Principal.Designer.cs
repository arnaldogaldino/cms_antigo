﻿namespace DarumaFramework_CSharp
{
    partial class FR_MenuImpressoraFiscal_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FR_MenuImpressoraFiscal_Principal));
            this.LB_DLL = new System.Windows.Forms.Label();
            this.lb_duvidas = new System.Windows.Forms.Label();
            this.LB_Impressoras = new System.Windows.Forms.Label();
            this.PN_Dual = new System.Windows.Forms.Panel();
            this.PB_DDC = new System.Windows.Forms.PictureBox();
            this.BT_fechar = new System.Windows.Forms.Button();
            this.MS_Geral_Fiscal = new System.Windows.Forms.MenuStrip();
            this.MN_Metodos_Cupom = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_AberturaCupomFiscal = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoiCFAbrir_ECF_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFVenderECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarItemParcialECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEncerrarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFCancelarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configuraçãoCupomManiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cupomFiscalCompletoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cupomFiscalResumidoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cupomFiscalPreVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_CCD = new System.Windows.Forms.ToolStripMenuItem();
            this.aberturaCCDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDAbrirECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textoImprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encerrarCCDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDFecharECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.estornoCCDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ªViaDoCCDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tEFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eTEFSetarFocoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iTEFFecharToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testeCompletoTEFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.cCDCompletoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_CNF = new System.Windows.Forms.ToolStripMenuItem();
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFAbrirECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rcebimentoDeItensToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFReceberECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelamentoDeItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelamentoDeDescontoEmItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.totalizacaoDeCNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encerramentoDeCNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelamentoDeCNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICNFCancelarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplosToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.cNFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_RG = new System.Windows.Forms.ToolStripMenuItem();
            this.aberturaRelatórioGerencialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textoImpressãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.encerramentoRelatórioGerencialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIRGFecharECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Bilhete_Passagem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFAbrirECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFBPVenderECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Relatorios_Fiscais = new System.Windows.Forms.ToolStripMenuItem();
            this.leituraXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoILeituraXECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRLeituraXECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.reduçãoZToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIReducaoZECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sangriaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoISangriaECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.suprimentoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoISuprimentoECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.leituraMemóriaFiscalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIMFLerECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Programacao_Impressora = new System.Windows.Forms.ToolStripMenuItem();
            this.eCFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoConfCadastrarECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.horárioDeVerãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.habilitarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desabilitarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.modoPréVendaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.habilitarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.desabilitarToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.avançoPapelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lojaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operadorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MS_Metodos_RetornosECF = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Gaveta_Autentica_E_Outros = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Cheque = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Codigo_Barras = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Registry = new System.Windows.Forms.ToolStripMenuItem();
            this.geralDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cupomFiscalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chequeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cCDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCCDECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegCCDValorECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eCFToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegAlterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegLoginDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.atoCotepeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sintegraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRegSintegraECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.especiaisDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEDefinirProdutoDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoERetornarErroECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Geracao_Arquivos = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_TEF = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_PAF_ECF = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRCalcularMD5EToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_MenuFiscal = new System.Windows.Forms.ToolStripMenuItem();
            this.lXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lMFSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lMDCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.espelhoMFDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arqMFDToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabProdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.estoqueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.movimentoPorECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meiosDePToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vendasDoPeríodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.identificaçãoDoPAFECFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.dAVEmitidosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.encerrantesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transfMesasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mesasAbertasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manifestoFiscalDeViagemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabIndiceTécnicoProduçãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplsoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testeDeConsumoDeMFDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PN_Dual.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).BeginInit();
            this.MS_Geral_Fiscal.SuspendLayout();
            this.SuspendLayout();
            // 
            // LB_DLL
            // 
            this.LB_DLL.AutoSize = true;
            this.LB_DLL.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DLL.Location = new System.Drawing.Point(12, 84);
            this.LB_DLL.Name = "LB_DLL";
            this.LB_DLL.Size = new System.Drawing.Size(204, 16);
            this.LB_DLL.TabIndex = 2;
            this.LB_DLL.Text = "DLL: DarumaFramework.dll";
            // 
            // lb_duvidas
            // 
            this.lb_duvidas.AutoSize = true;
            this.lb_duvidas.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_duvidas.Location = new System.Drawing.Point(12, 362);
            this.lb_duvidas.Name = "lb_duvidas";
            this.lb_duvidas.Size = new System.Drawing.Size(312, 16);
            this.lb_duvidas.TabIndex = 6;
            this.lb_duvidas.Text = "Duvidas? Ligue Gratuito! - 0800 770 33 20";
            // 
            // LB_Impressoras
            // 
            this.LB_Impressoras.AutoSize = true;
            this.LB_Impressoras.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Impressoras.Location = new System.Drawing.Point(12, 19);
            this.LB_Impressoras.Name = "LB_Impressoras";
            this.LB_Impressoras.Size = new System.Drawing.Size(200, 23);
            this.LB_Impressoras.TabIndex = 1;
            this.LB_Impressoras.Text = "Impressora Fiscal";
            // 
            // PN_Dual
            // 
            this.PN_Dual.BackColor = System.Drawing.Color.White;
            this.PN_Dual.Controls.Add(this.LB_DLL);
            this.PN_Dual.Controls.Add(this.LB_Impressoras);
            this.PN_Dual.Controls.Add(this.PB_DDC);
            this.PN_Dual.Location = new System.Drawing.Point(0, 388);
            this.PN_Dual.Name = "PN_Dual";
            this.PN_Dual.Size = new System.Drawing.Size(983, 114);
            this.PN_Dual.TabIndex = 5;
            // 
            // PB_DDC
            // 
            this.PB_DDC.Image = global::DarumaFramework_CSharp.Properties.Resources.logoDDCpeq2;
            this.PB_DDC.Location = new System.Drawing.Point(723, 19);
            this.PB_DDC.Name = "PB_DDC";
            this.PB_DDC.Size = new System.Drawing.Size(185, 81);
            this.PB_DDC.TabIndex = 0;
            this.PB_DDC.TabStop = false;
            // 
            // BT_fechar
            // 
            this.BT_fechar.Location = new System.Drawing.Point(867, 359);
            this.BT_fechar.Name = "BT_fechar";
            this.BT_fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_fechar.TabIndex = 7;
            this.BT_fechar.Text = "Fechar";
            this.BT_fechar.UseVisualStyleBackColor = true;
            this.BT_fechar.Click += new System.EventHandler(this.BT_fechar_Click);
            // 
            // MS_Geral_Fiscal
            // 
            this.MS_Geral_Fiscal.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_Metodos_Cupom,
            this.MN_Metodos_CCD,
            this.MN_Metodos_CNF,
            this.MN_Metodos_RG,
            this.MN_Metodos_Bilhete_Passagem,
            this.MN_Metodos_Relatorios_Fiscais,
            this.MN_Metodos_Programacao_Impressora,
            this.MS_Metodos_RetornosECF,
            this.MN_Metodos_Gaveta_Autentica_E_Outros,
            this.MN_Metodos_Cheque,
            this.MN_Metodos_Codigo_Barras,
            this.MN_Metodos_Registry,
            this.MN_Metodos_Geracao_Arquivos,
            this.MN_Metodos_TEF,
            this.MN_Metodos_PAF_ECF,
            this.MN_Metodos_MenuFiscal,
            this.exemplsoToolStripMenuItem});
            this.MS_Geral_Fiscal.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.MS_Geral_Fiscal.Location = new System.Drawing.Point(0, 0);
            this.MS_Geral_Fiscal.Name = "MS_Geral_Fiscal";
            this.MS_Geral_Fiscal.Size = new System.Drawing.Size(978, 42);
            this.MS_Geral_Fiscal.TabIndex = 9;
            this.MS_Geral_Fiscal.Text = "menuStrip1";
            // 
            // MN_Metodos_Cupom
            // 
            this.MN_Metodos_Cupom.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.MN_Metodos_Cupom.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_AberturaCupomFiscal,
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10,
            this.toolStripMenuItem11,
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem,
            this.toolStripMenuItem14,
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem,
            this.exemplosToolStripMenuItem});
            this.MN_Metodos_Cupom.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.MN_Metodos_Cupom.Name = "MN_Metodos_Cupom";
            this.MN_Metodos_Cupom.Size = new System.Drawing.Size(81, 17);
            this.MN_Metodos_Cupom.Text = "Cupom Fiscal";
            this.MN_Metodos_Cupom.Click += new System.EventHandler(this.MN_Metodos_Cupom_Click);
            // 
            // MN_AberturaCupomFiscal
            // 
            this.MN_AberturaCupomFiscal.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2,
            this.métodoiCFAbrir_ECF_Daruma});
            this.MN_AberturaCupomFiscal.Name = "MN_AberturaCupomFiscal";
            this.MN_AberturaCupomFiscal.Size = new System.Drawing.Size(406, 22);
            this.MN_AberturaCupomFiscal.Text = "Abertura Cupom Fiscal";
            // 
            // métodoICFAbrirPadraoECFDarumaToolStripMenuItem2
            // 
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2.Name = "métodoICFAbrirPadraoECFDarumaToolStripMenuItem2";
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2.Size = new System.Drawing.Size(253, 22);
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2.Text = "Método iCFAbrirPadrao_ECF_Daruma";
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2.ToolTipText = "iCFAbrir_ECF_Daruma(char *pszCPF, char *pszNome,char *pszEndereco)";
            this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2.Click += new System.EventHandler(this.métodoICFAbrirPadraoECFDarumaToolStripMenuItem2_Click_1);
            // 
            // métodoiCFAbrir_ECF_Daruma
            // 
            this.métodoiCFAbrir_ECF_Daruma.Name = "métodoiCFAbrir_ECF_Daruma";
            this.métodoiCFAbrir_ECF_Daruma.Size = new System.Drawing.Size(253, 22);
            this.métodoiCFAbrir_ECF_Daruma.Text = "Método iCFAbrir_ECF_Daruma";
            this.métodoiCFAbrir_ECF_Daruma.ToolTipText = "iCFAbrirPadrao_ECF_Daruma(void)";
            this.métodoiCFAbrir_ECF_Daruma.Click += new System.EventHandler(this.métodoiCFAbrir_ECF_Daruma_Click_1);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFVenderECFDarumaToolStripMenuItem,
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem,
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem1.Text = "Registro de Item";
            // 
            // métodoICFVenderECFDarumaToolStripMenuItem
            // 
            this.métodoICFVenderECFDarumaToolStripMenuItem.Name = "métodoICFVenderECFDarumaToolStripMenuItem";
            this.métodoICFVenderECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.métodoICFVenderECFDarumaToolStripMenuItem.Text = "Método iCFVender_ECF_Daruma";
            this.métodoICFVenderECFDarumaToolStripMenuItem.ToolTipText = resources.GetString("métodoICFVenderECFDarumaToolStripMenuItem.ToolTipText");
            this.métodoICFVenderECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFVenderECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFVenderSemDescECFDarumaToolStripMenuItem
            // 
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem.Name = "métodoICFVenderSemDescECFDarumaToolStripMenuItem";
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem.Text = "Método iCFVenderSemDesc_ECF_Daruma";
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem.ToolTipText = "iCFVenderSemDesc_ECF_Daruma(char *pszCargaTributaria,char *pszQuantidade,char *ps" +
                "zPrecoUnitario,char *pszCodigoItem,char *pszUnidadeMedida,char *pszDescricaoItem" +
                ");";
            this.métodoICFVenderSemDescECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFVenderSemDescECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFVenderResumidoECFDarumaToolStripMenuItem
            // 
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem.Name = "métodoICFVenderResumidoECFDarumaToolStripMenuItem";
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(276, 22);
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem.Text = "Método iCFVenderResumido_ECF_Daruma";
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem.ToolTipText = "iCFVenderResumido_ECF_Daruma(char *pszCargaTributaria,char *pszPrecoUnitario,char" +
                " *pszCodigoItem,char *pszDescricaoItem);";
            this.métodoICFVenderResumidoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFVenderResumidoECFDarumaToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem,
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem,
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem,
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem2.Text = "Desconto ou Acréscimo  em item de Cupom Fiscal";
            // 
            // métodoICFLancarAcrescimoItemECFToolStripMenuItem
            // 
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem.Name = "métodoICFLancarAcrescimoItemECFToolStripMenuItem";
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem.Text = "Método iCFLancarAcrescimoItem_ECF_Daruma";
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem.ToolTipText = "iCFLancarAcrescimoItem_ECF(string pszNumItem, string pszTipoDescAcresc, string ps" +
                "zValorDescAcresc)";
            this.métodoICFLancarAcrescimoItemECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFLancarAcrescimoItemECFToolStripMenuItem_Click_1);
            // 
            // métodoICFLancarDescontoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem.Name = "métodoICFLancarDescontoItemECFDarumaToolStripMenuItem";
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem.Text = "Método iCFLancarDescontoItem_ECF_Daruma";
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem.ToolTipText = "iCFLancarDescontoItem_ECF_Daruma(string pszNumItem, string pszTipoDescAcresc, str" +
                "ing pszValorDescAcresc)";
            this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFLancarDescontoItemECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem
            // 
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem.Name = "métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem";
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem.Text = "Método iCFLancarAcrescimoUltimoItem_ECF_Daruma";
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem.ToolTipText = "iCFLancarAcrescimoUltimoItem_ECF(string pszTipoDescAcresc, string pszValorDescAcr" +
                "esc)";
            this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem_Click_1);
            // 
            // métodoICFLancarDescontoUltimoItemECFToolStripMenuItem
            // 
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem.Name = "métodoICFLancarDescontoUltimoItemECFToolStripMenuItem";
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem.Size = new System.Drawing.Size(327, 22);
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem.Text = "Método iCFLancarDescontoUltimoItem_ECF_Daruma";
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem.ToolTipText = "iCFLancarDescontoUltimoItem_ECF(string pszTipoDescAcresc, string pszValorDescAcre" +
                "sc)";
            this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFLancarDescontoUltimoItemECFToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem,
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem3.Text = "Cancelamento Total  de Item em Cupom Fiscal";
            // 
            // métodoICFCancelarItemECFDarumaToolStripMenuItem
            // 
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem.Name = "métodoICFCancelarItemECFDarumaToolStripMenuItem";
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem.Text = "Método iCFCancelarItem_ECF_Daruma";
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem.ToolTipText = "iCFCancelarItem_ECF_Daruma(string pszNumItem)";
            this.métodoICFCancelarItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarItemECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem.Name = "métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem";
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem.Text = "Método iCFCancelarUltimoItem_ECF_Daruma";
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem.ToolTipText = "iCFCancelarUltimoItem_ECF_Daruma()";
            this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFCancelarItemParcialECFToolStripMenuItem,
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem4.Text = "Cancelamento Parcial de Item em Cupom Fiscal";
            // 
            // métodoICFCancelarItemParcialECFToolStripMenuItem
            // 
            this.métodoICFCancelarItemParcialECFToolStripMenuItem.Name = "métodoICFCancelarItemParcialECFToolStripMenuItem";
            this.métodoICFCancelarItemParcialECFToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoICFCancelarItemParcialECFToolStripMenuItem.Text = "Método iCFCancelarItemParcial_ECF_Daruma";
            this.métodoICFCancelarItemParcialECFToolStripMenuItem.ToolTipText = "iCFCancelarItemParcial_ECF(string pszNumItem, string pszQuantidade)";
            this.métodoICFCancelarItemParcialECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarItemParcialECFToolStripMenuItem_Click_1);
            // 
            // métodoICFCancelarUltimoItemParcialECFToolStripMenuItem
            // 
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem.Name = "métodoICFCancelarUltimoItemParcialECFToolStripMenuItem";
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem.Text = "Método iCFCancelarUltimoItemParcial_ECF_Daruma";
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem.ToolTipText = "iCFCancelarUltimoItemParcial_ECF";
            this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarUltimoItemParcialECFToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem,
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem5.Text = "Cancelamento de Desconto em Item";
            // 
            // métodoICFCancelarDescontoItemECFToolStripMenuItem
            // 
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem.Name = "métodoICFCancelarDescontoItemECFToolStripMenuItem";
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem.Size = new System.Drawing.Size(312, 22);
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem.Text = "Método iCFCancelarDescontoItem_ECF_Daruma";
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem.ToolTipText = "iCFCancelarDescontoItem_ECF(ref string pszNumItem);";
            this.métodoICFCancelarDescontoItemECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarDescontoItemECFToolStripMenuItem_Click_1);
            // 
            // métodoICFCancelarDescUltimoItemECFToolStripMenuItem
            // 
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem.Name = "métodoICFCancelarDescUltimoItemECFToolStripMenuItem";
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem.Size = new System.Drawing.Size(312, 22);
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem.Text = "Método iCFCancelarDescUltimoItem_ECF_Daruma";
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem.ToolTipText = "iCFCancelarDescUltimoItem_ECF()";
            this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarDescUltimoItemECFToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem,
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem6.Text = "Totalização de Cupom Fiscal";
            // 
            // métodoICFTotalizarCupomECFDarumaToolStripMenuItem
            // 
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem.Name = "métodoICFTotalizarCupomECFDarumaToolStripMenuItem";
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem.Text = "Método iCFTotalizarCupom_ECF_Daruma";
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem.ToolTipText = "iCFTotalizarCupom_ECF_Daruma(string pszTipoDescAcresc, string pszValorDescAcresc)" +
                ";";
            this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFTotalizarCupomECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFTotalizarCupomPadraoECFToolStripMenuItem
            // 
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem.Name = "métodoICFTotalizarCupomPadraoECFToolStripMenuItem";
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem.Text = "Método iCFTotalizarCupomPadrao_ECF_Daruma";
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem.ToolTipText = "iCFTotalizarCupomPadrao_ECF();";
            this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFTotalizarCupomPadraoECFToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem,
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem7.Text = "Cancelamento Desconto e Acréscimo em Subtotal de Cupom Fiscal";
            // 
            // métodoICFCancelarDescontoSubtotalECFToolStripMenuItem
            // 
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem.Name = "métodoICFCancelarDescontoSubtotalECFToolStripMenuItem";
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem.Size = new System.Drawing.Size(326, 22);
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem.Text = "Método iCFCancelarDescontoSubtotal_ECF_Daruma";
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem.ToolTipText = "iCFCancelarDescontoSubtotal_ECF();";
            this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarDescontoSubtotalECFToolStripMenuItem_Click_1);
            // 
            // métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem
            // 
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem.Name = "métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem";
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem.Size = new System.Drawing.Size(326, 22);
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem.Text = "Método iCFCancelarAcrescimoSubtotal_ECF_Daruma";
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem.ToolTipText = "iCFCancelarAcrescimoSubtotal_ECF()";
            this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem,
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem,
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem});
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem8.Text = "Descrição do Meio de Pagamento ";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.toolStripMenuItem8_Click);
            // 
            // métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem
            // 
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem.Name = "métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem";
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem.Text = "Método iCFEfetuarPagamentoPadrao_ECF_Daruma";
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem.ToolTipText = "iCFEfetuarPagamentoPadrao_ECF()";
            this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem_Click_1);
            // 
            // métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem
            // 
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem.Name = "métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem";
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem.Text = "Método iCFEfetuarPagamentoFormatado_ECF_Daruma";
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem.ToolTipText = "iCFEfetuarPagamentoFormatado_ECF(ref string pszFormaPgto, ref string pszValor)";
            this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem_Click_1);
            // 
            // métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem
            // 
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem.Name = "métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem";
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(338, 22);
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem.Text = "Método iCFEfetuarPagamento_ECF_Daruma";
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem.ToolTipText = "iCFEfetuarPagamento_ECF_Daruma(";
            this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem,
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem,
            this.métodoICFEncerrarECFDarumaToolStripMenuItem,
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem,
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem9.Text = "Encerramento de Cupom Fiscal";
            // 
            // métodoICFEncerrarPadraoECFDarumaToolStripMenuItem
            // 
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem.Name = "métodoICFEncerrarPadraoECFDarumaToolStripMenuItem";
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem.Text = "Método iCFEncerrarPadrao_ECF_Daruma";
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem.ToolTipText = "iCFEncerrarPadrao_ECF_Daruma()";
            this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEncerrarPadraoECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem
            // 
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem.Name = "métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem";
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem.Text = "Método iCFEncerrarConfigMsg_ECF_Daruma";
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem.ToolTipText = "iCFEncerrarConfigMsg_ECF_Daruma(string pszMensagem)";
            this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFEncerrarECFDarumaToolStripMenuItem
            // 
            this.métodoICFEncerrarECFDarumaToolStripMenuItem.Name = "métodoICFEncerrarECFDarumaToolStripMenuItem";
            this.métodoICFEncerrarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICFEncerrarECFDarumaToolStripMenuItem.Text = "Método iCFEncerrar_ECF_Daruma";
            this.métodoICFEncerrarECFDarumaToolStripMenuItem.ToolTipText = "iCFEncerrar_ECF_Daruma(string pszCupomAdicional, string pszMensagem);";
            this.métodoICFEncerrarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEncerrarECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFFecharResumidoECFDarumaToolStripMenuItem
            // 
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem.Name = "métodoICFFecharResumidoECFDarumaToolStripMenuItem";
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem.Text = "Método iCFEncerrarResumido_ECF_Daruma";
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem.ToolTipText = "iCFFecharResumido_ECF_Daruma()";
            this.métodoICFFecharResumidoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFFecharResumidoECFDarumaToolStripMenuItem_Click_1);
            // 
            // métodoICFEmitirCupomAdicionalECFToolStripMenuItem
            // 
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem.Name = "métodoICFEmitirCupomAdicionalECFToolStripMenuItem";
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem.Text = "Método iCFEmitirCupomAdicional_ECF_Daruma";
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem.ToolTipText = "iCFEmitirCupomAdicional_ECF()";
            this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFEmitirCupomAdicionalECFToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFCancelarECFDarumaToolStripMenuItem});
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem10.Text = "Cancelamento de Cupom Fiscal";
            this.toolStripMenuItem10.Click += new System.EventHandler(this.toolStripMenuItem10_Click);
            // 
            // métodoICFCancelarECFDarumaToolStripMenuItem
            // 
            this.métodoICFCancelarECFDarumaToolStripMenuItem.Name = "métodoICFCancelarECFDarumaToolStripMenuItem";
            this.métodoICFCancelarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(238, 22);
            this.métodoICFCancelarECFDarumaToolStripMenuItem.Text = "Método iCFCancelar_ECF_Daruma";
            this.métodoICFCancelarECFDarumaToolStripMenuItem.ToolTipText = "iCFCancelar_ECF_Daruma()";
            this.métodoICFCancelarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFCancelarECFDarumaToolStripMenuItem_Click_1);
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem});
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem11.Text = "Identificação Consumidor Rodapé do Cupom Fiscal";
            // 
            // métodoICFIdentificarConsumidorECFToolStripMenuItem
            // 
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem.Name = "métodoICFIdentificarConsumidorECFToolStripMenuItem";
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem.Text = "Método iCFIdentificarConsumidor_ECF_Daruma";
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem.ToolTipText = "iCFIdentificarConsumidor_ECF(ref string pszNome, ref string pszEndereco, ref stri" +
                "ng pszDoc)";
            this.métodoICFIdentificarConsumidorECFToolStripMenuItem.Click += new System.EventHandler(this.métodoICFIdentificarConsumidorECFToolStripMenuItem_Click_1);
            // 
            // cupomManiaParaOEstadoDoRJToolStripMenuItem
            // 
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.configuraçãoCupomManiaToolStripMenuItem,
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem});
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem.Name = "cupomManiaParaOEstadoDoRJToolStripMenuItem";
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem.Size = new System.Drawing.Size(406, 22);
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem.Text = "Cupom Mania para o estado do RJ";
            this.cupomManiaParaOEstadoDoRJToolStripMenuItem.Click += new System.EventHandler(this.cupomManiaParaOEstadoDoRJToolStripMenuItem_Click);
            // 
            // configuraçãoCupomManiaToolStripMenuItem
            // 
            this.configuraçãoCupomManiaToolStripMenuItem.Name = "configuraçãoCupomManiaToolStripMenuItem";
            this.configuraçãoCupomManiaToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.configuraçãoCupomManiaToolStripMenuItem.Text = "Configuração Cupom Mania";
            this.configuraçãoCupomManiaToolStripMenuItem.Click += new System.EventHandler(this.configuraçãoCupomManiaToolStripMenuItem_Click);
            // 
            // totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem
            // 
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem.Name = "totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem";
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem.Size = new System.Drawing.Size(315, 22);
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem.Text = "Total de ISS e ICMS contabilizado  último CF Mania";
            this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem.Click += new System.EventHandler(this.totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Enabled = false;
            this.toolStripMenuItem14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Underline);
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(406, 22);
            this.toolStripMenuItem14.Text = "---------------------------------------------------------------------------------" +
                "--";
            // 
            // testedeVendadeItensSemPararBuferizandoToolStripMenuItem
            // 
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem.Name = "testedeVendadeItensSemPararBuferizandoToolStripMenuItem";
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem.Size = new System.Drawing.Size(406, 22);
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem.Text = "Teste_de_Venda_de_Itens_Sem_Parar_Buferizando";
            this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem.Click += new System.EventHandler(this.testedeVendadeItensSemPararBuferizandoToolStripMenuItem_Click);
            // 
            // exemplosToolStripMenuItem
            // 
            this.exemplosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cupomFiscalCompletoToolStripMenuItem,
            this.cupomFiscalResumidoToolStripMenuItem,
            this.cupomFiscalPreVendaToolStripMenuItem});
            this.exemplosToolStripMenuItem.Name = "exemplosToolStripMenuItem";
            this.exemplosToolStripMenuItem.Size = new System.Drawing.Size(406, 22);
            this.exemplosToolStripMenuItem.Text = "Exemplos";
            // 
            // cupomFiscalCompletoToolStripMenuItem
            // 
            this.cupomFiscalCompletoToolStripMenuItem.Name = "cupomFiscalCompletoToolStripMenuItem";
            this.cupomFiscalCompletoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.cupomFiscalCompletoToolStripMenuItem.Text = "Cupom Fiscal Completo";
            this.cupomFiscalCompletoToolStripMenuItem.Click += new System.EventHandler(this.cupomFiscalCompletoToolStripMenuItem_Click);
            // 
            // cupomFiscalResumidoToolStripMenuItem
            // 
            this.cupomFiscalResumidoToolStripMenuItem.Name = "cupomFiscalResumidoToolStripMenuItem";
            this.cupomFiscalResumidoToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.cupomFiscalResumidoToolStripMenuItem.Text = "Cupom Fiscal Resumido";
            this.cupomFiscalResumidoToolStripMenuItem.Click += new System.EventHandler(this.cupomFiscalResumidoToolStripMenuItem_Click);
            // 
            // cupomFiscalPreVendaToolStripMenuItem
            // 
            this.cupomFiscalPreVendaToolStripMenuItem.Name = "cupomFiscalPreVendaToolStripMenuItem";
            this.cupomFiscalPreVendaToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.cupomFiscalPreVendaToolStripMenuItem.Text = "Cupom Fiscal Pre-Venda";
            this.cupomFiscalPreVendaToolStripMenuItem.Click += new System.EventHandler(this.cupomFiscalPreVendaToolStripMenuItem_Click);
            // 
            // MN_Metodos_CCD
            // 
            this.MN_Metodos_CCD.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aberturaCCDToolStripMenuItem,
            this.textoImprimirToolStripMenuItem,
            this.encerrarCCDToolStripMenuItem,
            this.estornoCCDToolStripMenuItem,
            this.ªViaDoCCDToolStripMenuItem,
            this.tEFToolStripMenuItem,
            this.toolStripMenuItem15,
            this.exemplosToolStripMenuItem1});
            this.MN_Metodos_CCD.Name = "MN_Metodos_CCD";
            this.MN_Metodos_CCD.Size = new System.Drawing.Size(73, 19);
            this.MN_Metodos_CCD.Text = "CCD - TEF";
            // 
            // aberturaCCDToolStripMenuItem
            // 
            this.aberturaCCDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICCDAbrirECFDarumaToolStripMenuItem,
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1,
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1});
            this.aberturaCCDToolStripMenuItem.Name = "aberturaCCDToolStripMenuItem";
            this.aberturaCCDToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.aberturaCCDToolStripMenuItem.Text = "Abertura CCD";
            // 
            // métodoICCDAbrirECFDarumaToolStripMenuItem
            // 
            this.métodoICCDAbrirECFDarumaToolStripMenuItem.Name = "métodoICCDAbrirECFDarumaToolStripMenuItem";
            this.métodoICCDAbrirECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.métodoICCDAbrirECFDarumaToolStripMenuItem.Text = "Método iCCDAbrir_ECF_Daruma";
            this.métodoICCDAbrirECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICCDAbrirECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1
            // 
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1.Name = "métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1";
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(310, 22);
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1.Text = "Método iCCDAbrirSimplificado_ECF_Daruma";
            this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1
            // 
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1.Name = "métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1";
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(310, 22);
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1.Text = "Método iCCDAbrirPadrao_ECF_Daruma";
            this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1_Click);
            // 
            // textoImprimirToolStripMenuItem
            // 
            this.textoImprimirToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1,
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem});
            this.textoImprimirToolStripMenuItem.Name = "textoImprimirToolStripMenuItem";
            this.textoImprimirToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.textoImprimirToolStripMenuItem.Text = "Texto Imprimir";
            // 
            // métodoICCDImprimirTextoECFDarumaToolStripMenuItem1
            // 
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1.Name = "métodoICCDImprimirTextoECFDarumaToolStripMenuItem1";
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(306, 22);
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1.Text = "Método iCCDImprimirTexto_ECF_Daruma";
            this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoICCDImprimirTextoECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoICCDImprimirArquivoECFDarumaToolStripMenuItem
            // 
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem.Name = "métodoICCDImprimirArquivoECFDarumaToolStripMenuItem";
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(306, 22);
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem.Text = "Método iCCDImprimirArquivo_ECF_Daruma";
            this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICCDImprimirArquivoECFDarumaToolStripMenuItem_Click);
            // 
            // encerrarCCDToolStripMenuItem
            // 
            this.encerrarCCDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICCDFecharECFDarumaToolStripMenuItem1});
            this.encerrarCCDToolStripMenuItem.Name = "encerrarCCDToolStripMenuItem";
            this.encerrarCCDToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.encerrarCCDToolStripMenuItem.Text = "Encerrar CCD";
            // 
            // métodoICCDFecharECFDarumaToolStripMenuItem1
            // 
            this.métodoICCDFecharECFDarumaToolStripMenuItem1.Name = "métodoICCDFecharECFDarumaToolStripMenuItem1";
            this.métodoICCDFecharECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(253, 22);
            this.métodoICCDFecharECFDarumaToolStripMenuItem1.Text = "Método iCCDFechar_ECF_Daruma";
            this.métodoICCDFecharECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoICCDFecharECFDarumaToolStripMenuItem1_Click);
            // 
            // estornoCCDToolStripMenuItem
            // 
            this.estornoCCDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem,
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1});
            this.estornoCCDToolStripMenuItem.Name = "estornoCCDToolStripMenuItem";
            this.estornoCCDToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.estornoCCDToolStripMenuItem.Text = "Estorno CCD";
            // 
            // métodoICCDEstornoPadraoECFDarumaToolStripMenuItem
            // 
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem.Name = "métodoICCDEstornoPadraoECFDarumaToolStripMenuItem";
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(298, 22);
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem.Text = "Método iCCDEstornarPadrao_ECF_Daruma";
            this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICCDEstornoPadraoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICCDEstornarECFDarumaToolStripMenuItem1
            // 
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1.Name = "métodoICCDEstornarECFDarumaToolStripMenuItem1";
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(298, 22);
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1.Text = "Método iCCDEstornar_ECF_Daruma";
            this.métodoICCDEstornarECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoICCDEstornarECFDarumaToolStripMenuItem1_Click);
            // 
            // ªViaDoCCDToolStripMenuItem
            // 
            this.ªViaDoCCDToolStripMenuItem.Name = "ªViaDoCCDToolStripMenuItem";
            this.ªViaDoCCDToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.ªViaDoCCDToolStripMenuItem.Text = "2ª Via do CCD";
            // 
            // tEFToolStripMenuItem
            // 
            this.tEFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem,
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem,
            this.eTEFSetarFocoECFDarumaToolStripMenuItem,
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem,
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem,
            this.iTEFFecharToolStripMenuItem,
            this.testeCompletoTEFToolStripMenuItem});
            this.tEFToolStripMenuItem.Name = "tEFToolStripMenuItem";
            this.tEFToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.tEFToolStripMenuItem.Text = "TEF";
            // 
            // eTEFEsperarArquivoECFDarumaToolStripMenuItem
            // 
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem.Name = "eTEFEsperarArquivoECFDarumaToolStripMenuItem";
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem.Text = "eTEF_EsperarArquivo_ECF_Daruma";
            this.eTEFEsperarArquivoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.eTEFEsperarArquivoECFDarumaToolStripMenuItem_Click);
            // 
            // eTEFTravarTecladoECFDarumaToolStripMenuItem
            // 
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem.Name = "eTEFTravarTecladoECFDarumaToolStripMenuItem";
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem.Text = "eTEF_TravarTeclado_ECF_Daruma";
            this.eTEFTravarTecladoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.eTEFTravarTecladoECFDarumaToolStripMenuItem_Click);
            // 
            // eTEFSetarFocoECFDarumaToolStripMenuItem
            // 
            this.eTEFSetarFocoECFDarumaToolStripMenuItem.Name = "eTEFSetarFocoECFDarumaToolStripMenuItem";
            this.eTEFSetarFocoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.eTEFSetarFocoECFDarumaToolStripMenuItem.Text = "eTEF_SetarFoco_ECF_Daruma";
            this.eTEFSetarFocoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.eTEFSetarFocoECFDarumaToolStripMenuItem_Click);
            // 
            // iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem
            // 
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem.Name = "iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem";
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem.Text = "iTEF_ImprimirRespostaCartao_ECF_Daruma";
            this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem_Click);
            // 
            // iTEFImprimirRespostaECFDarumaToolStripMenuItem
            // 
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem.Name = "iTEFImprimirRespostaECFDarumaToolStripMenuItem";
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem.Text = "iTEF_ImprimirResposta_ECF_Daruma";
            this.iTEFImprimirRespostaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.iTEFImprimirRespostaECFDarumaToolStripMenuItem_Click);
            // 
            // iTEFFecharToolStripMenuItem
            // 
            this.iTEFFecharToolStripMenuItem.Name = "iTEFFecharToolStripMenuItem";
            this.iTEFFecharToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.iTEFFecharToolStripMenuItem.Text = "iTEF_Fechar_ECF_Daruma";
            this.iTEFFecharToolStripMenuItem.Click += new System.EventHandler(this.iTEFFecharToolStripMenuItem_Click);
            // 
            // testeCompletoTEFToolStripMenuItem
            // 
            this.testeCompletoTEFToolStripMenuItem.Name = "testeCompletoTEFToolStripMenuItem";
            this.testeCompletoTEFToolStripMenuItem.Size = new System.Drawing.Size(301, 22);
            this.testeCompletoTEFToolStripMenuItem.Text = "Teste Completo TEF";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Enabled = false;
            this.toolStripMenuItem15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Underline);
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(178, 22);
            this.toolStripMenuItem15.Text = "--------------------------";
            // 
            // exemplosToolStripMenuItem1
            // 
            this.exemplosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cCDCompletoToolStripMenuItem});
            this.exemplosToolStripMenuItem1.Name = "exemplosToolStripMenuItem1";
            this.exemplosToolStripMenuItem1.Size = new System.Drawing.Size(178, 22);
            this.exemplosToolStripMenuItem1.Text = "Exemplos";
            // 
            // cCDCompletoToolStripMenuItem
            // 
            this.cCDCompletoToolStripMenuItem.Name = "cCDCompletoToolStripMenuItem";
            this.cCDCompletoToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.cCDCompletoToolStripMenuItem.Text = "CCD Completo";
            // 
            // MN_Metodos_CNF
            // 
            this.MN_Metodos_CNF.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem,
            this.rcebimentoDeItensToolStripMenuItem,
            this.cancelamentoDeItemToolStripMenuItem,
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem,
            this.cancelamentoDeDescontoEmItemToolStripMenuItem,
            this.totalizacaoDeCNFToolStripMenuItem,
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem,
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem,
            this.encerramentoDeCNFToolStripMenuItem,
            this.cancelamentoDeCNFToolStripMenuItem,
            this.toolStripMenuItem16,
            this.exemplosToolStripMenuItem2});
            this.MN_Metodos_CNF.Name = "MN_Metodos_CNF";
            this.MN_Metodos_CNF.Size = new System.Drawing.Size(149, 19);
            this.MN_Metodos_CNF.Text = "Comprovante Não Fiscal";
            // 
            // aberturaDeComprovanteNãoFiscalToolStripMenuItem
            // 
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFAbrirECFDarumaToolStripMenuItem,
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem});
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem.Name = "aberturaDeComprovanteNãoFiscalToolStripMenuItem";
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.aberturaDeComprovanteNãoFiscalToolStripMenuItem.Text = "Abertura de Comprovante Não Fiscal";
            // 
            // métodoICNFAbrirECFDarumaToolStripMenuItem
            // 
            this.métodoICNFAbrirECFDarumaToolStripMenuItem.Name = "métodoICNFAbrirECFDarumaToolStripMenuItem";
            this.métodoICNFAbrirECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.métodoICNFAbrirECFDarumaToolStripMenuItem.Text = "Método iCNFAbrir_ECF_Daruma";
            this.métodoICNFAbrirECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFAbrirECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFAbrirPadraoECFDarumaToolStripMenuItem
            // 
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem.Name = "métodoICNFAbrirPadraoECFDarumaToolStripMenuItem";
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(280, 22);
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem.Text = "Método iCNFAbrirPadrao_ECF_Daruma";
            this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFAbrirPadraoECFDarumaToolStripMenuItem_Click);
            // 
            // rcebimentoDeItensToolStripMenuItem
            // 
            this.rcebimentoDeItensToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFReceberECFDarumaToolStripMenuItem,
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem});
            this.rcebimentoDeItensToolStripMenuItem.Name = "rcebimentoDeItensToolStripMenuItem";
            this.rcebimentoDeItensToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.rcebimentoDeItensToolStripMenuItem.Text = "Recebimento de itens";
            // 
            // métodoICNFReceberECFDarumaToolStripMenuItem
            // 
            this.métodoICNFReceberECFDarumaToolStripMenuItem.Name = "métodoICNFReceberECFDarumaToolStripMenuItem";
            this.métodoICNFReceberECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(307, 22);
            this.métodoICNFReceberECFDarumaToolStripMenuItem.Text = "Método iCNFReceber_ECF_Daruma";
            this.métodoICNFReceberECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFReceberECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFReceberSemDescECFDarumaToolStripMenuItem
            // 
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem.Name = "métodoICNFReceberSemDescECFDarumaToolStripMenuItem";
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(307, 22);
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem.Text = "Método iCNFReceberSemDesc_ECF_Daruma";
            this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFReceberSemDescECFDarumaToolStripMenuItem_Click);
            // 
            // cancelamentoDeItemToolStripMenuItem
            // 
            this.cancelamentoDeItemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem,
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem});
            this.cancelamentoDeItemToolStripMenuItem.Name = "cancelamentoDeItemToolStripMenuItem";
            this.cancelamentoDeItemToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.cancelamentoDeItemToolStripMenuItem.Text = "Cancelamento de item";
            // 
            // métodoICNFCancelarItemECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarItemECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(323, 22);
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarItem_ECF_Daruma";
            this.métodoICNFCancelarItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarItemECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(323, 22);
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarUltimoItem_ECF_Daruma";
            this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem_Click);
            // 
            // cancelamentoDeAcrescimoEmItemToolStripMenuItem
            // 
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem,
            this.métodoToolStripMenuItem});
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem.Name = "cancelamentoDeAcrescimoEmItemToolStripMenuItem";
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.cancelamentoDeAcrescimoEmItemToolStripMenuItem.Text = "Cancelamento de Acrescimo em Item";
            // 
            // métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(379, 22);
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarAcrescimoItem_ECF_Daruma";
            this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem_Click);
            // 
            // métodoToolStripMenuItem
            // 
            this.métodoToolStripMenuItem.Name = "métodoToolStripMenuItem";
            this.métodoToolStripMenuItem.Size = new System.Drawing.Size(379, 22);
            this.métodoToolStripMenuItem.Text = "Método iCNFCancelarAcrescimoUltimoItem_ECF_Daruma";
            this.métodoToolStripMenuItem.Click += new System.EventHandler(this.métodoToolStripMenuItem_Click);
            // 
            // cancelamentoDeDescontoEmItemToolStripMenuItem
            // 
            this.cancelamentoDeDescontoEmItemToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem,
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem});
            this.cancelamentoDeDescontoEmItemToolStripMenuItem.Name = "cancelamentoDeDescontoEmItemToolStripMenuItem";
            this.cancelamentoDeDescontoEmItemToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.cancelamentoDeDescontoEmItemToolStripMenuItem.Text = "Cancelamento de desconto em item";
            // 
            // métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(373, 22);
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarDescontoItem_ECF_Daruma";
            this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(373, 22);
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarDescontoUltimoItem_ECF_Daruma";
            this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem_Click);
            // 
            // totalizacaoDeCNFToolStripMenuItem
            // 
            this.totalizacaoDeCNFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem,
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem});
            this.totalizacaoDeCNFToolStripMenuItem.Name = "totalizacaoDeCNFToolStripMenuItem";
            this.totalizacaoDeCNFToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.totalizacaoDeCNFToolStripMenuItem.Text = "Totalizacao de CNF";
            // 
            // métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem
            // 
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem.Name = "métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem";
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(372, 22);
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem.Text = "Método iCNFTotalizarComprovante_ECF_Daruma";
            this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem
            // 
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem.Name = "métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem";
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(372, 22);
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem.Text = "Método iCNFTotalizarComprovantePadrao_ECF_Daruma";
            this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem_Click);
            // 
            // cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem
            // 
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem,
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem});
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem.Name = "cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem";
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem.Text = "Cancelamento de desconto e acrescimo em subtotal de CNF";
            this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem.Click += new System.EventHandler(this.cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem_Click);
            // 
            // métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarAcrescimoSubtotal_ECF_Daruma";
            this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(363, 22);
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem.Text = "Método iCNFCancelarDescontoSubtotal_ECF_Daruma";
            this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem_Click);
            // 
            // descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem
            // 
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem,
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem,
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem});
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem.Name = "descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem";
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem.Text = "Descricao dos meios de pagamento de CNF";
            // 
            // métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem
            // 
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem.Name = "métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem";
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(373, 22);
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem.Text = "Método iCNFEfetuarPagamento_ECF_Daruma";
            this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem
            // 
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem.Name = "métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem";
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(373, 22);
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem.Text = "Método iCNFEfetuarPagamentoFormatado_ECF_Daruma";
            this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFEfetuarPagamentoPadrToolStripMenuItem
            // 
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem.Name = "métodoICNFEfetuarPagamentoPadrToolStripMenuItem";
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem.Size = new System.Drawing.Size(373, 22);
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem.Text = "Método iCNFEfetuarPagamentoPadrao_ECF_Daruma";
            this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFEfetuarPagamentoPadrToolStripMenuItem_Click);
            // 
            // encerramentoDeCNFToolStripMenuItem
            // 
            this.encerramentoDeCNFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem,
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem});
            this.encerramentoDeCNFToolStripMenuItem.Name = "encerramentoDeCNFToolStripMenuItem";
            this.encerramentoDeCNFToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.encerramentoDeCNFToolStripMenuItem.Text = "Encerramento de CNF";
            // 
            // métodoICNFEncerrarECFDarumaToolStripMenuItem
            // 
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem.Name = "métodoICNFEncerrarECFDarumaToolStripMenuItem";
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem.Text = "Método iCNFEncerrar_ECF_Daruma";
            this.métodoICNFEncerrarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFEncerrarECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem
            // 
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem.Name = "métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem";
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(297, 22);
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem.Text = "Método iCNFEncerrarPadrao_ECF_Daruma";
            this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem_Click);
            // 
            // cancelamentoDeCNFToolStripMenuItem
            // 
            this.cancelamentoDeCNFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICNFCancelarECFDarumaToolStripMenuItem});
            this.cancelamentoDeCNFToolStripMenuItem.Name = "cancelamentoDeCNFToolStripMenuItem";
            this.cancelamentoDeCNFToolStripMenuItem.Size = new System.Drawing.Size(393, 22);
            this.cancelamentoDeCNFToolStripMenuItem.Text = "Cancelamento de CNF";
            // 
            // métodoICNFCancelarECFDarumaToolStripMenuItem
            // 
            this.métodoICNFCancelarECFDarumaToolStripMenuItem.Name = "métodoICNFCancelarECFDarumaToolStripMenuItem";
            this.métodoICNFCancelarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.métodoICNFCancelarECFDarumaToolStripMenuItem.Text = "Método iCNFCancelar_ECF_Daruma";
            this.métodoICNFCancelarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICNFCancelarECFDarumaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Enabled = false;
            this.toolStripMenuItem16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Underline);
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(393, 22);
            this.toolStripMenuItem16.Text = "-----------------------------------------------------------";
            // 
            // exemplosToolStripMenuItem2
            // 
            this.exemplosToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cNFToolStripMenuItem});
            this.exemplosToolStripMenuItem2.Name = "exemplosToolStripMenuItem2";
            this.exemplosToolStripMenuItem2.Size = new System.Drawing.Size(393, 22);
            this.exemplosToolStripMenuItem2.Text = "Exemplos";
            this.exemplosToolStripMenuItem2.Click += new System.EventHandler(this.exemplosToolStripMenuItem2_Click);
            // 
            // cNFToolStripMenuItem
            // 
            this.cNFToolStripMenuItem.Name = "cNFToolStripMenuItem";
            this.cNFToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.cNFToolStripMenuItem.Text = "CNF Detalhado";
            this.cNFToolStripMenuItem.Click += new System.EventHandler(this.cNFToolStripMenuItem_Click);
            // 
            // MN_Metodos_RG
            // 
            this.MN_Metodos_RG.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aberturaRelatórioGerencialToolStripMenuItem,
            this.textoImpressãoToolStripMenuItem,
            this.encerramentoRelatórioGerencialToolStripMenuItem});
            this.MN_Metodos_RG.Name = "MN_Metodos_RG";
            this.MN_Metodos_RG.Size = new System.Drawing.Size(118, 19);
            this.MN_Metodos_RG.Text = "Relatório Gerencial";
            // 
            // aberturaRelatórioGerencialToolStripMenuItem
            // 
            this.aberturaRelatórioGerencialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1,
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1,
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1});
            this.aberturaRelatórioGerencialToolStripMenuItem.Name = "aberturaRelatórioGerencialToolStripMenuItem";
            this.aberturaRelatórioGerencialToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.aberturaRelatórioGerencialToolStripMenuItem.Text = "Abertura Relatório Gerencial";
            // 
            // métodoIRGAbrirECFDarumaToolStripMenuItem1
            // 
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1.Name = "métodoIRGAbrirECFDarumaToolStripMenuItem1";
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(272, 22);
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1.Text = "Método iRGAbrir_ECF_Daruma";
            this.métodoIRGAbrirECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIRGAbrirECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1
            // 
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1.Name = "métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1";
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(272, 22);
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1.Text = "Método iRGAbrirIndice_ECF_Daruma";
            this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1
            // 
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1.Name = "métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1";
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(272, 22);
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1.Text = "Método iRGAbrirPadrao_ECF_Daruma";
            this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1_Click);
            // 
            // textoImpressãoToolStripMenuItem
            // 
            this.textoImpressãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1});
            this.textoImpressãoToolStripMenuItem.Name = "textoImpressãoToolStripMenuItem";
            this.textoImpressãoToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.textoImpressãoToolStripMenuItem.Text = "Texto Impressão";
            // 
            // métodoIRGImprimirTextoECFDarumaToolStripMenuItem1
            // 
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1.Name = "métodoIRGImprimirTextoECFDarumaToolStripMenuItem1";
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(284, 22);
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1.Text = "Método iRGImprimirTexto_ECF_Daruma";
            this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIRGImprimirTextoECFDarumaToolStripMenuItem1_Click);
            // 
            // encerramentoRelatórioGerencialToolStripMenuItem
            // 
            this.encerramentoRelatórioGerencialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIRGFecharECFDarumaToolStripMenuItem1});
            this.encerramentoRelatórioGerencialToolStripMenuItem.Name = "encerramentoRelatórioGerencialToolStripMenuItem";
            this.encerramentoRelatórioGerencialToolStripMenuItem.Size = new System.Drawing.Size(250, 22);
            this.encerramentoRelatórioGerencialToolStripMenuItem.Text = "Encerramento Relatório Gerencial";
            // 
            // métodoIRGFecharECFDarumaToolStripMenuItem1
            // 
            this.métodoIRGFecharECFDarumaToolStripMenuItem1.Name = "métodoIRGFecharECFDarumaToolStripMenuItem1";
            this.métodoIRGFecharECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(244, 22);
            this.métodoIRGFecharECFDarumaToolStripMenuItem1.Text = "Método iRGFechar_ECF_Daruma";
            this.métodoIRGFecharECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIRGFecharECFDarumaToolStripMenuItem1_Click);
            // 
            // MN_Metodos_Bilhete_Passagem
            // 
            this.MN_Metodos_Bilhete_Passagem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoICFAbrirECFDarumaToolStripMenuItem,
            this.métodoICFBPVenderECFDarumaToolStripMenuItem,
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem});
            this.MN_Metodos_Bilhete_Passagem.Name = "MN_Metodos_Bilhete_Passagem";
            this.MN_Metodos_Bilhete_Passagem.Size = new System.Drawing.Size(127, 19);
            this.MN_Metodos_Bilhete_Passagem.Text = "Bilhete de Passagem";
            // 
            // métodoICFAbrirECFDarumaToolStripMenuItem
            // 
            this.métodoICFAbrirECFDarumaToolStripMenuItem.Name = "métodoICFAbrirECFDarumaToolStripMenuItem";
            this.métodoICFAbrirECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.métodoICFAbrirECFDarumaToolStripMenuItem.Text = "Método iCFBPAbrir_ECF_Daruma";
            this.métodoICFAbrirECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFAbrirECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICFBPVenderECFDarumaToolStripMenuItem
            // 
            this.métodoICFBPVenderECFDarumaToolStripMenuItem.Name = "métodoICFBPVenderECFDarumaToolStripMenuItem";
            this.métodoICFBPVenderECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.métodoICFBPVenderECFDarumaToolStripMenuItem.Text = "Método iCFBPVender_ECF_Daruma";
            this.métodoICFBPVenderECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFBPVenderECFDarumaToolStripMenuItem_Click);
            // 
            // métodoICFBPProgramarUFECFDarumaToolStripMenuItem
            // 
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem.Name = "métodoICFBPProgramarUFECFDarumaToolStripMenuItem";
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(313, 22);
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem.Text = "Método confCFBPProgramarUF_ECF_Daruma";
            this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoICFBPProgramarUFECFDarumaToolStripMenuItem_Click);
            // 
            // MN_Metodos_Relatorios_Fiscais
            // 
            this.MN_Metodos_Relatorios_Fiscais.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leituraXToolStripMenuItem,
            this.reduçãoZToolStripMenuItem,
            this.sangriaToolStripMenuItem1,
            this.suprimentoToolStripMenuItem1,
            this.leituraMemóriaFiscalToolStripMenuItem1});
            this.MN_Metodos_Relatorios_Fiscais.Name = "MN_Metodos_Relatorios_Fiscais";
            this.MN_Metodos_Relatorios_Fiscais.Size = new System.Drawing.Size(108, 19);
            this.MN_Metodos_Relatorios_Fiscais.Text = "Relatórios Fiscais";
            this.MN_Metodos_Relatorios_Fiscais.Click += new System.EventHandler(this.MN_Metodos_Relatorios_Fiscais_Click);
            // 
            // leituraXToolStripMenuItem
            // 
            this.leituraXToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoILeituraXECFDarumaToolStripMenuItem,
            this.métodoRLeituraXECFDarumaToolStripMenuItem1});
            this.leituraXToolStripMenuItem.Name = "leituraXToolStripMenuItem";
            this.leituraXToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.leituraXToolStripMenuItem.Text = "Leitura X";
            // 
            // métodoILeituraXECFDarumaToolStripMenuItem
            // 
            this.métodoILeituraXECFDarumaToolStripMenuItem.Name = "métodoILeituraXECFDarumaToolStripMenuItem";
            this.métodoILeituraXECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(238, 22);
            this.métodoILeituraXECFDarumaToolStripMenuItem.Text = "Método iLeituraX_ECF_Daruma";
            this.métodoILeituraXECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoILeituraXECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRLeituraXECFDarumaToolStripMenuItem1
            // 
            this.métodoRLeituraXECFDarumaToolStripMenuItem1.Name = "métodoRLeituraXECFDarumaToolStripMenuItem1";
            this.métodoRLeituraXECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(238, 22);
            this.métodoRLeituraXECFDarumaToolStripMenuItem1.Text = "Método rLeituraX_ECF_Daruma";
            this.métodoRLeituraXECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoRLeituraXECFDarumaToolStripMenuItem1_Click);
            // 
            // reduçãoZToolStripMenuItem
            // 
            this.reduçãoZToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIReducaoZECFDarumaToolStripMenuItem1});
            this.reduçãoZToolStripMenuItem.Name = "reduçãoZToolStripMenuItem";
            this.reduçãoZToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.reduçãoZToolStripMenuItem.Text = "Redução Z";
            // 
            // métodoIReducaoZECFDarumaToolStripMenuItem1
            // 
            this.métodoIReducaoZECFDarumaToolStripMenuItem1.Name = "métodoIReducaoZECFDarumaToolStripMenuItem1";
            this.métodoIReducaoZECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(247, 22);
            this.métodoIReducaoZECFDarumaToolStripMenuItem1.Text = "Método iReducaoZ_ECF_Daruma";
            this.métodoIReducaoZECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIReducaoZECFDarumaToolStripMenuItem1_Click);
            // 
            // sangriaToolStripMenuItem1
            // 
            this.sangriaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1,
            this.métodoISangriaECFDarumaToolStripMenuItem1});
            this.sangriaToolStripMenuItem1.Name = "sangriaToolStripMenuItem1";
            this.sangriaToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.sangriaToolStripMenuItem1.Text = "Sangria";
            // 
            // métodoISangriaPadraoECFDarumaToolStripMenuItem1
            // 
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1.Name = "métodoISangriaPadraoECFDarumaToolStripMenuItem1";
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1.Text = "Método iSangriaPadrao_ECF_Daruma";
            this.métodoISangriaPadraoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoISangriaPadraoECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoISangriaECFDarumaToolStripMenuItem1
            // 
            this.métodoISangriaECFDarumaToolStripMenuItem1.Name = "métodoISangriaECFDarumaToolStripMenuItem1";
            this.métodoISangriaECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(270, 22);
            this.métodoISangriaECFDarumaToolStripMenuItem1.Text = "Método iSangria_ECF_Daruma";
            this.métodoISangriaECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoISangriaECFDarumaToolStripMenuItem1_Click);
            // 
            // suprimentoToolStripMenuItem1
            // 
            this.suprimentoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1,
            this.métodoISuprimentoECFDarumaToolStripMenuItem1});
            this.suprimentoToolStripMenuItem1.Name = "suprimentoToolStripMenuItem1";
            this.suprimentoToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.suprimentoToolStripMenuItem1.Text = "Suprimento";
            // 
            // métodoISuprimentoPadraoECFDarumaToolStripMenuItem1
            // 
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1.Name = "métodoISuprimentoPadraoECFDarumaToolStripMenuItem1";
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(293, 22);
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1.Text = "Método iSuprimentoPadrao_ECF_Daruma";
            this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoISuprimentoPadraoECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoISuprimentoECFDarumaToolStripMenuItem1
            // 
            this.métodoISuprimentoECFDarumaToolStripMenuItem1.Name = "métodoISuprimentoECFDarumaToolStripMenuItem1";
            this.métodoISuprimentoECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(293, 22);
            this.métodoISuprimentoECFDarumaToolStripMenuItem1.Text = "Método iSuprimento_ECF_Daruma";
            this.métodoISuprimentoECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoISuprimentoECFDarumaToolStripMenuItem1_Click);
            // 
            // leituraMemóriaFiscalToolStripMenuItem1
            // 
            this.leituraMemóriaFiscalToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIMFLerECFDarumaToolStripMenuItem1,
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1});
            this.leituraMemóriaFiscalToolStripMenuItem1.Name = "leituraMemóriaFiscalToolStripMenuItem1";
            this.leituraMemóriaFiscalToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.leituraMemóriaFiscalToolStripMenuItem1.Text = "Leitura Memória Fiscal";
            // 
            // métodoIMFLerECFDarumaToolStripMenuItem1
            // 
            this.métodoIMFLerECFDarumaToolStripMenuItem1.Name = "métodoIMFLerECFDarumaToolStripMenuItem1";
            this.métodoIMFLerECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(255, 22);
            this.métodoIMFLerECFDarumaToolStripMenuItem1.Text = "Método iMFLer_ECF_Daruma";
            this.métodoIMFLerECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIMFLerECFDarumaToolStripMenuItem1_Click);
            // 
            // métodoIMFLerSerialECFDarumaToolStripMenuItem1
            // 
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1.Name = "métodoIMFLerSerialECFDarumaToolStripMenuItem1";
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1.Size = new System.Drawing.Size(255, 22);
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1.Text = "Método iMFLerSerial_ECF_Daruma";
            this.métodoIMFLerSerialECFDarumaToolStripMenuItem1.Click += new System.EventHandler(this.métodoIMFLerSerialECFDarumaToolStripMenuItem1_Click);
            // 
            // MN_Metodos_Programacao_Impressora
            // 
            this.MN_Metodos_Programacao_Impressora.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.eCFToolStripMenuItem,
            this.horárioDeVerãoToolStripMenuItem,
            this.modoPréVendaToolStripMenuItem,
            this.avançoPapelToolStripMenuItem,
            this.lojaToolStripMenuItem,
            this.operadorToolStripMenuItem});
            this.MN_Metodos_Programacao_Impressora.Name = "MN_Metodos_Programacao_Impressora";
            this.MN_Metodos_Programacao_Impressora.Size = new System.Drawing.Size(130, 19);
            this.MN_Metodos_Programacao_Impressora.Text = "Programação do ECF";
            this.MN_Metodos_Programacao_Impressora.Click += new System.EventHandler(this.MN_Metodos_Programacao_Impressora_Click);
            // 
            // eCFToolStripMenuItem
            // 
            this.eCFToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem,
            this.métodoConfCadastrarECFDarumaToolStripMenuItem});
            this.eCFToolStripMenuItem.Name = "eCFToolStripMenuItem";
            this.eCFToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.eCFToolStripMenuItem.Text = "ECF";
            // 
            // métodoConfCadastrarPadraoECFDarumaToolStripMenuItem
            // 
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem.Name = "métodoConfCadastrarPadraoECFDarumaToolStripMenuItem";
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(302, 22);
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem.Text = "Método confCadastrarPadrao_ECF_Daruma";
            this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoConfCadastrarPadraoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoConfCadastrarECFDarumaToolStripMenuItem
            // 
            this.métodoConfCadastrarECFDarumaToolStripMenuItem.Name = "métodoConfCadastrarECFDarumaToolStripMenuItem";
            this.métodoConfCadastrarECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(302, 22);
            this.métodoConfCadastrarECFDarumaToolStripMenuItem.Text = "Método confCadastrar_ECF_Daruma";
            this.métodoConfCadastrarECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoConfCadastrarECFDarumaToolStripMenuItem_Click);
            // 
            // horárioDeVerãoToolStripMenuItem
            // 
            this.horárioDeVerãoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.habilitarToolStripMenuItem,
            this.desabilitarToolStripMenuItem});
            this.horárioDeVerãoToolStripMenuItem.Name = "horárioDeVerãoToolStripMenuItem";
            this.horárioDeVerãoToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.horárioDeVerãoToolStripMenuItem.Text = "Horário de Verão";
            // 
            // habilitarToolStripMenuItem
            // 
            this.habilitarToolStripMenuItem.Name = "habilitarToolStripMenuItem";
            this.habilitarToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.habilitarToolStripMenuItem.Text = "Habilitar";
            this.habilitarToolStripMenuItem.Click += new System.EventHandler(this.habilitarToolStripMenuItem_Click);
            // 
            // desabilitarToolStripMenuItem
            // 
            this.desabilitarToolStripMenuItem.Name = "desabilitarToolStripMenuItem";
            this.desabilitarToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.desabilitarToolStripMenuItem.Text = "Desabilitar";
            this.desabilitarToolStripMenuItem.Click += new System.EventHandler(this.desabilitarToolStripMenuItem_Click);
            // 
            // modoPréVendaToolStripMenuItem
            // 
            this.modoPréVendaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.habilitarToolStripMenuItem1,
            this.desabilitarToolStripMenuItem1});
            this.modoPréVendaToolStripMenuItem.Name = "modoPréVendaToolStripMenuItem";
            this.modoPréVendaToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.modoPréVendaToolStripMenuItem.Text = "Modo Pré-Venda";
            this.modoPréVendaToolStripMenuItem.Click += new System.EventHandler(this.modoPréVendaToolStripMenuItem_Click);
            // 
            // habilitarToolStripMenuItem1
            // 
            this.habilitarToolStripMenuItem1.Name = "habilitarToolStripMenuItem1";
            this.habilitarToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.habilitarToolStripMenuItem1.Text = "Habilitar";
            this.habilitarToolStripMenuItem1.Click += new System.EventHandler(this.habilitarToolStripMenuItem1_Click);
            // 
            // desabilitarToolStripMenuItem1
            // 
            this.desabilitarToolStripMenuItem1.Name = "desabilitarToolStripMenuItem1";
            this.desabilitarToolStripMenuItem1.Size = new System.Drawing.Size(129, 22);
            this.desabilitarToolStripMenuItem1.Text = "Desabilitar";
            this.desabilitarToolStripMenuItem1.Click += new System.EventHandler(this.desabilitarToolStripMenuItem1_Click);
            // 
            // avançoPapelToolStripMenuItem
            // 
            this.avançoPapelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem});
            this.avançoPapelToolStripMenuItem.Name = "avançoPapelToolStripMenuItem";
            this.avançoPapelToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.avançoPapelToolStripMenuItem.Text = "Avanço Papel";
            // 
            // métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem
            // 
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem.Name = "métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem";
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(340, 22);
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem.Text = "Método confProgramarAvancoPapel_ECF_Daruma";
            this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem_Click);
            // 
            // lojaToolStripMenuItem
            // 
            this.lojaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem});
            this.lojaToolStripMenuItem.Name = "lojaToolStripMenuItem";
            this.lojaToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.lojaToolStripMenuItem.Text = "Loja";
            // 
            // métodoConfProgramarIDLojaECFDarumaToolStripMenuItem
            // 
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem.Name = "métodoConfProgramarIDLojaECFDarumaToolStripMenuItem";
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(304, 22);
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem.Text = "Método confProgramarIDLoja_ECF_Daruma";
            this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoConfProgramarIDLojaECFDarumaToolStripMenuItem_Click);
            // 
            // operadorToolStripMenuItem
            // 
            this.operadorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem});
            this.operadorToolStripMenuItem.Name = "operadorToolStripMenuItem";
            this.operadorToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.operadorToolStripMenuItem.Text = "Operador";
            // 
            // métodoConfProgramarOperadorECFDarumaToolStripMenuItem
            // 
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem.Name = "métodoConfProgramarOperadorECFDarumaToolStripMenuItem";
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(321, 22);
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem.Text = "Método confProgramarOperador_ECF_Daruma";
            this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoConfProgramarOperadorECFDarumaToolStripMenuItem_Click);
            // 
            // MS_Metodos_RetornosECF
            // 
            this.MS_Metodos_RetornosECF.Name = "MS_Metodos_RetornosECF";
            this.MS_Metodos_RetornosECF.Size = new System.Drawing.Size(150, 19);
            this.MS_Metodos_RetornosECF.Text = "Retornos e Status do ECF";
            this.MS_Metodos_RetornosECF.Click += new System.EventHandler(this.MS_Metodos_RetornosECF_Click);
            // 
            // MN_Metodos_Gaveta_Autentica_E_Outros
            // 
            this.MN_Metodos_Gaveta_Autentica_E_Outros.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem,
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem});
            this.MN_Metodos_Gaveta_Autentica_E_Outros.Name = "MN_Metodos_Gaveta_Autentica_E_Outros";
            this.MN_Metodos_Gaveta_Autentica_E_Outros.Size = new System.Drawing.Size(160, 19);
            this.MN_Metodos_Gaveta_Autentica_E_Outros.Text = "Gaveta, Autentica e Outros";
            // 
            // métodoIAbrirGavetaECFDarumaToolStripMenuItem
            // 
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem.Name = "métodoIAbrirGavetaECFDarumaToolStripMenuItem";
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem.Text = "Método eAcionarGuilhotina_ECF_Daruma";
            this.métodoIAbrirGavetaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoIAbrirGavetaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoEAbrirGavetaECFDarumaToolStripMenuItem
            // 
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem.Name = "métodoEAbrirGavetaECFDarumaToolStripMenuItem";
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem.Text = "Método eAbrirGaveta_ECF_Daruma";
            this.métodoEAbrirGavetaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEAbrirGavetaECFDarumaToolStripMenuItem_Click);
            // 
            // MN_Metodos_Cheque
            // 
            this.MN_Metodos_Cheque.Name = "MN_Metodos_Cheque";
            this.MN_Metodos_Cheque.Size = new System.Drawing.Size(60, 19);
            this.MN_Metodos_Cheque.Text = "Cheque";
            this.MN_Metodos_Cheque.Click += new System.EventHandler(this.MN_Metodos_Cheque_Click);
            // 
            // MN_Metodos_Codigo_Barras
            // 
            this.MN_Metodos_Codigo_Barras.Name = "MN_Metodos_Codigo_Barras";
            this.MN_Metodos_Codigo_Barras.Size = new System.Drawing.Size(109, 19);
            this.MN_Metodos_Codigo_Barras.Text = "Código de Barras";
            this.MN_Metodos_Codigo_Barras.Click += new System.EventHandler(this.MN_Metodos_Codigo_Barras_Click);
            // 
            // MN_Metodos_Registry
            // 
            this.MN_Metodos_Registry.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.geralDarumaFrameworkToolStripMenuItem,
            this.cupomFiscalToolStripMenuItem,
            this.chequeToolStripMenuItem,
            this.cCDToolStripMenuItem,
            this.eCFToolStripMenuItem1,
            this.atoCotepeToolStripMenuItem,
            this.sintegraToolStripMenuItem,
            this.especiaisDarumaFrameworkToolStripMenuItem});
            this.MN_Metodos_Registry.Name = "MN_Metodos_Registry";
            this.MN_Metodos_Registry.Size = new System.Drawing.Size(61, 19);
            this.MN_Metodos_Registry.Text = "Registry";
            this.MN_Metodos_Registry.Click += new System.EventHandler(this.MN_Metodos_Registry_Click);
            // 
            // geralDarumaFrameworkToolStripMenuItem
            // 
            this.geralDarumaFrameworkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem});
            this.geralDarumaFrameworkToolStripMenuItem.Name = "geralDarumaFrameworkToolStripMenuItem";
            this.geralDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.geralDarumaFrameworkToolStripMenuItem.Text = "Método reg";
            // 
            // métodoRegRetornaValorChaveECFDarumaToolStripMenuItem
            // 
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem.Name = "métodoRegRetornaValorChaveECFDarumaToolStripMenuItem";
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(343, 22);
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem.Text = "Método regRetornaValorChave_DarumaFramework";
            this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegRetornaValorChaveECFDarumaToolStripMenuItem_Click);
            // 
            // cupomFiscalToolStripMenuItem
            // 
            this.cupomFiscalToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem,
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem,
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem,
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem,
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem,
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem,
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem,
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem,
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem,
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem});
            this.cupomFiscalToolStripMenuItem.Name = "cupomFiscalToolStripMenuItem";
            this.cupomFiscalToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.cupomFiscalToolStripMenuItem.Text = "Cupom Fiscal";
            // 
            // métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem.Name = "métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem";
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem.Text = "Método regCFCupomAdicionalDllConfig_ECF_Daruma";
            this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem.Name = "métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem";
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem.Text = "Método regCFCupomAdicionalDllTitulo_ECF_Daruma";
            this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFCupomManiaECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem.Name = "métodoRegCFCupomManiaECFDarumaToolStripMenuItem";
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem.Text = "Método regCFCupomMania_ECF_Daruma";
            this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFCupomManiaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFFormaPgtoECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem.Name = "métodoRegCFFormaPgtoECFDarumaToolStripMenuItem";
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem.Text = "Método regCFFormaPgto_ECF_Daruma";
            this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFFormaPgtoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem.Name = "métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem";
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem.Text = "Método regCFMensagemPromocional_ECF_Daruma";
            this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFQuantidadeECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem.Name = "métodoRegCFQuantidadeECFDarumaToolStripMenuItem";
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem.Text = "Método regCFQuantidade_ECF_Daruma";
            this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFQuantidadeECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem.Name = "métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem";
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem.Text = "Método regCFTamanhoMinimoDescricao_ECF_Daruma";
            this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem.Name = "métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem";
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem.Text = "Método regCFTipoDescAcresc_ECF_Daruma";
            this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem.Name = "métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem";
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem.Text = "Método regCFUnidadeMedida_ECF_Daruma";
            this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem
            // 
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem.Name = "métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem";
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(366, 22);
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem.Text = "Método regCFValorDescAcresc_ECF_Daruma";
            this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem_Click);
            // 
            // chequeToolStripMenuItem
            // 
            this.chequeToolStripMenuItem.Name = "chequeToolStripMenuItem";
            this.chequeToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.chequeToolStripMenuItem.Text = "Cheque";
            // 
            // cCDToolStripMenuItem
            // 
            this.cCDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegCCDECFDarumaToolStripMenuItem,
            this.métodoToolStripMenuItem1,
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem,
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem,
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem,
            this.métodoRegCCDValorECFDarumaToolStripMenuItem});
            this.cCDToolStripMenuItem.Name = "cCDToolStripMenuItem";
            this.cCDToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.cCDToolStripMenuItem.Text = "CCD";
            // 
            // métodoRegCCDECFDarumaToolStripMenuItem
            // 
            this.métodoRegCCDECFDarumaToolStripMenuItem.Name = "métodoRegCCDECFDarumaToolStripMenuItem";
            this.métodoRegCCDECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoRegCCDECFDarumaToolStripMenuItem.Text = "Método regCCD_ECF_Daruma";
            
            // 
            // métodoToolStripMenuItem1
            // 
            this.métodoToolStripMenuItem1.Name = "métodoToolStripMenuItem1";
            this.métodoToolStripMenuItem1.Size = new System.Drawing.Size(293, 22);
            this.métodoToolStripMenuItem1.Text = "Método regCCDDocOrigem_ECF_Daruma";
            this.métodoToolStripMenuItem1.Click += new System.EventHandler(this.métodoToolStripMenuItem1_Click);
            // 
            // métodoRegCCFormaPgtoECFDarumaToolStripMenuItem
            // 
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem.Name = "métodoRegCCFormaPgtoECFDarumaToolStripMenuItem";
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem.Text = "Método regCCDFormaPgto_ECF_Daruma";
            this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCCFormaPgtoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem
            // 
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem.Name = "métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem";
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem.Text = "Método regCCDLinhasTEF_ECF_Daruma";
            this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCCDParcelasECFDarumaToolStripMenuItem
            // 
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem.Name = "métodoRegCCDParcelasECFDarumaToolStripMenuItem";
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem.Text = "Método regCCDParcelas_ECF_Daruma";
            this.métodoRegCCDParcelasECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCCDParcelasECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegCCDValorECFDarumaToolStripMenuItem
            // 
            this.métodoRegCCDValorECFDarumaToolStripMenuItem.Name = "métodoRegCCDValorECFDarumaToolStripMenuItem";
            this.métodoRegCCDValorECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(293, 22);
            this.métodoRegCCDValorECFDarumaToolStripMenuItem.Text = "Método regCCDValor_ECF_Daruma";
            this.métodoRegCCDValorECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegCCDValorECFDarumaToolStripMenuItem_Click);
            // 
            // eCFToolStripMenuItem1
            // 
            this.eCFToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegAlterToolStripMenuItem,
            this.métodoRegLoginDarumaToolStripMenuItem,
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem,
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem,
            this.métodoRegToolStripMenuItem,
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem,
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem,
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem,
            this.métodoRegToolStripMenuItem1,
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem,
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem});
            this.eCFToolStripMenuItem1.Name = "eCFToolStripMenuItem1";
            this.eCFToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.eCFToolStripMenuItem1.Text = "ECF";
            // 
            // métodoRegAlterToolStripMenuItem
            // 
            this.métodoRegAlterToolStripMenuItem.Name = "métodoRegAlterToolStripMenuItem";
            this.métodoRegAlterToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegAlterToolStripMenuItem.Text = "Método regAlterarValor_ECF_Daruma";
            this.métodoRegAlterToolStripMenuItem.Click += new System.EventHandler(this.métodoRegAlterToolStripMenuItem_Click);
            // 
            // métodoRegLoginDarumaToolStripMenuItem
            // 
            this.métodoRegLoginDarumaToolStripMenuItem.Name = "métodoRegLoginDarumaToolStripMenuItem";
            this.métodoRegLoginDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegLoginDarumaToolStripMenuItem.Text = "Método regLogin_Daruma";
            this.métodoRegLoginDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegLoginDarumaToolStripMenuItem_Click);
            // 
            // métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem.Name = "métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem";
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem.Text = "Método regECFAguardarImpressao_ECF_Daruma";
            this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem_Click);
            // 
            // métoRegECFArquivoLeituraECFDarumaToolStripMenuItem
            // 
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem.Name = "métoRegECFArquivoLeituraECFDarumaToolStripMenuItem";
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem.Text = "Método regECFArquivoLeitura_ECF_Daruma";
            this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métoRegECFArquivoLeituraECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegToolStripMenuItem
            // 
            this.métodoRegToolStripMenuItem.Name = "métodoRegToolStripMenuItem";
            this.métodoRegToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegToolStripMenuItem.Text = "Método regECFAuditoria_ECF_Daruma";
            this.métodoRegToolStripMenuItem.Click += new System.EventHandler(this.métodoRegToolStripMenuItem_Click);
            // 
            // métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem.Name = "métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem";
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem.Text = "Método regECFCaracterSeparador_ECF_Daruma";
            this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem.Name = "métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem";
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem.Text = "Método regECFMaxFechamentoAutomatico_ECF_Daruma";
            this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem.Name = "métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem";
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem.Text = "Método regECFReceberAvisoEmArquivo_ECF_Daruma";
            this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegToolStripMenuItem1
            // 
            this.métodoRegToolStripMenuItem1.Name = "métodoRegToolStripMenuItem1";
            this.métodoRegToolStripMenuItem1.Size = new System.Drawing.Size(401, 22);
            this.métodoRegToolStripMenuItem1.Text = "Método regECFReceberErroEmArquivo_ECF_Daruma";
            this.métodoRegToolStripMenuItem1.Click += new System.EventHandler(this.métodoRegToolStripMenuItem1_Click);
            // 
            // métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem.Name = "métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem";
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem.Text = "Método regECFReceberInfoEstendida_ECF_Daruma";
            this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem
            // 
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem.Name = "métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem";
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(401, 22);
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem.Text = "Método regECFReceberInfoEstendidaEmArquivo_ECF_Daruma";
            this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem_Click);
            // 
            // atoCotepeToolStripMenuItem
            // 
            this.atoCotepeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem});
            this.atoCotepeToolStripMenuItem.Name = "atoCotepeToolStripMenuItem";
            this.atoCotepeToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.atoCotepeToolStripMenuItem.Text = "Ato Cotepe";
            // 
            // métodoRegAtocotepeECFDarumaToolStripMenuItem
            // 
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem.Name = "métodoRegAtocotepeECFDarumaToolStripMenuItem";
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(263, 22);
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem.Text = "Método regAtocotepe_ECF_Daruma";
            this.métodoRegAtocotepeECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRegAtocotepeECFDarumaToolStripMenuItem_Click);
            // 
            // sintegraToolStripMenuItem
            // 
            this.sintegraToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRegSintegraECFDarumaToolStripMenuItem});
            this.sintegraToolStripMenuItem.Name = "sintegraToolStripMenuItem";
            this.sintegraToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.sintegraToolStripMenuItem.Text = "Sintegra";
            // 
            // métodoRegSintegraECFDarumaToolStripMenuItem
            // 
            this.métodoRegSintegraECFDarumaToolStripMenuItem.Name = "métodoRegSintegraECFDarumaToolStripMenuItem";
            this.métodoRegSintegraECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.métodoRegSintegraECFDarumaToolStripMenuItem.Text = "Método regSintegra_ECF_Daruma";
            // 
            // especiaisDarumaFrameworkToolStripMenuItem
            // 
            this.especiaisDarumaFrameworkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoEDefinirProdutoDarumaToolStripMenuItem,
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem,
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem,
            this.métodoERetornarErroECFToolStripMenuItem,
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem});
            this.especiaisDarumaFrameworkToolStripMenuItem.Name = "especiaisDarumaFrameworkToolStripMenuItem";
            this.especiaisDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.especiaisDarumaFrameworkToolStripMenuItem.Text = "Especiais ";
            this.especiaisDarumaFrameworkToolStripMenuItem.Click += new System.EventHandler(this.especiaisDarumaFrameworkToolStripMenuItem_Click);
            // 
            // métodoEDefinirProdutoDarumaToolStripMenuItem
            // 
            this.métodoEDefinirProdutoDarumaToolStripMenuItem.Name = "métodoEDefinirProdutoDarumaToolStripMenuItem";
            this.métodoEDefinirProdutoDarumaToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoEDefinirProdutoDarumaToolStripMenuItem.Text = "Método eDefinirProduto_Daruma";
            this.métodoEDefinirProdutoDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEDefinirProdutoDarumaToolStripMenuItem_Click);
            // 
            // métodoEDefinirModoRegistroDarumaToolStripMenuItem
            // 
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem.Name = "métodoEDefinirModoRegistroDarumaToolStripMenuItem";
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem.Text = "Método eDefinirModoRegistro_Daruma";
            this.métodoEDefinirModoRegistroDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEDefinirModoRegistroDarumaToolStripMenuItem_Click);
            // 
            // métodoERetornarAvisoECFDarumaToolStripMenuItem
            // 
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem.Name = "métodoERetornarAvisoECFDarumaToolStripMenuItem";
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem.Text = "Método eRetornarAviso_ECF_Daruma";
            this.métodoERetornarAvisoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoERetornarAvisoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoERetornarErroECFToolStripMenuItem
            // 
            this.métodoERetornarErroECFToolStripMenuItem.Name = "métodoERetornarErroECFToolStripMenuItem";
            this.métodoERetornarErroECFToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoERetornarErroECFToolStripMenuItem.Text = "Método eRetornarErro_ECF_Daruma";
            this.métodoERetornarErroECFToolStripMenuItem.Click += new System.EventHandler(this.métodoERetornarErroECFToolStripMenuItem_Click);
            // 
            // métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem
            // 
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem.Name = "métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem";
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(320, 22);
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem.Text = "Método eAguardarCompactação_ECF_Daruma";
            this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem_Click);
            // 
            // MN_Metodos_Geracao_Arquivos
            // 
            this.MN_Metodos_Geracao_Arquivos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem,
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem,
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem});
            this.MN_Metodos_Geracao_Arquivos.Name = "MN_Metodos_Geracao_Arquivos";
            this.MN_Metodos_Geracao_Arquivos.Size = new System.Drawing.Size(128, 19);
            this.MN_Metodos_Geracao_Arquivos.Text = "Geração de Arquivos";
            this.MN_Metodos_Geracao_Arquivos.Click += new System.EventHandler(this.MN_Metodos_Cupom_ManiaRJ_Click);
            // 
            // métodoRCMGerarRelatorioECFDarumaToolStripMenuItem
            // 
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem.Name = "métodoRCMGerarRelatorioECFDarumaToolStripMenuItem";
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(590, 22);
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem.Text = "Método rGerarRelatorio_ECF_Daruma(MFD-PAF, MF-PAF, Nota Fiscais Estaduais e Sinte" +
                "gra)";
            this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRCMGerarRelatorioECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRGerarRelatorioOffECFDarumaToolStripMenuItem
            // 
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem.Name = "métodoRGerarRelatorioOffECFDarumaToolStripMenuItem";
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(590, 22);
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem.Text = "Método rGerarRelatorioOffline_ECF_Daruma(MFD-PAF, MF-PAF, Nota Fiscais Estaduais " +
                "e Sintegra)";
            this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRGerarRelatorioOffECFDarumaToolStripMenuItem_Click);
            // 
            // MN_Metodos_TEF
            // 
            this.MN_Metodos_TEF.Name = "MN_Metodos_TEF";
            this.MN_Metodos_TEF.Size = new System.Drawing.Size(38, 19);
            this.MN_Metodos_TEF.Text = "TEF";
            this.MN_Metodos_TEF.Click += new System.EventHandler(this.MN_Metodos_TEF_Click);
            // 
            // MN_Metodos_PAF_ECF
            // 
            this.MN_Metodos_PAF_ECF.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.métodoRCalcularMD5EToolStripMenuItem,
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem,
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem,
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem,
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem,
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem,
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem});
            this.MN_Metodos_PAF_ECF.Name = "MN_Metodos_PAF_ECF";
            this.MN_Metodos_PAF_ECF.Size = new System.Drawing.Size(65, 19);
            this.MN_Metodos_PAF_ECF.Text = "PAF-ECF";
            // 
            // métodoRCalcularMD5EToolStripMenuItem
            // 
            this.métodoRCalcularMD5EToolStripMenuItem.Name = "métodoRCalcularMD5EToolStripMenuItem";
            this.métodoRCalcularMD5EToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRCalcularMD5EToolStripMenuItem.Text = "Método rCalcularMD5_ECF_Daruma";
            this.métodoRCalcularMD5EToolStripMenuItem.Click += new System.EventHandler(this.métodoRCalcularMD5EToolStripMenuItem_Click);
            // 
            // métodoRAssinarRSAECFDarumaToolStripMenuItem
            // 
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem.Name = "métodoRAssinarRSAECFDarumaToolStripMenuItem";
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem.Text = "Método rAssinarRSA_ECF_Daruma";
            this.métodoRAssinarRSAECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRAssinarRSAECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem
            // 
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem.Name = "métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem";
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem.Text = "Método rRetornarGTCodificado_ECF_Daruma";
            this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem
            // 
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem.Name = "métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem";
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem.Text = "Método rVerificarGTCodificado_ECF_Daruma";
            this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem
            // 
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Name = "métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem";
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Text = "Método rRetornarNumeroSerieCodificado_ECF_Daruma";
            this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem
            // 
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Name = "métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem";
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Text = "Método rVerificarNumeroSerieCodificado_ECF_Daruma";
            this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem_Click);
            // 
            // métodoERSAAssinarArquivoECFDarumaToolStripMenuItem
            // 
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem.Name = "métodoERSAAssinarArquivoECFDarumaToolStripMenuItem";
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(367, 22);
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem.Text = "Método eRSAAssinarArquivo_ECF_Daruma";
            this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoERSAAssinarArquivoECFDarumaToolStripMenuItem_Click);
            // 
            // MN_Metodos_MenuFiscal
            // 
            this.MN_Metodos_MenuFiscal.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lXToolStripMenuItem,
            this.lMFSToolStripMenuItem,
            this.lMDCToolStripMenuItem,
            this.espelhoMFDToolStripMenuItem,
            this.arqMFDToolStripMenuItem1,
            this.tabProdToolStripMenuItem,
            this.estoqueToolStripMenuItem,
            this.movimentoPorECFToolStripMenuItem,
            this.meiosDePToolStripMenuItem,
            this.vendasDoPeríodoToolStripMenuItem,
            this.identificaçãoDoPAFECFToolStripMenuItem,
            this.toolStripMenuItem13,
            this.dAVEmitidosToolStripMenuItem,
            this.encerrantesToolStripMenuItem,
            this.transfMesasToolStripMenuItem,
            this.mesasAbertasToolStripMenuItem,
            this.manifestoFiscalDeViagemToolStripMenuItem,
            this.tabIndiceTécnicoProduçãoToolStripMenuItem});
            this.MN_Metodos_MenuFiscal.Name = "MN_Metodos_MenuFiscal";
            this.MN_Metodos_MenuFiscal.Size = new System.Drawing.Size(82, 19);
            this.MN_Metodos_MenuFiscal.Text = "Menu Fiscal";
            this.MN_Metodos_MenuFiscal.Click += new System.EventHandler(this.MN_Metodos_MenuFiscal_Click);
            // 
            // lXToolStripMenuItem
            // 
            this.lXToolStripMenuItem.Name = "lXToolStripMenuItem";
            this.lXToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.lXToolStripMenuItem.Text = "LX";
            this.lXToolStripMenuItem.Click += new System.EventHandler(this.lXToolStripMenuItem_Click);
            // 
            // lMFSToolStripMenuItem
            // 
            this.lMFSToolStripMenuItem.Name = "lMFSToolStripMenuItem";
            this.lMFSToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.lMFSToolStripMenuItem.Text = "LMFC";
            this.lMFSToolStripMenuItem.Click += new System.EventHandler(this.lMFSToolStripMenuItem_Click);
            // 
            // lMDCToolStripMenuItem
            // 
            this.lMDCToolStripMenuItem.Name = "lMDCToolStripMenuItem";
            this.lMDCToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.lMDCToolStripMenuItem.Text = "LMFS";
            this.lMDCToolStripMenuItem.Click += new System.EventHandler(this.lMDCToolStripMenuItem_Click);
            // 
            // espelhoMFDToolStripMenuItem
            // 
            this.espelhoMFDToolStripMenuItem.Name = "espelhoMFDToolStripMenuItem";
            this.espelhoMFDToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.espelhoMFDToolStripMenuItem.Text = "Espelho MFD";
            this.espelhoMFDToolStripMenuItem.Click += new System.EventHandler(this.espelhoMFDToolStripMenuItem_Click);
            // 
            // arqMFDToolStripMenuItem1
            // 
            this.arqMFDToolStripMenuItem1.Name = "arqMFDToolStripMenuItem1";
            this.arqMFDToolStripMenuItem1.Size = new System.Drawing.Size(231, 22);
            this.arqMFDToolStripMenuItem1.Text = "Arq. MFD";
            this.arqMFDToolStripMenuItem1.Click += new System.EventHandler(this.arqMFDToolStripMenuItem1_Click);
            // 
            // tabProdToolStripMenuItem
            // 
            this.tabProdToolStripMenuItem.Name = "tabProdToolStripMenuItem";
            this.tabProdToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.tabProdToolStripMenuItem.Text = "Tab. Prod";
            this.tabProdToolStripMenuItem.Click += new System.EventHandler(this.tabProdToolStripMenuItem_Click_1);
            // 
            // estoqueToolStripMenuItem
            // 
            this.estoqueToolStripMenuItem.Name = "estoqueToolStripMenuItem";
            this.estoqueToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.estoqueToolStripMenuItem.Text = "Estoque";
            this.estoqueToolStripMenuItem.Click += new System.EventHandler(this.estoqueToolStripMenuItem_Click);
            // 
            // movimentoPorECFToolStripMenuItem
            // 
            this.movimentoPorECFToolStripMenuItem.Name = "movimentoPorECFToolStripMenuItem";
            this.movimentoPorECFToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.movimentoPorECFToolStripMenuItem.Text = "Movimento por ECF";
            this.movimentoPorECFToolStripMenuItem.Click += new System.EventHandler(this.movimentoPorECFToolStripMenuItem_Click);
            // 
            // meiosDePToolStripMenuItem
            // 
            this.meiosDePToolStripMenuItem.Name = "meiosDePToolStripMenuItem";
            this.meiosDePToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.meiosDePToolStripMenuItem.Text = "Meios de Pagto";
            this.meiosDePToolStripMenuItem.Click += new System.EventHandler(this.meiosDePToolStripMenuItem_Click);
            // 
            // vendasDoPeríodoToolStripMenuItem
            // 
            this.vendasDoPeríodoToolStripMenuItem.Name = "vendasDoPeríodoToolStripMenuItem";
            this.vendasDoPeríodoToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.vendasDoPeríodoToolStripMenuItem.Text = "Vendas do Período";
            this.vendasDoPeríodoToolStripMenuItem.Click += new System.EventHandler(this.vendasDoPeríodoToolStripMenuItem_Click);
            // 
            // identificaçãoDoPAFECFToolStripMenuItem
            // 
            this.identificaçãoDoPAFECFToolStripMenuItem.Name = "identificaçãoDoPAFECFToolStripMenuItem";
            this.identificaçãoDoPAFECFToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.identificaçãoDoPAFECFToolStripMenuItem.Text = "Identificação do PAF-ECF";
            this.identificaçãoDoPAFECFToolStripMenuItem.Click += new System.EventHandler(this.identificaçãoDoPAFECFToolStripMenuItem_Click);
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem13.Enabled = false;
            this.toolStripMenuItem13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Underline);
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(231, 22);
            this.toolStripMenuItem13.Text = "-------------------------------------";
            // 
            // dAVEmitidosToolStripMenuItem
            // 
            this.dAVEmitidosToolStripMenuItem.Name = "dAVEmitidosToolStripMenuItem";
            this.dAVEmitidosToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.dAVEmitidosToolStripMenuItem.Text = "DAV Emitidos";
            this.dAVEmitidosToolStripMenuItem.Click += new System.EventHandler(this.dAVEmitidosToolStripMenuItem_Click);
            // 
            // encerrantesToolStripMenuItem
            // 
            this.encerrantesToolStripMenuItem.Name = "encerrantesToolStripMenuItem";
            this.encerrantesToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.encerrantesToolStripMenuItem.Text = "Encerrantes";
            this.encerrantesToolStripMenuItem.Click += new System.EventHandler(this.encerrantesToolStripMenuItem_Click);
            // 
            // transfMesasToolStripMenuItem
            // 
            this.transfMesasToolStripMenuItem.Name = "transfMesasToolStripMenuItem";
            this.transfMesasToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.transfMesasToolStripMenuItem.Text = "Transf. Mesas";
            this.transfMesasToolStripMenuItem.Click += new System.EventHandler(this.transfMesasToolStripMenuItem_Click);
            // 
            // mesasAbertasToolStripMenuItem
            // 
            this.mesasAbertasToolStripMenuItem.Name = "mesasAbertasToolStripMenuItem";
            this.mesasAbertasToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.mesasAbertasToolStripMenuItem.Text = "Mesas Abertas";
            this.mesasAbertasToolStripMenuItem.Click += new System.EventHandler(this.mesasAbertasToolStripMenuItem_Click);
            // 
            // manifestoFiscalDeViagemToolStripMenuItem
            // 
            this.manifestoFiscalDeViagemToolStripMenuItem.Name = "manifestoFiscalDeViagemToolStripMenuItem";
            this.manifestoFiscalDeViagemToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.manifestoFiscalDeViagemToolStripMenuItem.Text = "Manifesto Fiscal de Viagem";
            this.manifestoFiscalDeViagemToolStripMenuItem.Click += new System.EventHandler(this.manifestoFiscalDeViagemToolStripMenuItem_Click);
            // 
            // tabIndiceTécnicoProduçãoToolStripMenuItem
            // 
            this.tabIndiceTécnicoProduçãoToolStripMenuItem.Name = "tabIndiceTécnicoProduçãoToolStripMenuItem";
            this.tabIndiceTécnicoProduçãoToolStripMenuItem.Size = new System.Drawing.Size(231, 22);
            this.tabIndiceTécnicoProduçãoToolStripMenuItem.Text = "Tab. Indice Técnico Produção";
            this.tabIndiceTécnicoProduçãoToolStripMenuItem.Click += new System.EventHandler(this.tabIndiceTécnicoProduçãoToolStripMenuItem_Click);
            // 
            // exemplsoToolStripMenuItem
            // 
            this.exemplsoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testeDeConsumoDeMFDToolStripMenuItem});
            this.exemplsoToolStripMenuItem.Name = "exemplsoToolStripMenuItem";
            this.exemplsoToolStripMenuItem.Size = new System.Drawing.Size(69, 19);
            this.exemplsoToolStripMenuItem.Text = "Exemplos";
            // 
            // testeDeConsumoDeMFDToolStripMenuItem
            // 
            this.testeDeConsumoDeMFDToolStripMenuItem.Name = "testeDeConsumoDeMFDToolStripMenuItem";
            this.testeDeConsumoDeMFDToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.testeDeConsumoDeMFDToolStripMenuItem.Text = "Teste Consumo MFD";
            this.testeDeConsumoDeMFDToolStripMenuItem.Click += new System.EventHandler(this.testeDeConsumoDeMFDToolStripMenuItem_Click);
            // 
            // métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem
            // 
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem.Name = "métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem";
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem.Size = new System.Drawing.Size(590, 22);
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem.Text = "Método rGerarEspelhoMFD_ECF_Daruma";
            this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem.Click += new System.EventHandler(this.métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem_Click);
            // 
            // FR_MenuImpressoraFiscal_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 501);
            this.Controls.Add(this.MS_Geral_Fiscal);
            this.Controls.Add(this.lb_duvidas);
            this.Controls.Add(this.PN_Dual);
            this.Controls.Add(this.BT_fechar);
            this.Name = "FR_MenuImpressoraFiscal_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Daruma Framework - C#  - Impressora Fiscal";
            this.Load += new System.EventHandler(this.FR_MenuImpressoraFiscal_Principal_Load);
            this.PN_Dual.ResumeLayout(false);
            this.PN_Dual.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).EndInit();
            this.MS_Geral_Fiscal.ResumeLayout(false);
            this.MS_Geral_Fiscal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_DLL;
        private System.Windows.Forms.Label lb_duvidas;
        private System.Windows.Forms.Label LB_Impressoras;
        private System.Windows.Forms.Panel PN_Dual;
        private System.Windows.Forms.Button BT_fechar;
        private System.Windows.Forms.MenuStrip MS_Geral_Fiscal;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Cupom;
        private System.Windows.Forms.ToolStripMenuItem MN_AberturaCupomFiscal;
        private System.Windows.Forms.ToolStripMenuItem métodoICFAbrirPadraoECFDarumaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem métodoiCFAbrir_ECF_Daruma;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoICFVenderECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFVenderSemDescECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFVenderResumidoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem métodoICFLancarAcrescimoItemECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFLancarDescontoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFLancarAcrescimoUltimoItemECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFLancarDescontoUltimoItemECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarUltimoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarItemParcialECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarUltimoItemParcialECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarDescontoItemECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarDescUltimoItemECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem métodoICFTotalizarCupomECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFTotalizarCupomPadraoECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarDescontoSubtotalECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarAcrescimoSubtotalECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEfetuarPagamentoPadraoECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEfetuarPagamentoFormatadoECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEfetuarPagamentoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEncerrarPadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEncerrarConfigMsgECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEncerrarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFFecharResumidoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFEmitirCupomAdicionalECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem métodoICFCancelarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem métodoICFIdentificarConsumidorECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_CCD;
        private System.Windows.Forms.ToolStripMenuItem aberturaCCDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDAbrirECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDAbrirSimplificadoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDAbrirPadraoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem textoImprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDImprimirTextoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDImprimirArquivoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encerrarCCDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDFecharECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem estornoCCDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDEstornoPadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICCDEstornarECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_CNF;
        private System.Windows.Forms.ToolStripMenuItem aberturaDeComprovanteNãoFiscalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFAbrirECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFAbrirPadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rcebimentoDeItensToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFReceberECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFReceberSemDescECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelamentoDeItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarUltimoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelamentoDeAcrescimoEmItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarAcrescimoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelamentoDeDescontoEmItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarDescontoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarDescontoUltimoItemECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem totalizacaoDeCNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFTotalizarComprovanteECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFTotalizarComprovantePadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelamentoDeDescontoEAcrescimoEmSubtotalDeCNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarAcrescimoSubtotalECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarDescontoSubtotalECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem descricaoDosMeiosDePagamentoDeCNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFEfetuarPagamentoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFEfetuarPagamentoFormatadoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFEfetuarPagamentoPadrToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encerramentoDeCNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFEncerrarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFEncerrarPadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelamentoDeCNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICNFCancelarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_RG;
        private System.Windows.Forms.ToolStripMenuItem aberturaRelatórioGerencialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoIRGAbrirECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoIRGAbrirIndiceECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoIRGAbrirPadraoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem textoImpressãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoIRGImprimirTextoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem encerramentoRelatórioGerencialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoIRGFecharECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Bilhete_Passagem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFAbrirECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFBPVenderECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoICFBPProgramarUFECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Relatorios_Fiscais;
        private System.Windows.Forms.ToolStripMenuItem leituraXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoILeituraXECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRLeituraXECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem reduçãoZToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoIReducaoZECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sangriaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoISangriaPadraoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoISangriaECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem suprimentoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoISuprimentoPadraoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoISuprimentoECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem leituraMemóriaFiscalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoIMFLerECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoIMFLerSerialECFDarumaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Gaveta_Autentica_E_Outros;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Programacao_Impressora;
        private System.Windows.Forms.ToolStripMenuItem eCFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoConfCadastrarPadraoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoConfCadastrarECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem horárioDeVerãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem habilitarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desabilitarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem modoPréVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem habilitarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem desabilitarToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem avançoPapelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lojaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operadorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Cheque;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Codigo_Barras;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Registry;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Geracao_Arquivos;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_TEF;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_PAF_ECF;
        private System.Windows.Forms.ToolStripMenuItem métodoRAssinarRSAECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRCalcularMD5EToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_MenuFiscal;
        private System.Windows.Forms.ToolStripMenuItem métodoConfProgramarAvancoPapelECFDarumaToolStripMenuItem;
        private System.Windows.Forms.PictureBox PB_DDC;
        private System.Windows.Forms.ToolStripMenuItem métodoConfProgramarIDLojaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoConfProgramarOperadorECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoIAbrirGavetaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRCMGerarRelatorioECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MS_Metodos_RetornosECF;
        private System.Windows.Forms.ToolStripMenuItem geralDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem especiaisDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cupomFiscalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cCDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chequeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eCFToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem espelhoMFDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFCupomAdicionalDllConfigECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFCupomAdicionalDllTituloECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFCupomManiaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFFormaPgtoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFMensagemPromocionalECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFQuantidadeECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFTamanhoMinimoDescricaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFTipoDescAcrescECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFUnidadeMedidaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCFValorDescAcrescECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRGerarRelatorioOffECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEAbrirGavetaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lMDCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lMFSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabProdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem estoqueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem movimentoPorECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meiosDePToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem identificaçãoDoPAFECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vendasDoPeríodoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabIndiceTécnicoProduçãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arqMFDToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cupomManiaParaOEstadoDoRJToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ªViaDoCCDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRRetornarGTCodificadoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRVerificarGTCodificadoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRRetornarNumeroSerieCodificadoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRVerificarNumeroSerieCodificadoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem dAVEmitidosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem encerrantesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transfMesasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mesasAbertasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manifestoFiscalDeViagemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem testedeVendadeItensSemPararBuferizandoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplsoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem exemplosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem cCDCompletoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem exemplosToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cNFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testeDeConsumoDeMFDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cupomFiscalCompletoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cupomFiscalResumidoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cupomFiscalPreVendaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configuraçãoCupomManiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem totalDeISSEICMSContabilizadoÚltimoCFManiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem atoCotepeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sintegraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCCDECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCCFormaPgtoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCCDLinhasTEFECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCCDParcelasECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegCCDValorECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegAlterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegLoginDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFAguardarImpressaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métoRegECFArquivoLeituraECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFCaracterSeparadorECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFMaxFechamentoAutomaticoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFReceberAvisoEmArquivoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFReceberInfoEstendidaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegECFReceberInfoEstendidaEmArquivoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegAtocotepeECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegSintegraECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEDefinirProdutoDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEDefinirModoRegistroDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoERetornarAvisoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoERetornarErroECFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoEAguardarCompactaçãoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRegRetornaValorChaveECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tEFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTEFEsperarArquivoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTEFTravarTecladoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eTEFSetarFocoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iTEFImprimirRespostaCartaoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iTEFImprimirRespostaECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iTEFFecharToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testeCompletoTEFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoERSAAssinarArquivoECFDarumaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem métodoRGerarEspelhoMFDECFDarumaToolStripMenuItem;
    }
}