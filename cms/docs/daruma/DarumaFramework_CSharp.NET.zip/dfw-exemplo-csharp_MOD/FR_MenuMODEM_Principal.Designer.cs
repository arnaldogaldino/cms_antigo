namespace DarumaFramework_CSharp
{
    partial class FR_MenuMODEM_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_DLL = new System.Windows.Forms.Label();
            this.PN_Modem = new System.Windows.Forms.Panel();
            this.LB_Modem = new System.Windows.Forms.Label();
            this.PB_DDC = new System.Windows.Forms.PictureBox();
            this.lb_duvidas = new System.Windows.Forms.Label();
            this.MN_Modem = new System.Windows.Forms.MenuStrip();
            this.MN_MetodosDarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_eDefinirProduto_Daruma = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regRetornaValorChave_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_MRegistro = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regLerApagar_TRUE = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regLerApagar_FALSE = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regPorta_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regThread_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regThread_TRUE = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regThread_FALSE = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regVelocidade_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regVelocidade_9600 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regVelocidade_38400 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_regVelocidade_115200 = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRegCaptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Funcao_MODEM = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_fnApagarSMS_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_fnInicializar_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_fnFinalizar_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_fnReseta_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Transmissao_MODEM = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_tEnviarSMS_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_Metodos_Recepcao_MODEM = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_rLerSMS_MODEM_DarumaFramework = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.m�todoRRetornarImeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MN_FecharJanela = new System.Windows.Forms.ToolStripMenuItem();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.TB_NovasMensagens = new System.Windows.Forms.TextBox();
            this.LB_MensagemThread = new System.Windows.Forms.Label();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.conex�oCSDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.servi�oCSDDarumaFrameworkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PN_Modem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).BeginInit();
            this.MN_Modem.SuspendLayout();
            this.SuspendLayout();
            // 
            // LB_DLL
            // 
            this.LB_DLL.AutoSize = true;
            this.LB_DLL.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DLL.Location = new System.Drawing.Point(14, 56);
            this.LB_DLL.Name = "LB_DLL";
            this.LB_DLL.Size = new System.Drawing.Size(233, 18);
            this.LB_DLL.TabIndex = 2;
            this.LB_DLL.Text = "DLL: DarumaFramework.dll";
            // 
            // PN_Modem
            // 
            this.PN_Modem.BackColor = System.Drawing.Color.White;
            this.PN_Modem.Controls.Add(this.LB_DLL);
            this.PN_Modem.Controls.Add(this.LB_Modem);
            this.PN_Modem.Controls.Add(this.PB_DDC);
            this.PN_Modem.Location = new System.Drawing.Point(-2, 267);
            this.PN_Modem.Name = "PN_Modem";
            this.PN_Modem.Size = new System.Drawing.Size(1148, 93);
            this.PN_Modem.TabIndex = 4;
            // 
            // LB_Modem
            // 
            this.LB_Modem.AutoSize = true;
            this.LB_Modem.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_Modem.Location = new System.Drawing.Point(12, 19);
            this.LB_Modem.Name = "LB_Modem";
            this.LB_Modem.Size = new System.Drawing.Size(299, 23);
            this.LB_Modem.TabIndex = 1;
            this.LB_Modem.Text = "MODEM - Daruma TeleCom";
            // 
            // PB_DDC
            // 
            this.PB_DDC.Image = global::DarumaFramework_CSharp.Properties.Resources.logoDDCpeq2;
            this.PB_DDC.Location = new System.Drawing.Point(630, 3);
            this.PB_DDC.Name = "PB_DDC";
            this.PB_DDC.Size = new System.Drawing.Size(185, 86);
            this.PB_DDC.TabIndex = 0;
            this.PB_DDC.TabStop = false;
            // 
            // lb_duvidas
            // 
            this.lb_duvidas.AutoSize = true;
            this.lb_duvidas.Font = new System.Drawing.Font("Verdana", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_duvidas.Location = new System.Drawing.Point(10, 234);
            this.lb_duvidas.Name = "lb_duvidas";
            this.lb_duvidas.Size = new System.Drawing.Size(314, 16);
            this.lb_duvidas.TabIndex = 5;
            this.lb_duvidas.Text = "Duvidas? Ligue Gratuito! - 0800 770 33 20";
            // 
            // MN_Modem
            // 
            this.MN_Modem.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_MetodosDarumaFramework,
            this.MN_MRegistro,
            this.MN_Metodos_Funcao_MODEM,
            this.MN_Metodos_Transmissao_MODEM,
            this.MN_Metodos_Recepcao_MODEM,
            this.conex�oCSDToolStripMenuItem,
            this.MN_FecharJanela});
            this.MN_Modem.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.MN_Modem.Location = new System.Drawing.Point(0, 0);
            this.MN_Modem.Name = "MN_Modem";
            this.MN_Modem.Size = new System.Drawing.Size(818, 42);
            this.MN_Modem.TabIndex = 6;
            this.MN_Modem.Text = "menuStrip1";
            // 
            // MN_MetodosDarumaFramework
            // 
            this.MN_MetodosDarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_eDefinirProduto_Daruma,
            this.MN_regRetornaValorChave_DarumaFramework});
            this.MN_MetodosDarumaFramework.Name = "MN_MetodosDarumaFramework";
            this.MN_MetodosDarumaFramework.Size = new System.Drawing.Size(196, 19);
            this.MN_MetodosDarumaFramework.Text = "&M�todos para DarumaFramework";
            // 
            // MN_eDefinirProduto_Daruma
            // 
            this.MN_eDefinirProduto_Daruma.Name = "MN_eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Size = new System.Drawing.Size(343, 22);
            this.MN_eDefinirProduto_Daruma.Text = "M�todo eDefinirProduto_Daruma";
            this.MN_eDefinirProduto_Daruma.Click += new System.EventHandler(this.MN_eDefinirProduto_Daruma_Click);
            // 
            // MN_regRetornaValorChave_DarumaFramework
            // 
            this.MN_regRetornaValorChave_DarumaFramework.Name = "MN_regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Size = new System.Drawing.Size(343, 22);
            this.MN_regRetornaValorChave_DarumaFramework.Text = "M�todo regRetornaValorChave_DarumaFramework";
            this.MN_regRetornaValorChave_DarumaFramework.Click += new System.EventHandler(this.MN_regRetornaValorChave_DarumaFramework_Click);
            // 
            // MN_MRegistro
            // 
            this.MN_MRegistro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem,
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem,
            this.MN_regPorta_MODEM_DarumaFramework,
            this.MN_regThread_MODEM_DarumaFramework,
            this.MN_regVelocidade_MODEM_DarumaFramework,
            this.m�todoRegCaptionToolStripMenuItem,
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem});
            this.MN_MRegistro.Name = "MN_MRegistro";
            this.MN_MRegistro.Size = new System.Drawing.Size(188, 19);
            this.MN_MRegistro.Text = "M�todos para &Registro(Registry)";
            // 
            // m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem
            // 
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem.Name = "m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem";
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(377, 22);
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem.Text = "M�todo regTempoAlertar_MODEM_DarumaFramework";
            this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem.Click += new System.EventHandler(this.m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem_Click);
            // 
            // m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem
            // 
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regLerApagar_TRUE,
            this.MN_regLerApagar_FALSE});
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem.Name = "m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem";
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(377, 22);
            this.m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem.Text = "M�todo regLerApagar_MODEM_DarumaFramework";
            // 
            // MN_regLerApagar_TRUE
            // 
            this.MN_regLerApagar_TRUE.Name = "MN_regLerApagar_TRUE";
            this.MN_regLerApagar_TRUE.Size = new System.Drawing.Size(106, 22);
            this.MN_regLerApagar_TRUE.Text = "TRUE";
            this.MN_regLerApagar_TRUE.Click += new System.EventHandler(this.MN_regLerApagar_TRUE_Click);
            // 
            // MN_regLerApagar_FALSE
            // 
            this.MN_regLerApagar_FALSE.Name = "MN_regLerApagar_FALSE";
            this.MN_regLerApagar_FALSE.Size = new System.Drawing.Size(106, 22);
            this.MN_regLerApagar_FALSE.Text = "FALSE";
            this.MN_regLerApagar_FALSE.Click += new System.EventHandler(this.MN_regLerApagar_FALSE_Click);
            // 
            // MN_regPorta_MODEM_DarumaFramework
            // 
            this.MN_regPorta_MODEM_DarumaFramework.Name = "MN_regPorta_MODEM_DarumaFramework";
            this.MN_regPorta_MODEM_DarumaFramework.Size = new System.Drawing.Size(377, 22);
            this.MN_regPorta_MODEM_DarumaFramework.Text = "M�todo regPorta_MODEM_DarumaFramework";
            this.MN_regPorta_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_regPorta_MODEM_DarumaFramework_Click);
            // 
            // MN_regThread_MODEM_DarumaFramework
            // 
            this.MN_regThread_MODEM_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regThread_TRUE,
            this.MN_regThread_FALSE});
            this.MN_regThread_MODEM_DarumaFramework.Name = "MN_regThread_MODEM_DarumaFramework";
            this.MN_regThread_MODEM_DarumaFramework.Size = new System.Drawing.Size(377, 22);
            this.MN_regThread_MODEM_DarumaFramework.Text = "M�todo regThread_MODEM_DarumaFramework";
            // 
            // MN_regThread_TRUE
            // 
            this.MN_regThread_TRUE.Name = "MN_regThread_TRUE";
            this.MN_regThread_TRUE.Size = new System.Drawing.Size(106, 22);
            this.MN_regThread_TRUE.Text = "TRUE";
            this.MN_regThread_TRUE.Click += new System.EventHandler(this.MN_regThread_TRUE_Click);
            // 
            // MN_regThread_FALSE
            // 
            this.MN_regThread_FALSE.Name = "MN_regThread_FALSE";
            this.MN_regThread_FALSE.Size = new System.Drawing.Size(106, 22);
            this.MN_regThread_FALSE.Text = "FALSE";
            this.MN_regThread_FALSE.Click += new System.EventHandler(this.MN_regThread_FALSE_Click);
            // 
            // MN_regVelocidade_MODEM_DarumaFramework
            // 
            this.MN_regVelocidade_MODEM_DarumaFramework.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_regVelocidade_9600,
            this.MN_regVelocidade_38400,
            this.MN_regVelocidade_115200});
            this.MN_regVelocidade_MODEM_DarumaFramework.Name = "MN_regVelocidade_MODEM_DarumaFramework";
            this.MN_regVelocidade_MODEM_DarumaFramework.Size = new System.Drawing.Size(377, 22);
            this.MN_regVelocidade_MODEM_DarumaFramework.Text = "M�todo regVelocidade_MODEM_DarumaFramework";
            // 
            // MN_regVelocidade_9600
            // 
            this.MN_regVelocidade_9600.Name = "MN_regVelocidade_9600";
            this.MN_regVelocidade_9600.Size = new System.Drawing.Size(110, 22);
            this.MN_regVelocidade_9600.Text = "9600";
            this.MN_regVelocidade_9600.Click += new System.EventHandler(this.MN_regVelocidade_9600_Click);
            // 
            // MN_regVelocidade_38400
            // 
            this.MN_regVelocidade_38400.Name = "MN_regVelocidade_38400";
            this.MN_regVelocidade_38400.Size = new System.Drawing.Size(110, 22);
            this.MN_regVelocidade_38400.Text = "38400";
            this.MN_regVelocidade_38400.Click += new System.EventHandler(this.MN_regVelocidade_38400_Click);
            // 
            // MN_regVelocidade_115200
            // 
            this.MN_regVelocidade_115200.Name = "MN_regVelocidade_115200";
            this.MN_regVelocidade_115200.Size = new System.Drawing.Size(110, 22);
            this.MN_regVelocidade_115200.Text = "115200";
            this.MN_regVelocidade_115200.Click += new System.EventHandler(this.MN_regVelocidade_115200_Click);
            // 
            // m�todoRegCaptionToolStripMenuItem
            // 
            this.m�todoRegCaptionToolStripMenuItem.Name = "m�todoRegCaptionToolStripMenuItem";
            this.m�todoRegCaptionToolStripMenuItem.Size = new System.Drawing.Size(377, 22);
            this.m�todoRegCaptionToolStripMenuItem.Text = "M�todo regCaptionWinAPP_MODEM_DarumaFramework";
            this.m�todoRegCaptionToolStripMenuItem.Click += new System.EventHandler(this.m�todoRegCaptionToolStripMenuItem_Click);
            // 
            // m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem
            // 
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem.Name = "m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem";
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(377, 22);
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem.Text = "M�todo regBandejaInicio_MODEM_DarumaFramework";
            this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem.Click += new System.EventHandler(this.m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem_Click);
            // 
            // MN_Metodos_Funcao_MODEM
            // 
            this.MN_Metodos_Funcao_MODEM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_fnApagarSMS_MODEM_DarumaFramework,
            this.MN_fnInicializar_MODEM_DarumaFramework,
            this.MN_fnFinalizar_MODEM_DarumaFramework,
            this.MN_fnReseta_MODEM_DarumaFramework});
            this.MN_Metodos_Funcao_MODEM.Name = "MN_Metodos_Funcao_MODEM";
            this.MN_Metodos_Funcao_MODEM.Size = new System.Drawing.Size(203, 19);
            this.MN_Metodos_Funcao_MODEM.Text = "M�todos de &Fun��es para MODEM";
            this.MN_Metodos_Funcao_MODEM.Click += new System.EventHandler(this.MN_Metodos_Funcao_MODEM_Click);
            // 
            // MN_fnApagarSMS_MODEM_DarumaFramework
            // 
            this.MN_fnApagarSMS_MODEM_DarumaFramework.Name = "MN_fnApagarSMS_MODEM_DarumaFramework";
            this.MN_fnApagarSMS_MODEM_DarumaFramework.Size = new System.Drawing.Size(380, 22);
            this.MN_fnApagarSMS_MODEM_DarumaFramework.Text = "M�todo eApagarSMS_MODEM_DarumaFramework";
            this.MN_fnApagarSMS_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_fnApagarSMS_MODEM_DarumaFramework_Click);
            // 
            // MN_fnInicializar_MODEM_DarumaFramework
            // 
            this.MN_fnInicializar_MODEM_DarumaFramework.Name = "MN_fnInicializar_MODEM_DarumaFramework";
            this.MN_fnInicializar_MODEM_DarumaFramework.Size = new System.Drawing.Size(380, 22);
            this.MN_fnInicializar_MODEM_DarumaFramework.Text = "M�todo eInicializar_MODEM_DarumaFramework";
            this.MN_fnInicializar_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_fnInicializar_MODEM_DarumaFramework_Click);
            // 
            // MN_fnFinalizar_MODEM_DarumaFramework
            // 
            this.MN_fnFinalizar_MODEM_DarumaFramework.Name = "MN_fnFinalizar_MODEM_DarumaFramework";
            this.MN_fnFinalizar_MODEM_DarumaFramework.Size = new System.Drawing.Size(380, 22);
            this.MN_fnFinalizar_MODEM_DarumaFramework.Text = "M�todo rNivelSinalRecebido_MODEM_DarumaFramework";
            this.MN_fnFinalizar_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_fnFinalizar_MODEM_DarumaFramework_Click);
            // 
            // MN_fnReseta_MODEM_DarumaFramework
            // 
            this.MN_fnReseta_MODEM_DarumaFramework.Name = "MN_fnReseta_MODEM_DarumaFramework";
            this.MN_fnReseta_MODEM_DarumaFramework.Size = new System.Drawing.Size(380, 22);
            this.MN_fnReseta_MODEM_DarumaFramework.Text = "M�todo eTrocarBandeja_MODEM_DarumaFramework";
            this.MN_fnReseta_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_fnReseta_MODEM_DarumaFramework_Click);
            // 
            // MN_Metodos_Transmissao_MODEM
            // 
            this.MN_Metodos_Transmissao_MODEM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MN_tEnviarSMS_MODEM_DarumaFramework});
            this.MN_Metodos_Transmissao_MODEM.Name = "MN_Metodos_Transmissao_MODEM";
            this.MN_Metodos_Transmissao_MODEM.Size = new System.Drawing.Size(225, 19);
            this.MN_Metodos_Transmissao_MODEM.Text = "M�todos de &Transmiss�o para MODEM";
            // 
            // MN_tEnviarSMS_MODEM_DarumaFramework
            // 
            this.MN_tEnviarSMS_MODEM_DarumaFramework.Name = "MN_tEnviarSMS_MODEM_DarumaFramework";
            this.MN_tEnviarSMS_MODEM_DarumaFramework.Size = new System.Drawing.Size(334, 22);
            this.MN_tEnviarSMS_MODEM_DarumaFramework.Text = "M�todo tEnviarSMS_MODEM_DarumaFramework";
            this.MN_tEnviarSMS_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_tEnviarSMS_MODEM_DarumaFramework_Click);
            // 
            // MN_Metodos_Recepcao_MODEM
            // 
            this.MN_Metodos_Recepcao_MODEM.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1,
            this.MN_rLerSMS_MODEM_DarumaFramework,
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem,
            this.m�todoRRetornarImeToolStripMenuItem});
            this.MN_Metodos_Recepcao_MODEM.Name = "MN_Metodos_Recepcao_MODEM";
            this.MN_Metodos_Recepcao_MODEM.Size = new System.Drawing.Size(210, 19);
            this.MN_Metodos_Recepcao_MODEM.Text = "M�todos de &Recep��o para MODEM";
            // 
            // m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1
            // 
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1.Name = "m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1";
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1.Size = new System.Drawing.Size(380, 22);
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1.Text = "M�todo rReceberSMS_MODEM_DarumaFramework";
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1.Click += new System.EventHandler(this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1_Click);
            // 
            // MN_rLerSMS_MODEM_DarumaFramework
            // 
            this.MN_rLerSMS_MODEM_DarumaFramework.Name = "MN_rLerSMS_MODEM_DarumaFramework";
            this.MN_rLerSMS_MODEM_DarumaFramework.Size = new System.Drawing.Size(380, 22);
            this.MN_rLerSMS_MODEM_DarumaFramework.Text = "M�todo rListarSMS_MODEM_DarumaFramework";
            this.MN_rLerSMS_MODEM_DarumaFramework.Click += new System.EventHandler(this.MN_rLerSMS_MODEM_DarumaFramework_Click);
            // 
            // m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem
            // 
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem.Name = "m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem";
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(380, 22);
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem.Text = "M�todo rRetornarImei_MODEM_DarumaFramework";
            this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem.Click += new System.EventHandler(this.m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem_Click);
            // 
            // m�todoRRetornarImeToolStripMenuItem
            // 
            this.m�todoRRetornarImeToolStripMenuItem.Name = "m�todoRRetornarImeToolStripMenuItem";
            this.m�todoRRetornarImeToolStripMenuItem.Size = new System.Drawing.Size(380, 22);
            this.m�todoRRetornarImeToolStripMenuItem.Text = "M�todo rRetornarOperadora_MODEM_DarumaFramework";
            this.m�todoRRetornarImeToolStripMenuItem.Click += new System.EventHandler(this.m�todoRRetornarImeToolStripMenuItem_Click);
            // 
            // MN_FecharJanela
            // 
            this.MN_FecharJanela.Name = "MN_FecharJanela";
            this.MN_FecharJanela.Size = new System.Drawing.Size(89, 19);
            this.MN_FecharJanela.Text = "&Fechar Janela";
            this.MN_FecharJanela.Click += new System.EventHandler(this.MN_FecharJanela_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(738, 226);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 7;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // TB_NovasMensagens
            // 
            this.TB_NovasMensagens.Location = new System.Drawing.Point(595, 229);
            this.TB_NovasMensagens.Name = "TB_NovasMensagens";
            this.TB_NovasMensagens.ReadOnly = true;
            this.TB_NovasMensagens.Size = new System.Drawing.Size(137, 20);
            this.TB_NovasMensagens.TabIndex = 8;
            // 
            // LB_MensagemThread
            // 
            this.LB_MensagemThread.AutoSize = true;
            this.LB_MensagemThread.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_MensagemThread.Location = new System.Drawing.Point(470, 249);
            this.LB_MensagemThread.Name = "LB_MensagemThread";
            this.LB_MensagemThread.Size = new System.Drawing.Size(343, 13);
            this.LB_MensagemThread.TabIndex = 9;
            this.LB_MensagemThread.Text = "Thread, verificando se existe novas mensagens no Modem";
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(526, 229);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(63, 21);
            this.BT_Limpar.TabIndex = 10;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Limpar_Click);
            // 
            // conex�oCSDToolStripMenuItem
            // 
            this.conex�oCSDToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.servi�oCSDDarumaFrameworkToolStripMenuItem});
            this.conex�oCSDToolStripMenuItem.Name = "conex�oCSDToolStripMenuItem";
            this.conex�oCSDToolStripMenuItem.Size = new System.Drawing.Size(90, 19);
            this.conex�oCSDToolStripMenuItem.Text = "Conex�o &CSD";
            // 
            // servi�oCSDDarumaFrameworkToolStripMenuItem
            // 
            this.servi�oCSDDarumaFrameworkToolStripMenuItem.Name = "servi�oCSDDarumaFrameworkToolStripMenuItem";
            this.servi�oCSDDarumaFrameworkToolStripMenuItem.Size = new System.Drawing.Size(249, 22);
            this.servi�oCSDDarumaFrameworkToolStripMenuItem.Text = "Servi�o CSD - DarumaFramework";
            this.servi�oCSDDarumaFrameworkToolStripMenuItem.Click += new System.EventHandler(this.servi�oCSDDarumaFrameworkToolStripMenuItem_Click);
            // 
            // FR_MenuMODEM_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 357);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.LB_MensagemThread);
            this.Controls.Add(this.TB_NovasMensagens);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.PN_Modem);
            this.Controls.Add(this.lb_duvidas);
            this.Controls.Add(this.MN_Modem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.MN_Modem;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MenuMODEM_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Modem - Daruma Telecom";
            this.Load += new System.EventHandler(this.FR_MODEM_MIN200_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FR_MenuMODEM_Principal_KeyDown);
            this.PN_Modem.ResumeLayout(false);
            this.PN_Modem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).EndInit();
            this.MN_Modem.ResumeLayout(false);
            this.MN_Modem.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_DLL;
        private System.Windows.Forms.Panel PN_Modem;
        private System.Windows.Forms.Label LB_Modem;
        private System.Windows.Forms.PictureBox PB_DDC;
        private System.Windows.Forms.Label lb_duvidas;
        private System.Windows.Forms.MenuStrip MN_Modem;
        private System.Windows.Forms.ToolStripMenuItem MN_MRegistro;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.ToolStripMenuItem MN_FecharJanela;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Funcao_MODEM;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Transmissao_MODEM;
        private System.Windows.Forms.ToolStripMenuItem MN_Metodos_Recepcao_MODEM;
        private System.Windows.Forms.ToolStripMenuItem m�todoRegLerApagarMODEMDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MN_regLerApagar_TRUE;
        private System.Windows.Forms.ToolStripMenuItem MN_regLerApagar_FALSE;
        private System.Windows.Forms.ToolStripMenuItem MN_regPorta_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regThread_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regThread_TRUE;
        private System.Windows.Forms.ToolStripMenuItem MN_regThread_FALSE;
        private System.Windows.Forms.ToolStripMenuItem MN_regVelocidade_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_regVelocidade_9600;
        private System.Windows.Forms.ToolStripMenuItem MN_regVelocidade_38400;
        private System.Windows.Forms.ToolStripMenuItem MN_regVelocidade_115200;
        private System.Windows.Forms.ToolStripMenuItem MN_fnApagarSMS_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_fnInicializar_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_fnFinalizar_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_fnReseta_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_tEnviarSMS_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_rLerSMS_MODEM_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_MetodosDarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem MN_eDefinirProduto_Daruma;
        private System.Windows.Forms.TextBox TB_NovasMensagens;
        private System.Windows.Forms.Label LB_MensagemThread;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.ToolStripMenuItem MN_regRetornaValorChave_DarumaFramework;
        private System.Windows.Forms.ToolStripMenuItem m�todoRegTempoAlertarMODEMDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem m�todoRegCaptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem m�todoRegBandejaInicioMODEMDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem m�todoRReceberSMSMODEMDarumaFrameworkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem m�todoRRetornarImeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conex�oCSDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem servi�oCSDDarumaFrameworkToolStripMenuItem;
    }
}