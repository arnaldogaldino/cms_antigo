using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_DUAL_menuExemplo4_comForumulario : Form
    {
        public FR_DUAL_menuExemplo4_comForumulario()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {

            this.Close();

        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Nome_Empresa;
            string Str_Endereco_Empresa;
            string Str_Fone_Empresa;
            string Str_Numero_Pedido;
            string Str_Tema_Mensagem;
            string Str_Titulo_Mensagem;
            string Str_Valor_Mensagem;
            string Str_Forma_Cobranca;
            string Str_Cliente;
            string Str_Fone_Res;
            string Str_Fone_Celular;
            string Str_Fone_Com;
            string Str_Mensagem_Promo;
            string Str_Hora;

            Str_Nome_Empresa = TB_Nome_Empresa.Text;
            Str_Endereco_Empresa = TB_Endereco_Empresa.Text;
            Str_Fone_Empresa = TB_Fone_Empresa.Text;
            Str_Numero_Pedido = TB_Numero_Pedido.Text;
            Str_Tema_Mensagem = TB_Tema_Mensagem.Text;
            Str_Titulo_Mensagem = TB_Titulo_Mensagem.Text;
            Str_Valor_Mensagem = TB_Valor_Mensagem.Text;
            Str_Forma_Cobranca = TB_Forma_Cobranca.Text;
            Str_Cliente = TB_Cliente.Text;
            Str_Fone_Res = TB_Fone_Res.Text;
            Str_Fone_Celular = TB_Celular.Text;
            Str_Fone_Com = TB_Fone_Com.Text;
            Str_Mensagem_Promo = TB_Mensagem_Promo.Text;
            Str_Hora = TB_Hora.Text;

            //IMPRIMINDO A PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<i><e><sp>2</sp>" + TB_Nome_Empresa.Text + "</e></i>", 0);
            //IMPRIMINDO A SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><tc>-</tc></ce>", 0);
            //IMPRIMINDO A TERCEIRA LINHA
            Declaracoes.iRetorno =Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Endereco_Empresa.Text + "<i>" + TB_Endereco_Empresa.Text + "</i>", 0);
            //IMPRIMINDO A QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Fone_Empresa.Text + "<i>" + TB_Fone_Empresa.Text + "</i>", 0);
            //IMPRIMINDO A QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Pedido_N.Text + "<i>" + TB_Numero_Pedido.Text + "</i>", 0);
            //IMPRIMINDO A SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Data.Text + "<i><dt></dt></i>", 0);
            //IMPRIMINDO A SETIMA LINHA
            Declaracoes.iRetorno=Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><tc>-</tc></ce>", 0);
            //IMPRIMINDO A OITAVA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Tema_Mensagem.Text + "<i>" + TB_Tema_Mensagem.Text + "</i>", 0);
            //IMPRIMINDO A NONA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Titulo_Mensagem.Text + "<i>" + TB_Titulo_Mensagem.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Valor_Mensagem.Text + "<i>" + TB_Valor_Mensagem.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA PRIMEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Forma_Cobranca.Text + "<i>" + TB_Forma_Cobranca.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA SEGUNDA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Cliente.Text + "<i>" + TB_Cliente.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA TERCEIRA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Fone_Res.Text + "<i>" + TB_Fone_Res.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA QUARTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Celular.Text + "<i>" + TB_Celular.Text + "</i>", 0);
            //IMPRIMINDO A DECIMA QUINTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>4</sp>" + LB_Fone_Com.Text + "<i>" + TB_Fone_Com.Text + "</i><sl>1</sl>", 0);
            //IMPRIMINDO A DECIMA SEXTA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><b>" + TB_Mensagem_Promo.Text + "</b></ce><sl>2</sl>", 0);
            //IMPRIMINDO A DECIMA OITAVA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<sp>35</sp>" + LB_Hora.Text + "<hr></hr>", 0);
            //IMPRIMINDO A DECIMA NONA LINHA
            Declaracoes.iRetorno = Declaracoes.iImprimirTexto_DUAL_DarumaFramework("<ce><tc>-</tc></ce><sl>8</sl>", 0);

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Impressao Concluida!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Erro ao Imprimir seu Formulario!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void BT_Limpar_Click(object sender, EventArgs e)
        {
            TB_Nome_Empresa.Text = string.Empty;
            TB_Endereco_Empresa.Text = string.Empty;
            TB_Fone_Empresa.Text = string.Empty;
            TB_Data_Pedido.Text = string.Empty;
            TB_Numero_Pedido.Text = string.Empty;
            TB_Tema_Mensagem.Text = string.Empty;
            TB_Titulo_Mensagem.Text = string.Empty;
            TB_Valor_Mensagem.Text = string.Empty;
            TB_Forma_Cobranca.Text = string.Empty;
            TB_Cliente.Text = string.Empty;
            TB_Fone_Res.Text = string.Empty;
            TB_Celular.Text = string.Empty;
            TB_Fone_Com.Text = string.Empty;
            TB_Mensagem_Promo.Text = string.Empty;
            TB_Hora.Text = string.Empty;
        }
    }
}