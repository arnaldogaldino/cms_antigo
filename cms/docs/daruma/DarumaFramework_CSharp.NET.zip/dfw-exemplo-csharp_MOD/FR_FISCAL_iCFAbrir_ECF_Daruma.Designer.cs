﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFAbrir_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.TB_CPF_CNPJ = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_Nome = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Endereço = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(284, 143);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 0;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(365, 143);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 1;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // TB_CPF_CNPJ
            // 
            this.TB_CPF_CNPJ.Location = new System.Drawing.Point(93, 65);
            this.TB_CPF_CNPJ.Name = "TB_CPF_CNPJ";
            this.TB_CPF_CNPJ.Size = new System.Drawing.Size(347, 20);
            this.TB_CPF_CNPJ.TabIndex = 2;
            this.TB_CPF_CNPJ.Text = "123.123.123-99";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "CPF:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome:";
            // 
            // TB_Nome
            // 
            this.TB_Nome.Location = new System.Drawing.Point(93, 91);
            this.TB_Nome.Name = "TB_Nome";
            this.TB_Nome.Size = new System.Drawing.Size(347, 20);
            this.TB_Nome.TabIndex = 5;
            this.TB_Nome.Text = "Daruma Developer Community";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Endereço:";
            // 
            // TB_Endereço
            // 
            this.TB_Endereço.Location = new System.Drawing.Point(93, 117);
            this.TB_Endereço.Name = "TB_Endereço";
            this.TB_Endereço.Size = new System.Drawing.Size(347, 20);
            this.TB_Endereço.TabIndex = 7;
            this.TB_Endereço.Text = "Av. Shishima Hifumi, 2911. 4 andar - Sala. 406  - São José dos Campos - São Paulo" +
                "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Informe os dados do consumidor:";
            // 
            // FR_FISCAL_iCFAbrir_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(454, 183);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_Endereço);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TB_Nome);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_CPF_CNPJ);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_iCFAbrir_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCFAbrir_ECF_Daruma (Identificação Consumidor)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.TextBox TB_CPF_CNPJ;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_Nome;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Endereço;
        private System.Windows.Forms.Label label4;
    }
}