namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_tEnviarSMS_MODEM_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_NumeroTelefone = new System.Windows.Forms.Label();
            this.TB_NumeroTelefone = new System.Windows.Forms.TextBox();
            this.LB_Mensagem = new System.Windows.Forms.Label();
            this.TB_Mensagem = new System.Windows.Forms.TextBox();
            this.LB_RespostaModem = new System.Windows.Forms.Label();
            this.TB_RespostaModem = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LB_NumeroTelefone
            // 
            this.LB_NumeroTelefone.AutoSize = true;
            this.LB_NumeroTelefone.Location = new System.Drawing.Point(10, 14);
            this.LB_NumeroTelefone.Name = "LB_NumeroTelefone";
            this.LB_NumeroTelefone.Size = new System.Drawing.Size(107, 13);
            this.LB_NumeroTelefone.TabIndex = 0;
            this.LB_NumeroTelefone.Text = "Numero do Telefone:";
            // 
            // TB_NumeroTelefone
            // 
            this.TB_NumeroTelefone.Location = new System.Drawing.Point(13, 30);
            this.TB_NumeroTelefone.Name = "TB_NumeroTelefone";
            this.TB_NumeroTelefone.Size = new System.Drawing.Size(146, 20);
            this.TB_NumeroTelefone.TabIndex = 1;
            this.TB_NumeroTelefone.Text = "0xxTelefone";
            // 
            // LB_Mensagem
            // 
            this.LB_Mensagem.AutoSize = true;
            this.LB_Mensagem.Location = new System.Drawing.Point(13, 68);
            this.LB_Mensagem.Name = "LB_Mensagem";
            this.LB_Mensagem.Size = new System.Drawing.Size(129, 13);
            this.LB_Mensagem.TabIndex = 2;
            this.LB_Mensagem.Text = "Mensagem a ser enviada:";
            // 
            // TB_Mensagem
            // 
            this.TB_Mensagem.Location = new System.Drawing.Point(13, 85);
            this.TB_Mensagem.MaxLength = 160;
            this.TB_Mensagem.Multiline = true;
            this.TB_Mensagem.Name = "TB_Mensagem";
            this.TB_Mensagem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_Mensagem.Size = new System.Drawing.Size(146, 105);
            this.TB_Mensagem.TabIndex = 3;
            this.TB_Mensagem.Text = "Teste Daruma MIN-200 - \r\nCSharp!\r\nAplicativo Exclusivo Daruma\r\n\r\nAcesse: \r\nwww.de" +
                "senvolvedoresdaruma.\r\ncom.br";
            // 
            // LB_RespostaModem
            // 
            this.LB_RespostaModem.AutoSize = true;
            this.LB_RespostaModem.Location = new System.Drawing.Point(13, 203);
            this.LB_RespostaModem.Name = "LB_RespostaModem";
            this.LB_RespostaModem.Size = new System.Drawing.Size(108, 13);
            this.LB_RespostaModem.TabIndex = 4;
            this.LB_RespostaModem.Text = "Resposta do Modem:";
            // 
            // TB_RespostaModem
            // 
            this.TB_RespostaModem.Location = new System.Drawing.Point(13, 219);
            this.TB_RespostaModem.Multiline = true;
            this.TB_RespostaModem.Name = "TB_RespostaModem";
            this.TB_RespostaModem.ReadOnly = true;
            this.TB_RespostaModem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_RespostaModem.Size = new System.Drawing.Size(146, 21);
            this.TB_RespostaModem.TabIndex = 5;
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(165, 167);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 6;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(165, 219);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 7;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(165, 138);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(75, 23);
            this.BT_Limpar.TabIndex = 8;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Apagar_Click);
            // 
            // FR_MODEM_tEnviarSMS_MODEM_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 249);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_RespostaModem);
            this.Controls.Add(this.LB_RespostaModem);
            this.Controls.Add(this.TB_Mensagem);
            this.Controls.Add(this.LB_Mensagem);
            this.Controls.Add(this.TB_NumeroTelefone);
            this.Controls.Add(this.LB_NumeroTelefone);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MODEM_tEnviarSMS_MODEM_DarumaFramework";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "M�todo Para Envio de SMS";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_NumeroTelefone;
        private System.Windows.Forms.TextBox TB_NumeroTelefone;
        private System.Windows.Forms.Label LB_Mensagem;
        private System.Windows.Forms.TextBox TB_Mensagem;
        private System.Windows.Forms.Label LB_RespostaModem;
        private System.Windows.Forms.TextBox TB_RespostaModem;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Limpar;
    }
}