﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_rCalcularMD5_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BT_LocalArquivos = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_MD5Ascii = new System.Windows.Forms.TextBox();
            this.TB_MD5Hex = new System.Windows.Forms.TextBox();
            this.TB_Caminho = new System.Windows.Forms.TextBox();
            this.BT_Calcular = new System.Windows.Forms.Button();
            this.BT_Voltar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BT_LocalArquivos);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TB_MD5Ascii);
            this.groupBox1.Controls.Add(this.TB_MD5Hex);
            this.groupBox1.Controls.Add(this.TB_Caminho);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(428, 250);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Calcular MD5";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // BT_LocalArquivos
            // 
            this.BT_LocalArquivos.Location = new System.Drawing.Point(383, 31);
            this.BT_LocalArquivos.Name = "BT_LocalArquivos";
            this.BT_LocalArquivos.Size = new System.Drawing.Size(28, 23);
            this.BT_LocalArquivos.TabIndex = 12;
            this.BT_LocalArquivos.Text = "...";
            this.BT_LocalArquivos.UseVisualStyleBackColor = true;
            this.BT_LocalArquivos.Click += new System.EventHandler(this.BT_LocalArquivos_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Retorna MD5 Gerado Ascii:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Retorna MD5 Gerado Hexadecimal:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Caminho do arquivo que será gerado o MD5:";
            // 
            // TB_MD5Ascii
            // 
            this.TB_MD5Ascii.Location = new System.Drawing.Point(9, 176);
            this.TB_MD5Ascii.Multiline = true;
            this.TB_MD5Ascii.Name = "TB_MD5Ascii";
            this.TB_MD5Ascii.Size = new System.Drawing.Size(413, 61);
            this.TB_MD5Ascii.TabIndex = 8;
            // 
            // TB_MD5Hex
            // 
            this.TB_MD5Hex.Location = new System.Drawing.Point(9, 81);
            this.TB_MD5Hex.Multiline = true;
            this.TB_MD5Hex.Name = "TB_MD5Hex";
            this.TB_MD5Hex.Size = new System.Drawing.Size(413, 67);
            this.TB_MD5Hex.TabIndex = 7;
            // 
            // TB_Caminho
            // 
            this.TB_Caminho.Location = new System.Drawing.Point(9, 33);
            this.TB_Caminho.Name = "TB_Caminho";
            this.TB_Caminho.Size = new System.Drawing.Size(368, 20);
            this.TB_Caminho.TabIndex = 6;
            // 
            // BT_Calcular
            // 
            this.BT_Calcular.Location = new System.Drawing.Point(273, 268);
            this.BT_Calcular.Name = "BT_Calcular";
            this.BT_Calcular.Size = new System.Drawing.Size(75, 23);
            this.BT_Calcular.TabIndex = 13;
            this.BT_Calcular.Text = "Calcular";
            this.BT_Calcular.UseVisualStyleBackColor = true;
            this.BT_Calcular.Click += new System.EventHandler(this.BT_Calcular_Click);
            // 
            // BT_Voltar
            // 
            this.BT_Voltar.Location = new System.Drawing.Point(359, 268);
            this.BT_Voltar.Name = "BT_Voltar";
            this.BT_Voltar.Size = new System.Drawing.Size(75, 23);
            this.BT_Voltar.TabIndex = 14;
            this.BT_Voltar.Text = "Voltar";
            this.BT_Voltar.UseVisualStyleBackColor = true;
            this.BT_Voltar.Click += new System.EventHandler(this.BT_Voltar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FR_FISCAL_rCalcularMD5_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(464, 302);
            this.Controls.Add(this.BT_Calcular);
            this.Controls.Add(this.BT_Voltar);
            this.Controls.Add(this.groupBox1);
            this.Name = "FR_FISCAL_rCalcularMD5_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "rCalcularMD5_ECF_Daruma";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_MD5Ascii;
        private System.Windows.Forms.TextBox TB_MD5Hex;
        private System.Windows.Forms.TextBox TB_Caminho;
        private System.Windows.Forms.Button BT_LocalArquivos;
        private System.Windows.Forms.Button BT_Calcular;
        private System.Windows.Forms.Button BT_Voltar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;

    }
}