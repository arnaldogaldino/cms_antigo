namespace DarumaFramework_CSharp
{
    partial class FR_DUAL_menuExemplo4_comForumulario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LB_NomeEmpresa = new System.Windows.Forms.Label();
            this.TB_Nome_Empresa = new System.Windows.Forms.TextBox();
            this.LB_Endereco_Empresa = new System.Windows.Forms.Label();
            this.TB_Endereco_Empresa = new System.Windows.Forms.TextBox();
            this.LB_Fone_Empresa = new System.Windows.Forms.Label();
            this.TB_Fone_Empresa = new System.Windows.Forms.TextBox();
            this.LB_Pedido_N = new System.Windows.Forms.Label();
            this.TB_Numero_Pedido = new System.Windows.Forms.TextBox();
            this.LB_Data = new System.Windows.Forms.Label();
            this.TB_Data_Pedido = new System.Windows.Forms.TextBox();
            this.LB_Tema_Mensagem = new System.Windows.Forms.Label();
            this.TB_Tema_Mensagem = new System.Windows.Forms.TextBox();
            this.LB_Titulo_Mensagem = new System.Windows.Forms.Label();
            this.TB_Titulo_Mensagem = new System.Windows.Forms.TextBox();
            this.LB_Valor_Mensagem = new System.Windows.Forms.Label();
            this.TB_Valor_Mensagem = new System.Windows.Forms.TextBox();
            this.LB_Forma_Cobranca = new System.Windows.Forms.Label();
            this.TB_Forma_Cobranca = new System.Windows.Forms.TextBox();
            this.LB_Cliente = new System.Windows.Forms.Label();
            this.TB_Cliente = new System.Windows.Forms.TextBox();
            this.LB_Fone_Res = new System.Windows.Forms.Label();
            this.TB_Fone_Res = new System.Windows.Forms.TextBox();
            this.LB_Celular = new System.Windows.Forms.Label();
            this.TB_Celular = new System.Windows.Forms.TextBox();
            this.LB_Fone_Com = new System.Windows.Forms.Label();
            this.TB_Fone_Com = new System.Windows.Forms.TextBox();
            this.LB_MensagemPromocional = new System.Windows.Forms.Label();
            this.TB_Mensagem_Promo = new System.Windows.Forms.TextBox();
            this.LB_Hora = new System.Windows.Forms.Label();
            this.TB_Hora = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.TM_Hora = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LB_NomeEmpresa
            // 
            this.LB_NomeEmpresa.AutoSize = true;
            this.LB_NomeEmpresa.Location = new System.Drawing.Point(10, 15);
            this.LB_NomeEmpresa.Name = "LB_NomeEmpresa";
            this.LB_NomeEmpresa.Size = new System.Drawing.Size(97, 13);
            this.LB_NomeEmpresa.TabIndex = 0;
            this.LB_NomeEmpresa.Text = "Nome da Empresa:";
            // 
            // TB_Nome_Empresa
            // 
            this.TB_Nome_Empresa.Location = new System.Drawing.Point(113, 12);
            this.TB_Nome_Empresa.Name = "TB_Nome_Empresa";
            this.TB_Nome_Empresa.Size = new System.Drawing.Size(367, 20);
            this.TB_Nome_Empresa.TabIndex = 1;
            this.TB_Nome_Empresa.Text = "Daruma Devolper Community";
            // 
            // LB_Endereco_Empresa
            // 
            this.LB_Endereco_Empresa.AutoSize = true;
            this.LB_Endereco_Empresa.Location = new System.Drawing.Point(10, 40);
            this.LB_Endereco_Empresa.Name = "LB_Endereco_Empresa";
            this.LB_Endereco_Empresa.Size = new System.Drawing.Size(56, 13);
            this.LB_Endereco_Empresa.TabIndex = 2;
            this.LB_Endereco_Empresa.Text = "Endere�o:";
            // 
            // TB_Endereco_Empresa
            // 
            this.TB_Endereco_Empresa.Location = new System.Drawing.Point(113, 40);
            this.TB_Endereco_Empresa.Name = "TB_Endereco_Empresa";
            this.TB_Endereco_Empresa.Size = new System.Drawing.Size(367, 20);
            this.TB_Endereco_Empresa.TabIndex = 3;
            this.TB_Endereco_Empresa.Text = "Avenida Paulista, 1776 - 16 Andar";
            // 
            // LB_Fone_Empresa
            // 
            this.LB_Fone_Empresa.AutoSize = true;
            this.LB_Fone_Empresa.Location = new System.Drawing.Point(10, 73);
            this.LB_Fone_Empresa.Name = "LB_Fone_Empresa";
            this.LB_Fone_Empresa.Size = new System.Drawing.Size(39, 13);
            this.LB_Fone_Empresa.TabIndex = 4;
            this.LB_Fone_Empresa.Text = "Fones:";
            // 
            // TB_Fone_Empresa
            // 
            this.TB_Fone_Empresa.Location = new System.Drawing.Point(57, 70);
            this.TB_Fone_Empresa.Name = "TB_Fone_Empresa";
            this.TB_Fone_Empresa.Size = new System.Drawing.Size(91, 20);
            this.TB_Fone_Empresa.TabIndex = 5;
            this.TB_Fone_Empresa.Text = "11-31464900";
            // 
            // LB_Pedido_N
            // 
            this.LB_Pedido_N.AutoSize = true;
            this.LB_Pedido_N.Location = new System.Drawing.Point(159, 72);
            this.LB_Pedido_N.Name = "LB_Pedido_N";
            this.LB_Pedido_N.Size = new System.Drawing.Size(58, 13);
            this.LB_Pedido_N.TabIndex = 6;
            this.LB_Pedido_N.Text = "Pedido N�:";
            // 
            // TB_Numero_Pedido
            // 
            this.TB_Numero_Pedido.Location = new System.Drawing.Point(223, 70);
            this.TB_Numero_Pedido.Name = "TB_Numero_Pedido";
            this.TB_Numero_Pedido.Size = new System.Drawing.Size(81, 20);
            this.TB_Numero_Pedido.TabIndex = 7;
            this.TB_Numero_Pedido.Text = "0541";
            // 
            // LB_Data
            // 
            this.LB_Data.AutoSize = true;
            this.LB_Data.Location = new System.Drawing.Point(319, 72);
            this.LB_Data.Name = "LB_Data";
            this.LB_Data.Size = new System.Drawing.Size(33, 13);
            this.LB_Data.TabIndex = 8;
            this.LB_Data.Text = "Data:";
            // 
            // TB_Data_Pedido
            // 
            this.TB_Data_Pedido.Location = new System.Drawing.Point(358, 69);
            this.TB_Data_Pedido.Name = "TB_Data_Pedido";
            this.TB_Data_Pedido.Size = new System.Drawing.Size(106, 20);
            this.TB_Data_Pedido.TabIndex = 9;
            this.TB_Data_Pedido.Text = "02-03-2009";
            // 
            // LB_Tema_Mensagem
            // 
            this.LB_Tema_Mensagem.AutoSize = true;
            this.LB_Tema_Mensagem.Location = new System.Drawing.Point(10, 107);
            this.LB_Tema_Mensagem.Name = "LB_Tema_Mensagem";
            this.LB_Tema_Mensagem.Size = new System.Drawing.Size(107, 13);
            this.LB_Tema_Mensagem.TabIndex = 10;
            this.LB_Tema_Mensagem.Text = "Tema da Mensagem:";
            // 
            // TB_Tema_Mensagem
            // 
            this.TB_Tema_Mensagem.Location = new System.Drawing.Point(125, 104);
            this.TB_Tema_Mensagem.Name = "TB_Tema_Mensagem";
            this.TB_Tema_Mensagem.Size = new System.Drawing.Size(121, 20);
            this.TB_Tema_Mensagem.TabIndex = 11;
            this.TB_Tema_Mensagem.Text = "Desenvolvimento";
            // 
            // LB_Titulo_Mensagem
            // 
            this.LB_Titulo_Mensagem.AutoSize = true;
            this.LB_Titulo_Mensagem.Location = new System.Drawing.Point(259, 106);
            this.LB_Titulo_Mensagem.Name = "LB_Titulo_Mensagem";
            this.LB_Titulo_Mensagem.Size = new System.Drawing.Size(106, 13);
            this.LB_Titulo_Mensagem.TabIndex = 12;
            this.LB_Titulo_Mensagem.Text = "Titulo da Mensagem:";
            // 
            // TB_Titulo_Mensagem
            // 
            this.TB_Titulo_Mensagem.Location = new System.Drawing.Point(374, 104);
            this.TB_Titulo_Mensagem.Name = "TB_Titulo_Mensagem";
            this.TB_Titulo_Mensagem.Size = new System.Drawing.Size(105, 20);
            this.TB_Titulo_Mensagem.TabIndex = 13;
            this.TB_Titulo_Mensagem.Text = "Exemplo C#!";
            // 
            // LB_Valor_Mensagem
            // 
            this.LB_Valor_Mensagem.AutoSize = true;
            this.LB_Valor_Mensagem.Location = new System.Drawing.Point(10, 136);
            this.LB_Valor_Mensagem.Name = "LB_Valor_Mensagem";
            this.LB_Valor_Mensagem.Size = new System.Drawing.Size(121, 13);
            this.LB_Valor_Mensagem.TabIndex = 14;
            this.LB_Valor_Mensagem.Text = "Valor da Mensagem R$:";
            // 
            // TB_Valor_Mensagem
            // 
            this.TB_Valor_Mensagem.Location = new System.Drawing.Point(139, 133);
            this.TB_Valor_Mensagem.Name = "TB_Valor_Mensagem";
            this.TB_Valor_Mensagem.Size = new System.Drawing.Size(83, 20);
            this.TB_Valor_Mensagem.TabIndex = 15;
            this.TB_Valor_Mensagem.Text = "5,00";
            // 
            // LB_Forma_Cobranca
            // 
            this.LB_Forma_Cobranca.AutoSize = true;
            this.LB_Forma_Cobranca.Location = new System.Drawing.Point(238, 136);
            this.LB_Forma_Cobranca.Name = "LB_Forma_Cobranca";
            this.LB_Forma_Cobranca.Size = new System.Drawing.Size(103, 13);
            this.LB_Forma_Cobranca.TabIndex = 16;
            this.LB_Forma_Cobranca.Text = "Forma de Cobran�a:";
            // 
            // TB_Forma_Cobranca
            // 
            this.TB_Forma_Cobranca.Location = new System.Drawing.Point(347, 134);
            this.TB_Forma_Cobranca.Name = "TB_Forma_Cobranca";
            this.TB_Forma_Cobranca.Size = new System.Drawing.Size(110, 20);
            this.TB_Forma_Cobranca.TabIndex = 17;
            this.TB_Forma_Cobranca.Text = "Boleto";
            // 
            // LB_Cliente
            // 
            this.LB_Cliente.AutoSize = true;
            this.LB_Cliente.Location = new System.Drawing.Point(10, 175);
            this.LB_Cliente.Name = "LB_Cliente";
            this.LB_Cliente.Size = new System.Drawing.Size(42, 13);
            this.LB_Cliente.TabIndex = 18;
            this.LB_Cliente.Text = "Cliente:";
            // 
            // TB_Cliente
            // 
            this.TB_Cliente.Location = new System.Drawing.Point(61, 173);
            this.TB_Cliente.Name = "TB_Cliente";
            this.TB_Cliente.Size = new System.Drawing.Size(419, 20);
            this.TB_Cliente.TabIndex = 19;
            this.TB_Cliente.Text = "Justino Justo Sabio";
            // 
            // LB_Fone_Res
            // 
            this.LB_Fone_Res.AutoSize = true;
            this.LB_Fone_Res.Location = new System.Drawing.Point(10, 215);
            this.LB_Fone_Res.Name = "LB_Fone_Res";
            this.LB_Fone_Res.Size = new System.Drawing.Size(56, 13);
            this.LB_Fone_Res.TabIndex = 20;
            this.LB_Fone_Res.Text = "Fone Res:";
            // 
            // TB_Fone_Res
            // 
            this.TB_Fone_Res.Location = new System.Drawing.Point(72, 212);
            this.TB_Fone_Res.Name = "TB_Fone_Res";
            this.TB_Fone_Res.Size = new System.Drawing.Size(98, 20);
            this.TB_Fone_Res.TabIndex = 21;
            this.TB_Fone_Res.Text = "11-31464900";
            // 
            // LB_Celular
            // 
            this.LB_Celular.AutoSize = true;
            this.LB_Celular.Location = new System.Drawing.Point(179, 216);
            this.LB_Celular.Name = "LB_Celular";
            this.LB_Celular.Size = new System.Drawing.Size(42, 13);
            this.LB_Celular.TabIndex = 22;
            this.LB_Celular.Text = "Celular:";
            // 
            // TB_Celular
            // 
            this.TB_Celular.Location = new System.Drawing.Point(227, 212);
            this.TB_Celular.Name = "TB_Celular";
            this.TB_Celular.Size = new System.Drawing.Size(91, 20);
            this.TB_Celular.TabIndex = 23;
            this.TB_Celular.Text = "9923-9281";
            // 
            // LB_Fone_Com
            // 
            this.LB_Fone_Com.AutoSize = true;
            this.LB_Fone_Com.Location = new System.Drawing.Point(330, 216);
            this.LB_Fone_Com.Name = "LB_Fone_Com";
            this.LB_Fone_Com.Size = new System.Drawing.Size(58, 13);
            this.LB_Fone_Com.TabIndex = 24;
            this.LB_Fone_Com.Text = "Fone Com:";
            // 
            // TB_Fone_Com
            // 
            this.TB_Fone_Com.Location = new System.Drawing.Point(394, 212);
            this.TB_Fone_Com.Name = "TB_Fone_Com";
            this.TB_Fone_Com.Size = new System.Drawing.Size(86, 20);
            this.TB_Fone_Com.TabIndex = 25;
            this.TB_Fone_Com.Text = "11-31464900";
            // 
            // LB_MensagemPromocional
            // 
            this.LB_MensagemPromocional.AutoSize = true;
            this.LB_MensagemPromocional.Location = new System.Drawing.Point(10, 253);
            this.LB_MensagemPromocional.Name = "LB_MensagemPromocional";
            this.LB_MensagemPromocional.Size = new System.Drawing.Size(123, 13);
            this.LB_MensagemPromocional.TabIndex = 26;
            this.LB_MensagemPromocional.Text = "Mensagem Promocional:";
            // 
            // TB_Mensagem_Promo
            // 
            this.TB_Mensagem_Promo.Location = new System.Drawing.Point(139, 250);
            this.TB_Mensagem_Promo.Name = "TB_Mensagem_Promo";
            this.TB_Mensagem_Promo.Size = new System.Drawing.Size(341, 20);
            this.TB_Mensagem_Promo.TabIndex = 27;
            this.TB_Mensagem_Promo.Text = "Agradecemos a Prefer�ncia!!! (www.desenvolvedoresdaruma.com.br)";
            // 
            // LB_Hora
            // 
            this.LB_Hora.AutoSize = true;
            this.LB_Hora.Location = new System.Drawing.Point(10, 286);
            this.LB_Hora.Name = "LB_Hora";
            this.LB_Hora.Size = new System.Drawing.Size(33, 13);
            this.LB_Hora.TabIndex = 28;
            this.LB_Hora.Text = "Hora:";
            // 
            // TB_Hora
            // 
            this.TB_Hora.Location = new System.Drawing.Point(49, 283);
            this.TB_Hora.Name = "TB_Hora";
            this.TB_Hora.Size = new System.Drawing.Size(58, 20);
            this.TB_Hora.TabIndex = 29;
            this.TB_Hora.Text = "09:10";
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(377, 286);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(87, 23);
            this.BT_Enviar.TabIndex = 30;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(377, 315);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(87, 23);
            this.BT_Fechar.TabIndex = 31;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(269, 316);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(96, 22);
            this.BT_Limpar.TabIndex = 32;
            this.BT_Limpar.Text = "Limpar Campos";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Limpar_Click);
            // 
            // FR_DUAL_menuExemplo4_comForumulario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 349);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_Hora);
            this.Controls.Add(this.LB_Hora);
            this.Controls.Add(this.TB_Mensagem_Promo);
            this.Controls.Add(this.LB_MensagemPromocional);
            this.Controls.Add(this.TB_Fone_Com);
            this.Controls.Add(this.LB_Fone_Com);
            this.Controls.Add(this.TB_Celular);
            this.Controls.Add(this.LB_Celular);
            this.Controls.Add(this.TB_Fone_Res);
            this.Controls.Add(this.LB_Fone_Res);
            this.Controls.Add(this.TB_Cliente);
            this.Controls.Add(this.LB_Cliente);
            this.Controls.Add(this.TB_Forma_Cobranca);
            this.Controls.Add(this.LB_Forma_Cobranca);
            this.Controls.Add(this.TB_Valor_Mensagem);
            this.Controls.Add(this.LB_Valor_Mensagem);
            this.Controls.Add(this.TB_Titulo_Mensagem);
            this.Controls.Add(this.LB_Titulo_Mensagem);
            this.Controls.Add(this.TB_Tema_Mensagem);
            this.Controls.Add(this.LB_Tema_Mensagem);
            this.Controls.Add(this.TB_Data_Pedido);
            this.Controls.Add(this.LB_Data);
            this.Controls.Add(this.TB_Numero_Pedido);
            this.Controls.Add(this.LB_Pedido_N);
            this.Controls.Add(this.TB_Fone_Empresa);
            this.Controls.Add(this.LB_Fone_Empresa);
            this.Controls.Add(this.TB_Endereco_Empresa);
            this.Controls.Add(this.LB_Endereco_Empresa);
            this.Controls.Add(this.TB_Nome_Empresa);
            this.Controls.Add(this.LB_NomeEmpresa);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DUAL_menuExemplo4_comForumulario";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemplo de Impress�o utilizando Formulario (Exemplo4)          Daruma DDC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_NomeEmpresa;
        private System.Windows.Forms.TextBox TB_Nome_Empresa;
        private System.Windows.Forms.Label LB_Endereco_Empresa;
        private System.Windows.Forms.TextBox TB_Endereco_Empresa;
        private System.Windows.Forms.Label LB_Fone_Empresa;
        private System.Windows.Forms.TextBox TB_Fone_Empresa;
        private System.Windows.Forms.Label LB_Pedido_N;
        private System.Windows.Forms.TextBox TB_Numero_Pedido;
        private System.Windows.Forms.Label LB_Data;
        private System.Windows.Forms.TextBox TB_Data_Pedido;
        private System.Windows.Forms.Label LB_Tema_Mensagem;
        private System.Windows.Forms.TextBox TB_Tema_Mensagem;
        private System.Windows.Forms.Label LB_Titulo_Mensagem;
        private System.Windows.Forms.TextBox TB_Titulo_Mensagem;
        private System.Windows.Forms.Label LB_Valor_Mensagem;
        private System.Windows.Forms.TextBox TB_Valor_Mensagem;
        private System.Windows.Forms.Label LB_Forma_Cobranca;
        private System.Windows.Forms.TextBox TB_Forma_Cobranca;
        private System.Windows.Forms.Label LB_Cliente;
        private System.Windows.Forms.TextBox TB_Cliente;
        private System.Windows.Forms.Label LB_Fone_Res;
        private System.Windows.Forms.TextBox TB_Fone_Res;
        private System.Windows.Forms.Label LB_Celular;
        private System.Windows.Forms.TextBox TB_Celular;
        private System.Windows.Forms.Label LB_Fone_Com;
        private System.Windows.Forms.TextBox TB_Fone_Com;
        private System.Windows.Forms.Label LB_MensagemPromocional;
        private System.Windows.Forms.TextBox TB_Mensagem_Promo;
        private System.Windows.Forms.Label LB_Hora;
        private System.Windows.Forms.TextBox TB_Hora;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.Timer TM_Hora;
    }
}