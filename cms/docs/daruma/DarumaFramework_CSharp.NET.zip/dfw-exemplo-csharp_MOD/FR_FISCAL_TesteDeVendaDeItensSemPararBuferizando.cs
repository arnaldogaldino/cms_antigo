﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_TesteDeVendaDeItensSemPararBuferizando : Form
    {
        public FR_FISCAL_TesteDeVendaDeItensSemPararBuferizando()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_NumeroCupons, Str_NumeroItens, Str_VenderUmaLinha;

            Str_NumeroCupons = TB_NumeroCupons.Text.Trim();
            Str_NumeroItens = TB_NumeroItens.Text.Trim();
            Str_VenderUmaLinha = TB_VendeUmaLinha.Text.Trim();

            if ((Str_NumeroCupons.Equals("")) || (Str_NumeroItens.Equals("")) || (Str_VenderUmaLinha.Equals("")))
            {
                MessageBox.Show("É Necessário que sejam preenchidos todos os Campos!");
                
            }
            else
            {               //whileCupom

                int Int_Qtd_Cupom; //Guarda a Quantidade de Cupom desejado
                int Int_Qtd_Itens; //Guarda a Quantidade de Item desejado
                string Str_Qtd_Cupom; //Recebe do InputBox a Qtd desejada
                string Str_Qtd_Itens; //Recebe do InputBox a Qtd desejada
                string Str_NumeroLinhas; //Recebe o Numero de Linhas
                string Str_TimeFinal;
                string Str_TimeInicial;
                int Int_Contador;
                long Int_Codigo;
                Str_Qtd_Cupom = TB_NumeroCupons.Text.Trim();
                Str_Qtd_Itens = TB_NumeroItens.Text.Trim();
                Str_NumeroLinhas = TB_VendeUmaLinha.Text.Trim();
                Int_Contador = 1;
                Int_Codigo = 1234567890;
                if ((Str_Qtd_Cupom == "") || (Str_Qtd_Itens == "") || (Str_NumeroLinhas == ""))
                {
                    return;
                }
                Int_Qtd_Cupom = int.Parse(Str_Qtd_Cupom);
                Str_TimeInicial = DateTime.Now.ToLongTimeString();
                while (Int_Qtd_Cupom != 0)
                {
                    Int_Qtd_Itens = int.Parse(Str_Qtd_Itens);
                    //AbreCupom
                    Declaracoes.iRetorno = Declaracoes.iCFAbrirPadrao_ECF_Daruma();
                    while (Int_Qtd_Itens != 0)
                    {
                        if (int.Parse(Str_NumeroLinhas) == 1)
                        {
                            //VendeItem
                            Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("F1", "1,00", Int_Codigo.ToString(), "Item" + Int_Contador.ToString());
                        }
                        else
                            //Vende Item
                            Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("F1", "1,00", Int_Codigo.ToString(), "Item" + Int_Contador.ToString() + "Teste Venda" + Int_Contador.ToString());
                        Int_Contador = Int_Contador + 1;
                        Int_Codigo = Int_Codigo + 1;
                        if (Declaracoes.iRetorno != 1)
                        {
                            MessageBox.Show("Foi Detectado Erro na Venda de Item!! Vamos Cancelar o Cupom", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Declaracoes.iRetorno = Declaracoes.iCFCancelar_ECF_Daruma();
                            return;
                        }
                        Int_Qtd_Itens = Int_Qtd_Itens - 1;
                    }

                    Declaracoes.iRetorno = Declaracoes.iCFTotalizarCupomPadrao_ECF_Daruma();
                    Declaracoes.iRetorno = Declaracoes.iCFEfetuarPagamentoPadrao_ECF_Daruma();
                    Declaracoes.iRetorno = Declaracoes.iCFEncerrarPadrao_ECF_Daruma();

                    Int_Qtd_Cupom = Int_Qtd_Cupom - 1;
                }
                Str_TimeFinal = DateTime.Now.ToLongTimeString();

                MessageBox.Show("Time Inicial = " + Str_TimeInicial + "\n" + "TimeFinal = " + Str_TimeFinal, "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                
            }
            
        }
    }
}
