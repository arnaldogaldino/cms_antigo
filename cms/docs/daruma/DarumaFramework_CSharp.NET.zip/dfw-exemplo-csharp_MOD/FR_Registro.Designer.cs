﻿namespace DarumaFramework_CSharp
{
    partial class FR_Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_NomeProdutoChave = new System.Windows.Forms.TextBox();
            this.TB_ValorChave = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Cancelar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TB_NomeProdutoChave
            // 
            this.TB_NomeProdutoChave.Location = new System.Drawing.Point(146, 22);
            this.TB_NomeProdutoChave.Name = "TB_NomeProdutoChave";
            this.TB_NomeProdutoChave.Size = new System.Drawing.Size(100, 20);
            this.TB_NomeProdutoChave.TabIndex = 0;
            this.TB_NomeProdutoChave.Text = "ECF\\Auditoria";
            this.TB_NomeProdutoChave.TextChanged += new System.EventHandler(this.TB_NomeProdutoChave_TextChanged);
            // 
            // TB_ValorChave
            // 
            this.TB_ValorChave.Location = new System.Drawing.Point(146, 60);
            this.TB_ValorChave.Name = "TB_ValorChave";
            this.TB_ValorChave.Size = new System.Drawing.Size(100, 20);
            this.TB_ValorChave.TabIndex = 1;
            this.TB_ValorChave.Text = "1";
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(110, 96);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(65, 23);
            this.BT_Enviar.TabIndex = 2;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Cancelar
            // 
            this.BT_Cancelar.Location = new System.Drawing.Point(181, 96);
            this.BT_Cancelar.Name = "BT_Cancelar";
            this.BT_Cancelar.Size = new System.Drawing.Size(65, 23);
            this.BT_Cancelar.TabIndex = 3;
            this.BT_Cancelar.Text = "Cancelar";
            this.BT_Cancelar.UseVisualStyleBackColor = true;
            this.BT_Cancelar.Click += new System.EventHandler(this.BT_Cancelar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Nome do Produto e Chave:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Valor Chave:";
            // 
            // FR_Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 127);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BT_Cancelar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_ValorChave);
            this.Controls.Add(this.TB_NomeProdutoChave);
            this.Name = "FR_Registro";
            this.Text = "regAlterarValor_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_NomeProdutoChave;
        private System.Windows.Forms.TextBox TB_ValorChave;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Cancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}