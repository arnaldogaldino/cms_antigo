﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_confCadastrarPadrao_ECF_Daruma : Form
    {
        public FR_FISCAL_confCadastrarPadrao_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_TipoCadastro, Str_Valor;

            Str_TipoCadastro = CBO_TipoCadastro.Text.Trim();
            Str_Valor = TB_Valor.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.confCadastrarPadrao_ECF_Daruma(Str_TipoCadastro, Str_Valor);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                 
        }

        private void FR_FISCAL_confCadastrarPadrao_ECF_Daruma_Load(object sender, EventArgs e)
        {

        }
    }
}
