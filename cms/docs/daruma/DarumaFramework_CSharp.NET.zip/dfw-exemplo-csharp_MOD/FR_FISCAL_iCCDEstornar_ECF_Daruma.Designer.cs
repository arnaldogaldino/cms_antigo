﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCCDEstornar_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TB_COO = new System.Windows.Forms.TextBox();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_Endereco = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TB_Nome = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TB_CPF = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "COO:";
            // 
            // TB_COO
            // 
            this.TB_COO.Location = new System.Drawing.Point(87, 14);
            this.TB_COO.Name = "TB_COO";
            this.TB_COO.Size = new System.Drawing.Size(100, 20);
            this.TB_COO.TabIndex = 1;
            this.TB_COO.Text = "999999";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(229, 131);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 17;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(148, 131);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 16;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_Endereco
            // 
            this.TB_Endereco.Location = new System.Drawing.Point(87, 93);
            this.TB_Endereco.Name = "TB_Endereco";
            this.TB_Endereco.Size = new System.Drawing.Size(217, 20);
            this.TB_Endereco.TabIndex = 23;
            this.TB_Endereco.Text = "Av. Shishima Hifumi, 2911. 4 andar - Sala. 406  - São José dos Campos - São Paulo" +
                "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 96);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 22;
            this.label7.Text = "Endereço:";
            // 
            // TB_Nome
            // 
            this.TB_Nome.Location = new System.Drawing.Point(87, 67);
            this.TB_Nome.Name = "TB_Nome";
            this.TB_Nome.Size = new System.Drawing.Size(217, 20);
            this.TB_Nome.TabIndex = 21;
            this.TB_Nome.Text = "Daruma Developer Community";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 20;
            this.label6.Text = "Nome:";
            // 
            // TB_CPF
            // 
            this.TB_CPF.Location = new System.Drawing.Point(87, 41);
            this.TB_CPF.Name = "TB_CPF";
            this.TB_CPF.Size = new System.Drawing.Size(217, 20);
            this.TB_CPF.TabIndex = 19;
            this.TB_CPF.Text = "123.123.123-99";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(51, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "CPF:";
            // 
            // FR_FISCAL_iCCDEstornar_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 166);
            this.Controls.Add(this.TB_Endereco);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.TB_Nome);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TB_CPF);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_COO);
            this.Controls.Add(this.label1);
            this.Name = "FR_FISCAL_iCCDEstornar_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCCDEstornar_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_COO;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_Endereco;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TB_Nome;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TB_CPF;
        private System.Windows.Forms.Label label5;
    }
}