﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFLancarAcrescimoItem_ECF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Numero_Item = new System.Windows.Forms.TextBox();
            this.TB_Tipo_Acrescimo = new System.Windows.Forms.TextBox();
            this.TB_Valor_Acrescimo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número Item:";
            // 
            // TB_Numero_Item
            // 
            this.TB_Numero_Item.Location = new System.Drawing.Point(130, 12);
            this.TB_Numero_Item.Name = "TB_Numero_Item";
            this.TB_Numero_Item.Size = new System.Drawing.Size(100, 20);
            this.TB_Numero_Item.TabIndex = 1;
            this.TB_Numero_Item.Text = "001";
            // 
            // TB_Tipo_Acrescimo
            // 
            this.TB_Tipo_Acrescimo.Location = new System.Drawing.Point(130, 38);
            this.TB_Tipo_Acrescimo.Name = "TB_Tipo_Acrescimo";
            this.TB_Tipo_Acrescimo.Size = new System.Drawing.Size(158, 20);
            this.TB_Tipo_Acrescimo.TabIndex = 2;
            this.TB_Tipo_Acrescimo.Text = "D$";
            // 
            // TB_Valor_Acrescimo
            // 
            this.TB_Valor_Acrescimo.Location = new System.Drawing.Point(130, 64);
            this.TB_Valor_Acrescimo.Name = "TB_Valor_Acrescimo";
            this.TB_Valor_Acrescimo.Size = new System.Drawing.Size(158, 20);
            this.TB_Valor_Acrescimo.TabIndex = 3;
            this.TB_Valor_Acrescimo.Text = "0,01";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 67);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(89, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Valor  Acréscimo:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Tipo Acréscimo:";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(211, 99);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 41;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(130, 99);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 40;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // FR_FISCAL_iCFLancarAcrescimoItem_ECF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(300, 134);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_Valor_Acrescimo);
            this.Controls.Add(this.TB_Tipo_Acrescimo);
            this.Controls.Add(this.TB_Numero_Item);
            this.Controls.Add(this.label1);
            this.Name = "FR_FISCAL_iCFLancarAcrescimoItem_ECF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iCFLancarAcrescimoItem_ECF";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Numero_Item;
        private System.Windows.Forms.TextBox TB_Tipo_Acrescimo;
        private System.Windows.Forms.TextBox TB_Valor_Acrescimo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
    }
}