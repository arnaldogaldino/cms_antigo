﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFVender_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_Aliquota = new System.Windows.Forms.TextBox();
            this.TB_Qtde = new System.Windows.Forms.TextBox();
            this.TB_ValorUnitario = new System.Windows.Forms.TextBox();
            this.TB_TipoDesc_Acresc = new System.Windows.Forms.TextBox();
            this.TB_Valor_Desc_Acresc = new System.Windows.Forms.TextBox();
            this.TB_Codigo_Item = new System.Windows.Forms.TextBox();
            this.TB_Unidade_Medida = new System.Windows.Forms.TextBox();
            this.TB_Descricao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(317, 243);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 3;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(236, 243);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 2;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_Aliquota
            // 
            this.TB_Aliquota.Location = new System.Drawing.Point(132, 22);
            this.TB_Aliquota.Name = "TB_Aliquota";
            this.TB_Aliquota.Size = new System.Drawing.Size(41, 20);
            this.TB_Aliquota.TabIndex = 4;
            this.TB_Aliquota.Text = "I1";
            // 
            // TB_Qtde
            // 
            this.TB_Qtde.Location = new System.Drawing.Point(132, 48);
            this.TB_Qtde.Name = "TB_Qtde";
            this.TB_Qtde.Size = new System.Drawing.Size(75, 20);
            this.TB_Qtde.TabIndex = 5;
            this.TB_Qtde.Text = "1,000";
            // 
            // TB_ValorUnitario
            // 
            this.TB_ValorUnitario.Location = new System.Drawing.Point(132, 74);
            this.TB_ValorUnitario.Name = "TB_ValorUnitario";
            this.TB_ValorUnitario.Size = new System.Drawing.Size(110, 20);
            this.TB_ValorUnitario.TabIndex = 6;
            this.TB_ValorUnitario.Text = "0,10";
            // 
            // TB_TipoDesc_Acresc
            // 
            this.TB_TipoDesc_Acresc.Location = new System.Drawing.Point(132, 100);
            this.TB_TipoDesc_Acresc.Name = "TB_TipoDesc_Acresc";
            this.TB_TipoDesc_Acresc.Size = new System.Drawing.Size(110, 20);
            this.TB_TipoDesc_Acresc.TabIndex = 7;
            this.TB_TipoDesc_Acresc.Text = "D$";
            // 
            // TB_Valor_Desc_Acresc
            // 
            this.TB_Valor_Desc_Acresc.Location = new System.Drawing.Point(132, 128);
            this.TB_Valor_Desc_Acresc.Name = "TB_Valor_Desc_Acresc";
            this.TB_Valor_Desc_Acresc.Size = new System.Drawing.Size(110, 20);
            this.TB_Valor_Desc_Acresc.TabIndex = 8;
            this.TB_Valor_Desc_Acresc.Text = "0,01";
            // 
            // TB_Codigo_Item
            // 
            this.TB_Codigo_Item.Location = new System.Drawing.Point(132, 154);
            this.TB_Codigo_Item.Name = "TB_Codigo_Item";
            this.TB_Codigo_Item.Size = new System.Drawing.Size(139, 20);
            this.TB_Codigo_Item.TabIndex = 9;
            this.TB_Codigo_Item.Text = "7896230301146";
            // 
            // TB_Unidade_Medida
            // 
            this.TB_Unidade_Medida.Location = new System.Drawing.Point(132, 180);
            this.TB_Unidade_Medida.Name = "TB_Unidade_Medida";
            this.TB_Unidade_Medida.Size = new System.Drawing.Size(41, 20);
            this.TB_Unidade_Medida.TabIndex = 10;
            this.TB_Unidade_Medida.Text = "UN";
            // 
            // TB_Descricao
            // 
            this.TB_Descricao.Location = new System.Drawing.Point(132, 206);
            this.TB_Descricao.Name = "TB_Descricao";
            this.TB_Descricao.Size = new System.Drawing.Size(260, 20);
            this.TB_Descricao.TabIndex = 11;
            this.TB_Descricao.Text = "Bolacha";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(76, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Alíquota:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Quantidade:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "Valor Unitário:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Tipo Desc. / Acresc.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Valor Desc. / Acresc.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(60, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "Código Item:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(38, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(88, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Unidade Medida:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(68, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 19;
            this.label8.Text = "Descrição:";
            // 
            // FR_FISCAL_iCFVender_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(408, 281);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Descricao);
            this.Controls.Add(this.TB_Unidade_Medida);
            this.Controls.Add(this.TB_Codigo_Item);
            this.Controls.Add(this.TB_Valor_Desc_Acresc);
            this.Controls.Add(this.TB_TipoDesc_Acresc);
            this.Controls.Add(this.TB_ValorUnitario);
            this.Controls.Add(this.TB_Qtde);
            this.Controls.Add(this.TB_Aliquota);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_iCFVender_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método iCFVender_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_Aliquota;
        private System.Windows.Forms.TextBox TB_Qtde;
        private System.Windows.Forms.TextBox TB_ValorUnitario;
        private System.Windows.Forms.TextBox TB_TipoDesc_Acresc;
        private System.Windows.Forms.TextBox TB_Valor_Desc_Acresc;
        private System.Windows.Forms.TextBox TB_Codigo_Item;
        private System.Windows.Forms.TextBox TB_Unidade_Medida;
        private System.Windows.Forms.TextBox TB_Descricao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}