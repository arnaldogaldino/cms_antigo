﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_Teste_Consumo_MFD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_limpar_logs = new System.Windows.Forms.Button();
            this.bt_limpar_LstBox = new System.Windows.Forms.Button();
            this.CH_ReenviarLog = new System.Windows.Forms.CheckBox();
            this.bt_Recalcular = new System.Windows.Forms.Button();
            this.LB_MFDBYTES = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.PG_MFDPERCENT = new System.Windows.Forms.ProgressBar();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.LB_MFDPERCENT = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.LB_LogDescricao = new System.Windows.Forms.ListBox();
            this.LB_LogCodigo = new System.Windows.Forms.ListBox();
            this.LB_StatusEnvio = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.PerguntarStatusCupom = new System.Windows.Forms.CheckBox();
            this.PerguntarGT = new System.Windows.Forms.CheckBox();
            this.PerguntarSubTotal = new System.Windows.Forms.CheckBox();
            this.PerguntarLigada = new System.Windows.Forms.CheckBox();
            this.bt_Imprime_Cupons = new System.Windows.Forms.Button();
            this.TX_Itens = new System.Windows.Forms.TextBox();
            this.TX_Cupons = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TX_QtdDigitoAleatorio = new System.Windows.Forms.TextBox();
            this.TX_QtdLetraAleatoria = new System.Windows.Forms.TextBox();
            this.TX_CodigoAleatorio = new System.Windows.Forms.TextBox();
            this.TX_DescricaoAleatoria = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_fechar = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_limpar_logs
            // 
            this.bt_limpar_logs.Location = new System.Drawing.Point(782, 341);
            this.bt_limpar_logs.Name = "bt_limpar_logs";
            this.bt_limpar_logs.Size = new System.Drawing.Size(80, 23);
            this.bt_limpar_logs.TabIndex = 59;
            this.bt_limpar_logs.Text = "Limpar Logs";
            this.bt_limpar_logs.Click += new System.EventHandler(this.bt_limpar_logs_Click);
            // 
            // bt_limpar_LstBox
            // 
            this.bt_limpar_LstBox.Location = new System.Drawing.Point(462, 341);
            this.bt_limpar_LstBox.Name = "bt_limpar_LstBox";
            this.bt_limpar_LstBox.Size = new System.Drawing.Size(96, 23);
            this.bt_limpar_LstBox.TabIndex = 58;
            this.bt_limpar_LstBox.Text = "Limpar List Box";
            this.bt_limpar_LstBox.Click += new System.EventHandler(this.bt_limpar_LstBox_Click);
            // 
            // CH_ReenviarLog
            // 
            this.CH_ReenviarLog.Location = new System.Drawing.Point(622, 341);
            this.CH_ReenviarLog.Name = "CH_ReenviarLog";
            this.CH_ReenviarLog.Size = new System.Drawing.Size(106, 23);
            this.CH_ReenviarLog.TabIndex = 57;
            this.CH_ReenviarLog.Text = "Reenviar Log";
            // 
            // bt_Recalcular
            // 
            this.bt_Recalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.bt_Recalcular.Location = new System.Drawing.Point(6, 461);
            this.bt_Recalcular.Name = "bt_Recalcular";
            this.bt_Recalcular.Size = new System.Drawing.Size(75, 23);
            this.bt_Recalcular.TabIndex = 55;
            this.bt_Recalcular.Text = "Recalcular";
            this.bt_Recalcular.Click += new System.EventHandler(this.bt_Recalcular_Click);
            // 
            // LB_MFDBYTES
            // 
            this.LB_MFDBYTES.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_MFDBYTES.Location = new System.Drawing.Point(150, 429);
            this.LB_MFDBYTES.Name = "LB_MFDBYTES";
            this.LB_MFDBYTES.Size = new System.Drawing.Size(216, 23);
            this.LB_MFDBYTES.TabIndex = 54;
            this.LB_MFDBYTES.Text = "000000000 Bytes";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 429);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 23);
            this.label14.TabIndex = 53;
            this.label14.Text = "MFD em Bytes:";
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(838, 373);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 24);
            this.label13.TabIndex = 52;
            this.label13.Text = "Máximo";
            // 
            // PG_MFDPERCENT
            // 
            this.PG_MFDPERCENT.Location = new System.Drawing.Point(6, 397);
            this.PG_MFDPERCENT.Name = "PG_MFDPERCENT";
            this.PG_MFDPERCENT.Size = new System.Drawing.Size(904, 23);
            this.PG_MFDPERCENT.TabIndex = 51;
            this.PG_MFDPERCENT.Value = 100;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 373);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 23);
            this.label12.TabIndex = 50;
            this.label12.Text = "Mínimo";
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(206, 349);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 23);
            this.label11.TabIndex = 49;
            this.label11.Text = "Disponível";
            // 
            // LB_MFDPERCENT
            // 
            this.LB_MFDPERCENT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_MFDPERCENT.Location = new System.Drawing.Point(6, 349);
            this.LB_MFDPERCENT.Name = "LB_MFDPERCENT";
            this.LB_MFDPERCENT.Size = new System.Drawing.Size(192, 23);
            this.LB_MFDPERCENT.TabIndex = 48;
            this.LB_MFDPERCENT.Text = "MFD em % : 00,00";
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(782, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 47;
            this.label9.Text = "Log Descricao";
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(614, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 16);
            this.label8.TabIndex = 46;
            this.label8.Text = "Log Codigo";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(462, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 16);
            this.label7.TabIndex = 45;
            this.label7.Text = "Status Envio";
            // 
            // LB_LogDescricao
            // 
            this.LB_LogDescricao.Location = new System.Drawing.Point(750, 29);
            this.LB_LogDescricao.Name = "LB_LogDescricao";
            this.LB_LogDescricao.Size = new System.Drawing.Size(144, 303);
            this.LB_LogDescricao.TabIndex = 44;
            // 
            // LB_LogCodigo
            // 
            this.LB_LogCodigo.Location = new System.Drawing.Point(598, 29);
            this.LB_LogCodigo.Name = "LB_LogCodigo";
            this.LB_LogCodigo.Size = new System.Drawing.Size(144, 303);
            this.LB_LogCodigo.TabIndex = 43;
            // 
            // LB_StatusEnvio
            // 
            this.LB_StatusEnvio.Items.AddRange(new object[] {
            ""});
            this.LB_StatusEnvio.Location = new System.Drawing.Point(446, 29);
            this.LB_StatusEnvio.Name = "LB_StatusEnvio";
            this.LB_StatusEnvio.Size = new System.Drawing.Size(144, 303);
            this.LB_StatusEnvio.TabIndex = 42;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.PerguntarStatusCupom);
            this.groupBox2.Controls.Add(this.PerguntarGT);
            this.groupBox2.Controls.Add(this.PerguntarSubTotal);
            this.groupBox2.Controls.Add(this.PerguntarLigada);
            this.groupBox2.Controls.Add(this.bt_Imprime_Cupons);
            this.groupBox2.Controls.Add(this.TX_Itens);
            this.groupBox2.Controls.Add(this.TX_Cupons);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(6, 133);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(392, 152);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cupom Fiscal";
            // 
            // PerguntarStatusCupom
            // 
            this.PerguntarStatusCupom.Location = new System.Drawing.Point(8, 128);
            this.PerguntarStatusCupom.Name = "PerguntarStatusCupom";
            this.PerguntarStatusCupom.Size = new System.Drawing.Size(192, 16);
            this.PerguntarStatusCupom.TabIndex = 8;
            this.PerguntarStatusCupom.Text = "Perguntar Status Cupom (cupm)";
            // 
            // PerguntarGT
            // 
            this.PerguntarGT.Location = new System.Drawing.Point(8, 112);
            this.PerguntarGT.Name = "PerguntarGT";
            this.PerguntarGT.Size = new System.Drawing.Size(144, 16);
            this.PerguntarGT.TabIndex = 7;
            this.PerguntarGT.Text = "Perguntar GT (Cupom)";
            // 
            // PerguntarSubTotal
            // 
            this.PerguntarSubTotal.Location = new System.Drawing.Point(8, 96);
            this.PerguntarSubTotal.Name = "PerguntarSubTotal";
            this.PerguntarSubTotal.Size = new System.Drawing.Size(160, 16);
            this.PerguntarSubTotal.TabIndex = 6;
            this.PerguntarSubTotal.Text = "Perguntar SubTotal (item)";
            // 
            // PerguntarLigada
            // 
            this.PerguntarLigada.Location = new System.Drawing.Point(8, 80);
            this.PerguntarLigada.Name = "PerguntarLigada";
            this.PerguntarLigada.Size = new System.Drawing.Size(200, 16);
            this.PerguntarLigada.TabIndex = 5;
            this.PerguntarLigada.Text = "Perguntar Impressora Ligada(item)";
            this.PerguntarLigada.CheckedChanged += new System.EventHandler(this.PerguntarLigada_CheckedChanged);
            // 
            // bt_Imprime_Cupons
            // 
            this.bt_Imprime_Cupons.Location = new System.Drawing.Point(272, 72);
            this.bt_Imprime_Cupons.Name = "bt_Imprime_Cupons";
            this.bt_Imprime_Cupons.Size = new System.Drawing.Size(104, 23);
            this.bt_Imprime_Cupons.TabIndex = 4;
            this.bt_Imprime_Cupons.Text = "Imprimir Cupom";
            this.bt_Imprime_Cupons.Click += new System.EventHandler(this.bt_Imprime_Cupons_Click);
            // 
            // TX_Itens
            // 
            this.TX_Itens.Location = new System.Drawing.Point(248, 40);
            this.TX_Itens.Name = "TX_Itens";
            this.TX_Itens.Size = new System.Drawing.Size(136, 20);
            this.TX_Itens.TabIndex = 3;
            this.TX_Itens.Text = "10";
            // 
            // TX_Cupons
            // 
            this.TX_Cupons.Location = new System.Drawing.Point(184, 16);
            this.TX_Cupons.Name = "TX_Cupons";
            this.TX_Cupons.Size = new System.Drawing.Size(200, 20);
            this.TX_Cupons.TabIndex = 2;
            this.TX_Cupons.Text = "1";
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(16, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(232, 16);
            this.label6.TabIndex = 1;
            this.label6.Text = "Quantos Itens Você deseja em Cada Cupom:";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(16, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Quantos Cupos Você deseja:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TX_QtdDigitoAleatorio);
            this.groupBox1.Controls.Add(this.TX_QtdLetraAleatoria);
            this.groupBox1.Controls.Add(this.TX_CodigoAleatorio);
            this.groupBox1.Controls.Add(this.TX_DescricaoAleatoria);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(432, 120);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Parametros para o teste";
            // 
            // TX_QtdDigitoAleatorio
            // 
            this.TX_QtdDigitoAleatorio.Location = new System.Drawing.Point(184, 88);
            this.TX_QtdDigitoAleatorio.Name = "TX_QtdDigitoAleatorio";
            this.TX_QtdDigitoAleatorio.Size = new System.Drawing.Size(240, 20);
            this.TX_QtdDigitoAleatorio.TabIndex = 7;
            this.TX_QtdDigitoAleatorio.Text = "13";
            // 
            // TX_QtdLetraAleatoria
            // 
            this.TX_QtdLetraAleatoria.Location = new System.Drawing.Point(176, 64);
            this.TX_QtdLetraAleatoria.Name = "TX_QtdLetraAleatoria";
            this.TX_QtdLetraAleatoria.Size = new System.Drawing.Size(248, 20);
            this.TX_QtdLetraAleatoria.TabIndex = 6;
            this.TX_QtdLetraAleatoria.Text = "10";
            // 
            // TX_CodigoAleatorio
            // 
            this.TX_CodigoAleatorio.Location = new System.Drawing.Point(144, 40);
            this.TX_CodigoAleatorio.Name = "TX_CodigoAleatorio";
            this.TX_CodigoAleatorio.Size = new System.Drawing.Size(280, 20);
            this.TX_CodigoAleatorio.TabIndex = 5;
            this.TX_CodigoAleatorio.Text = "1234567890";
            // 
            // TX_DescricaoAleatoria
            // 
            this.TX_DescricaoAleatoria.Location = new System.Drawing.Point(216, 16);
            this.TX_DescricaoAleatoria.Name = "TX_DescricaoAleatoria";
            this.TX_DescricaoAleatoria.Size = new System.Drawing.Size(208, 20);
            this.TX_DescricaoAleatoria.TabIndex = 4;
            this.TX_DescricaoAleatoria.Text = "ABCDEFGHIJKLMNOPQRSTUVXZ";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(176, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantidade de Digitos no Codigo:";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantidade de Letras Aleatorias:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Codigo do Item Aleatorio:";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Letras Aleatorias da Descriçao do Item:";
            // 
            // bt_fechar
            // 
            this.bt_fechar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bt_fechar.Location = new System.Drawing.Point(821, 479);
            this.bt_fechar.Name = "bt_fechar";
            this.bt_fechar.Size = new System.Drawing.Size(88, 23);
            this.bt_fechar.TabIndex = 60;
            this.bt_fechar.Text = "Fechar";
            this.bt_fechar.Click += new System.EventHandler(this.bt_fechar_Click);
            // 
            // FR_FISCAL_Teste_Consumo_MFD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 515);
            this.Controls.Add(this.bt_fechar);
            this.Controls.Add(this.bt_limpar_logs);
            this.Controls.Add(this.bt_limpar_LstBox);
            this.Controls.Add(this.CH_ReenviarLog);
            this.Controls.Add(this.bt_Recalcular);
            this.Controls.Add(this.LB_MFDBYTES);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.PG_MFDPERCENT);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.LB_MFDPERCENT);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.LB_LogDescricao);
            this.Controls.Add(this.LB_LogCodigo);
            this.Controls.Add(this.LB_StatusEnvio);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "FR_FISCAL_Teste_Consumo_MFD";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FR_FISCAL_Teste_Consumo_MFD";
            this.Load += new System.EventHandler(this.FR_FISCAL_Teste_Consumo_MFD_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_limpar_logs;
        private System.Windows.Forms.Button bt_limpar_LstBox;
        private System.Windows.Forms.CheckBox CH_ReenviarLog;
        private System.Windows.Forms.Button bt_Recalcular;
        public System.Windows.Forms.Label LB_MFDBYTES;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        public System.Windows.Forms.ProgressBar PG_MFDPERCENT;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label LB_MFDPERCENT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox LB_LogDescricao;
        private System.Windows.Forms.ListBox LB_LogCodigo;
        private System.Windows.Forms.ListBox LB_StatusEnvio;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox PerguntarStatusCupom;
        private System.Windows.Forms.CheckBox PerguntarGT;
        private System.Windows.Forms.CheckBox PerguntarSubTotal;
        private System.Windows.Forms.CheckBox PerguntarLigada;
        private System.Windows.Forms.Button bt_Imprime_Cupons;
        private System.Windows.Forms.TextBox TX_Itens;
        private System.Windows.Forms.TextBox TX_Cupons;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TX_QtdDigitoAleatorio;
        private System.Windows.Forms.TextBox TX_QtdLetraAleatoria;
        private System.Windows.Forms.TextBox TX_CodigoAleatorio;
        private System.Windows.Forms.TextBox TX_DescricaoAleatoria;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_fechar;
    }
}