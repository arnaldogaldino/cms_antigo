﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma : Form
    {
        public FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma()
        {
            InitializeComponent();
        }

        
        private void BT_FECHAR_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_GerarRelatorio_Click(object sender, EventArgs e)
        {

            string Str_Tipo, Str_Inicial, Str_Final, Str_LocalArquivos;
            Str_Tipo = string.Empty;
            Str_Tipo = CBO_Tipo.Text.Trim();
            Str_LocalArquivos = string.Empty;

            Str_LocalArquivos = TB_LocalArquivos.Text.Trim();

            if (Str_LocalArquivos != null)
            {
                Declaracoes.regAlterarValor_Daruma(@"START\LocalArquivosRelatorios", Str_LocalArquivos);
            }


            if (Str_Tipo == "2_Intervalo de COO")
            {
                Str_Tipo = "2";
                Str_Inicial = TB_Inicial.Text.Trim();
                Str_Final = TB_Final.Text.Trim();

                Declaracoes.iRetorno = Declaracoes.rGerarEspelhoMFD_ECF_Daruma(Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (Str_Tipo == "1_Intervalo de datas")
            {
                Str_Tipo = "1";

                DateTime Str_Inicial1 = Convert.ToDateTime(DTP_DataInicial.Text);
                Str_Inicial = Str_Inicial1.ToString("ddMMyy");
                DateTime Str_Final1 = Convert.ToDateTime(DTP_DataFinal.Text);
                Str_Final = Str_Final1.ToString("ddMMyy");

                Declaracoes.iRetorno = Declaracoes.rGerarEspelhoMFD_ECF_Daruma(Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            }
            else if (CBO_Tipo.SelectedItem.Equals("3_Intervalo de Data Movimento"))
            {
                Str_Tipo = "3";
                DateTime Str_Inicial1 = Convert.ToDateTime(DTP_DataInicial.Text);
                Str_Inicial = Str_Inicial1.ToString("ddMMyy");
                DateTime Str_Final1 = Convert.ToDateTime(DTP_DataFinal.Text);
                Str_Final = Str_Final1.ToString("ddMMyy");

                Declaracoes.iRetorno = Declaracoes.rGerarEspelhoMFD_ECF_Daruma(Str_Tipo, Str_Inicial, Str_Final);
                Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            }
        }

        private void CBO_Tipo_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (CBO_Tipo.SelectedItem.Equals("1_Intervalo de datas"))
            {
                DTP_DataInicial.Visible = true;
                DTP_DataFinal.Visible = true;
                TB_Inicial.Visible = false;
                TB_Final.Visible = false;
            }
            else if (CBO_Tipo.SelectedItem.Equals("2_Intervalo de COO"))
            {
                DTP_DataInicial.Visible = false;
                DTP_DataFinal.Visible = false;
                TB_Inicial.Visible = true;
                TB_Final.Visible = true;
            }
            else if (CBO_Tipo.SelectedItem.Equals("3_Intervalo de Data Movimento"))
            {
                DTP_DataInicial.Visible = true;
                DTP_DataFinal.Visible = true;
                TB_Inicial.Visible = false;
                TB_Final.Visible = false;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            string Str_LocalArquivos = folderBrowserDialog1.SelectedPath.ToString()+@"\";

            TB_LocalArquivos.Text = Str_LocalArquivos;
        }

        private void FR_FISCAL_rGerarEspelhoMFD_ECF_Daruma_Load(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

      
    }
}
