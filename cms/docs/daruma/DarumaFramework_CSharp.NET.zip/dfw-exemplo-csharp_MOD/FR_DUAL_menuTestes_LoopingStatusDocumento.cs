using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_DUAL_menuTestes_LoopingStatusDocumento : Form
    {
        public FR_DUAL_menuTestes_LoopingStatusDocumento()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            this.DestroyHandle();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            TM_StatusDoc.Enabled = true;
        }

        private void BT_Stop_Click(object sender, EventArgs e)
        {
            TM_StatusDoc.Enabled = false;
            TB_StatusDoc.Clear();
        }

        private void TM_StatusDoc_Tick(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rStatusDocumento_DUAL_DarumaFramework();

            if (Declaracoes.iRetorno == 1 | Declaracoes.iRetorno == 0 | Declaracoes.iRetorno == -27)
                switch (Declaracoes.iRetorno)
                {
                    case 0: TB_StatusDoc.Text = "0(zero) - Documento n�o posicionado, favor verificar!";
                        break;
                    case 1: TB_StatusDoc.Text = "1(um) - Documento posicionado";
                        break;
                    case -27: TB_StatusDoc.Text = "-27 - Erro Generico!";
                        break;
                }

            else
            {
                TB_StatusDoc.Text = "Retorno n�o esperado!";
            }
        }
    }
}