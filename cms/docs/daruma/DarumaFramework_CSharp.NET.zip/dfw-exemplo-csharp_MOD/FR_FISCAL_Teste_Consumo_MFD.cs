﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_Teste_Consumo_MFD : Form
    {
        public FR_FISCAL_Teste_Consumo_MFD()
        {
            InitializeComponent();
        }

        private void bt_fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void bt_Imprime_Cupons_Click(object sender, EventArgs e)
        {
            StringBuilder Str_GT = new StringBuilder();					//recebe o Grande Total
            StringBuilder Str_SubTotal = new StringBuilder();			//recebe o SubTotal
            StringBuilder Str_StatusCupom = new StringBuilder();			//recebe o Status do Cupom Fiscal (1)Aberto e (0)Fechado
            Random Int_Random = new Random();
            Random RandomClass = new Random();
            int Int_ImpressoraLigada;		//recebe o Status de ECF (1)Ligado (0)Desligado
            int Int_ContaRamdom;
            int Int_Qtd_Cupom;			//Guarda a Quantidade de Cupom desejado
            int Int_Qtd_Itens;			//Guarda a Quantidade de Item desejado
            int Int_CodigoAleatorio;
            int Int_Tamanho;
            double Int_Tamanho1;
            double Int_Tamanho2;
            int Int_TamanhoString;
            int Int_TamanhoCodigo;
            string Str_CodigoRamdom2;
            string Str_Qtd_Cupom;		//Recebe do InputBox a Qtd desejada
            string Str_Qtd_Itens;		//Recebe do InputBox a Qtd desejada
            string Str_NumeroLinhas;
            string Str_TimeInicial;
            string Str_TimeFinal;
            string Str_DescricaoRamdom1;     //recebe a string da descricao ramdomica
            string Str_DescricaoRamdom;
            string Str_CodigoRamdom;		//recebe a string do codigo ramdomico			
            string Str_CodigoRamdomAleatorio;
            string Str_DescricaoAleatoria;

            Str_Qtd_Cupom = TX_Cupons.Text;
            Str_Qtd_Itens = TX_Itens.Text;
            Str_NumeroLinhas = ("1");

            if (string.IsNullOrEmpty(Str_Qtd_Cupom) | string.IsNullOrEmpty(Str_Qtd_Itens) | string.IsNullOrEmpty(Str_NumeroLinhas))
            {
                return;
            }
            Int_Qtd_Cupom = int.Parse(Str_Qtd_Cupom.ToString());
            Str_TimeInicial = DateTime.Now.ToLongTimeString();
            LB_StatusEnvio.Items.Add("TIME INICIAL = " + Str_TimeInicial);
            LB_StatusEnvio.Refresh();
            while (Int_Qtd_Cupom != 0)
            {
                Declaracoes.iRetorno = Declaracoes.rRetornarInformacao_ECF_Daruma("56", Str_StatusCupom);
                if (int.Parse(Str_StatusCupom.ToString()) == 1)
                {
                    Declaracoes.iCFCancelar_ECF_Daruma();
                }
                if (int.Parse(Str_StatusCupom.ToString()) == 0)
                {
                    Int_ContaRamdom = 0;
                    if ((PerguntarLigada.Checked.ToString()) == "True")
                    {
                        Int_ImpressoraLigada = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
                        if (Int_ImpressoraLigada != 1)
                        {
                            MessageBox.Show("ECF Desligado!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    if ((PerguntarGT.Checked.ToString()) == "True")
                    {
                        Declaracoes.iRetorno = Declaracoes.rRetornarInformacao_ECF_Daruma("1",Str_GT);
                        if (Declaracoes.iRetorno != 1)
                        {
                            MessageBox.Show("Erro na Execucao da Funcao Grade Total", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    Declaracoes.iCFAbrirPadrao_ECF_Daruma();
                    if ((PerguntarStatusCupom.Checked.ToString()) == "True")
                    {
                        
                        Declaracoes.iRetorno = Declaracoes.rRetornarInformacao_ECF_Daruma("56", Str_StatusCupom);
                        if (Declaracoes.iRetorno != 1)
                        {
                            MessageBox.Show("Erro na Execucao da Funcao Status Cupom Fiscal!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                }
                Int_Qtd_Itens = int.Parse(Str_Qtd_Itens.ToString());
                while (Int_Qtd_Itens != 0)
                {
                    if (int.Parse(Str_NumeroLinhas) == 1)
                    {
                        if ((CH_ReenviarLog.Checked.ToString()) == "True")
                        {
                            Int_Qtd_Itens = 1;
                            Int_Qtd_Cupom = 1;
                        }

                        if ((CH_ReenviarLog.Checked.ToString()) != "True")
                        {
                            // primeiro vamos gerar o codigo randomico
                            Int_ContaRamdom = int.Parse(TX_QtdDigitoAleatorio.Text);
                            Str_CodigoRamdom = "";
                            while (Int_ContaRamdom != 0)
                            {
                                Int_Tamanho2 = 0;
                                Int_TamanhoCodigo = (TX_CodigoAleatorio.Text.Length);
                                Int_Tamanho2 = (Math.Abs(RandomClass.Next()));
                                while (Int_Tamanho2 >= (Int_TamanhoCodigo))
                                {
                                    Int_Tamanho2 = (Int_Tamanho2 / Int_TamanhoCodigo);
                                }
                                Int_CodigoAleatorio = Convert.ToInt32(Int_Tamanho2);
                                Int_CodigoAleatorio = Int_CodigoAleatorio - 1;

                                Str_CodigoRamdomAleatorio = TX_CodigoAleatorio.Text;
                                Str_CodigoRamdom2 = Str_CodigoRamdomAleatorio.Substring(Int_CodigoAleatorio, 1);
                                Str_CodigoRamdom = (Str_CodigoRamdom + Str_CodigoRamdom2);

                                Int_ContaRamdom = (Int_ContaRamdom - 1);

                            }
                            if ((PerguntarLigada.Checked.ToString()) == "True")
                            {
                                Int_ImpressoraLigada = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
                                if (Int_ImpressoraLigada != 1)
                                {
                                    MessageBox.Show("ECF Desligado!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                            // Pegar a Descricao Aleatoria
                            Int_ContaRamdom = int.Parse(TX_QtdLetraAleatoria.Text);
                            Str_DescricaoRamdom = ("");
                            Int_Tamanho1 = 0;
                            while (Int_ContaRamdom != 0)
                            {
                                Int_Tamanho1 = 0;
                                Int_TamanhoString = (TX_DescricaoAleatoria.Text.Length);
                                Int_Tamanho1 = Math.Abs((Int_TamanhoString * Int_Random.Next()) + 1);
                                while (Int_Tamanho1 >= (Int_TamanhoString))
                                {

                                    Int_Tamanho1 = (Int_Tamanho1 / Int_TamanhoString);

                                }
                                Int_Tamanho = Convert.ToInt32(Int_Tamanho1);
                                Int_Tamanho = Int_Tamanho - 1;
                                Str_DescricaoAleatoria = TX_DescricaoAleatoria.Text;
                                Str_DescricaoRamdom1 = Str_DescricaoAleatoria.Substring(Int_Tamanho, 1);
                                Str_DescricaoRamdom = (Str_DescricaoRamdom + Str_DescricaoRamdom1);
                                Int_ContaRamdom = (Int_ContaRamdom - 1);

                            }

                      
                            Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("I1", "0,10", Str_CodigoRamdom, Str_DescricaoRamdom);
                            LB_LogCodigo.Items.Add(Str_CodigoRamdom);
                            LB_LogDescricao.Items.Add(Str_DescricaoRamdom);
                           
                            if ((PerguntarSubTotal.Checked.ToString()) == "True")
                            {
                                Declaracoes.iRetorno = Declaracoes.rCFSubTotal_ECF_Daruma(Str_SubTotal);
                                if (Declaracoes.iRetorno != 1)
                                {
                                    MessageBox.Show("Erro na Execucao da Funcao Sub Total!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                            }
                        }   


                        if (false)
                        {
                            if(PerguntarLigada.Checked==true)
                            {
                                Int_ImpressoraLigada = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
                                if (Int_ImpressoraLigada != 1)
                                {
                                    MessageBox.Show("ECF Desligado!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }
                                Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("I1", "0,10", LB_LogCodigo.Items[Int_ContaRamdom].ToString(), LB_LogDescricao.Items[Int_ContaRamdom].ToString());
                            }
                        }



                        LB_StatusEnvio.Items.Add("Retorno do comando = " + Declaracoes.iRetorno.ToString());
                        LB_StatusEnvio.Refresh();
                        if ((PerguntarSubTotal.Checked.ToString()) == "True")
                        {
                            Declaracoes.iRetorno = Declaracoes.rCFSubTotal_ECF_Daruma(Str_SubTotal);
                            if (Declaracoes.iRetorno != 1)
                            {
                                MessageBox.Show("Erro na Execucao da Funcao Sub Total!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                    }
                    else
                    {
                        if ((PerguntarLigada.Checked.ToString()) == "True")
                        {
                            Int_ImpressoraLigada = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
                            if (Int_ImpressoraLigada != 1)
                            {
                                MessageBox.Show("ECF Desligado!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                        Declaracoes.iRetorno = Declaracoes.iCFVenderResumido_ECF_Daruma("I1", "0,10",/* LB_LogCodigo.Items[Int_ContaRamdom].ToString()*/"123456", /*LB_LogDescricao.Items[Int_ContaRamdom].ToString()*/"32232323");
                        if (Declaracoes.iRetorno != 1)
                        {
                            MessageBox.Show("Foi Detectado Erro na Venda de Item!! Vamos Cancelar o Cupom", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Declaracoes.iCFCancelar_ECF_Daruma();
                        }
                    }
                    Int_Qtd_Itens = (Int_Qtd_Itens - 1);
                } //While do Item				
                if ((PerguntarLigada.Checked.ToString()) == "True")
                {
                    Int_ImpressoraLigada = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
                    if (Int_ImpressoraLigada != 1)
                    {
                        MessageBox.Show("ECF Desligado!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                if ((PerguntarSubTotal.Checked.ToString()) == "True")
                {
                    Declaracoes.iRetorno = Declaracoes.rCFSubTotal_ECF_Daruma(Str_SubTotal);
                    if (Declaracoes.iRetorno != 1)
                    {
                        MessageBox.Show("Erro na Execucao da Funcao Sub Total!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                Declaracoes.iRetorno = Declaracoes.iCFTotalizarCupomPadrao_ECF_Daruma();
                Declaracoes.iRetorno = Declaracoes.iCFEfetuarPagamentoPadrao_ECF_Daruma();
                Declaracoes.iRetorno = Declaracoes.iCFEncerrarPadrao_ECF_Daruma();

                Int_ContaRamdom = 0;
                Int_Qtd_Cupom = (Int_Qtd_Cupom - 1);
            }//While do Cupom

            Str_TimeFinal = DateTime.Now.ToLongTimeString();
            LB_StatusEnvio.Items.Add("TIME FINAL = " + Str_TimeFinal.ToString());
            LB_StatusEnvio.Items.Add("  ");
            LB_StatusEnvio.Items.Add("  ");
            LB_StatusEnvio.Refresh();
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void bt_limpar_LstBox_Click(object sender, EventArgs e)
        {
            LB_StatusEnvio.Items.Clear();
        }

        private void bt_limpar_logs_Click(object sender, EventArgs e)
        {
            LB_LogDescricao.Items.Clear();
            LB_LogCodigo.Items.Clear();
        }

        private void bt_Recalcular_Click(object sender, EventArgs e)
        {
            StringBuilder Str_InformacaoMFD = new StringBuilder();
            string d;
            int Temp = 0;
            double x = 0;
            string Str_Informacao2;

            Declaracoes.iRetorno = Declaracoes.rVerificarImpressoraLigada_ECF_Daruma();
            if (Declaracoes.iRetorno != 1)
            {
                MessageBox.Show("ECF Desligado, verifique!", "Daruma_Framework_CSharp", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;   //retorna ao form principal
            }
            Declaracoes.iRetorno = Declaracoes.rRetornarInformacao_ECF_Daruma("103", Str_InformacaoMFD);
            Str_Informacao2 = Str_InformacaoMFD.ToString();
            Temp = (int.Parse(Str_Informacao2.Substring(0, 5)) / 100);
            x = (float.Parse(Str_Informacao2.Substring(0, 5)) / 100);
            this.PG_MFDPERCENT.Value = Temp;
            this.LB_MFDPERCENT.Text = ("MFD em % : " + x.ToString());
            Declaracoes.iRetorno = Declaracoes.rRetornarInformacao_ECF_Daruma("104", Str_InformacaoMFD);
            d = Str_InformacaoMFD.ToString();
            int i = int.Parse(d.Substring(0, 8), System.Globalization.NumberStyles.HexNumber); //transforma hexa para decimal(inteiro)
            this.LB_MFDBYTES.Text = (Math.Round((i * x) / 100) + " Bytes Restantes");

            this.LB_MFDBYTES.Refresh();
            this.LB_MFDBYTES.Refresh();
        }

        private void PerguntarLigada_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void FR_FISCAL_Teste_Consumo_MFD_Load(object sender, EventArgs e)
        {

        }
    }
}
