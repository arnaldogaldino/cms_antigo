﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_Registro : Form
    {
        public FR_Registro()
        {
            InitializeComponent();
        }

        private void BT_Cancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void TB_NomeProdutoChave_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Produto_Chave, Str_Valor_Produto_Chave;

            Str_Produto_Chave = TB_NomeProdutoChave.Text.Trim();
            Str_Valor_Produto_Chave = TB_ValorChave.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.regAlterarValor_Daruma(Str_Produto_Chave, Str_Valor_Produto_Chave);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            
        }
    }
}
