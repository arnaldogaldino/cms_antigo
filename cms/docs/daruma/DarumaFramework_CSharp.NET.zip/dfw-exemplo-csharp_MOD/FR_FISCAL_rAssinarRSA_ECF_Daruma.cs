﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rAssinarRSA_ECF_Daruma : Form
    {
        public FR_FISCAL_rAssinarRSA_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_CaminhoArquivo.Text = openFileDialog1.FileName;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
          
            
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void TB_ChavePrivada_TextChanged(object sender, EventArgs e)
        {

        }

        private void TB_PathArquivo_TextChanged(object sender, EventArgs e)
        {

        }

        private void BT_CaminhoArquivo_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_CaminhoArquivo.Text = openFileDialog1.FileName;
        }

        private void BT_CaminhoChavePrivada_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_CaminhoChavePrivada.Text = openFileDialog1.FileName;
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_CaminhoArquivo, Str_CaminhoChavePrivada;
            StringBuilder Str_Assinatura = new StringBuilder();
            Str_CaminhoArquivo = TB_CaminhoArquivo.Text.Trim();
            Str_CaminhoChavePrivada = TB_CaminhoChavePrivada.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.rAssinarRSA_ECF_Daruma(Str_CaminhoArquivo,Str_CaminhoChavePrivada, Str_Assinatura);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_Assinatura.Text = Str_Assinatura.ToString();
        }
    }
}
