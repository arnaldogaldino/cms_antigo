namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_tEnviarComando
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_Parametors = new System.Windows.Forms.Label();
            this.TB_ComandoEnviado = new System.Windows.Forms.TextBox();
            this.LB_TamanhoComando = new System.Windows.Forms.Label();
            this.TB_Tamanho = new System.Windows.Forms.TextBox();
            this.LB_NomeChave = new System.Windows.Forms.Label();
            this.TB_RespostaModem = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.LB_ComandoAT = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LB_Parametors
            // 
            this.LB_Parametors.AutoSize = true;
            this.LB_Parametors.Location = new System.Drawing.Point(13, 13);
            this.LB_Parametors.Name = "LB_Parametors";
            this.LB_Parametors.Size = new System.Drawing.Size(123, 13);
            this.LB_Parametors.TabIndex = 0;
            this.LB_Parametors.Text = "Comando a ser Enviado:";
            // 
            // TB_ComandoEnviado
            // 
            this.TB_ComandoEnviado.Location = new System.Drawing.Point(13, 30);
            this.TB_ComandoEnviado.Name = "TB_ComandoEnviado";
            this.TB_ComandoEnviado.Size = new System.Drawing.Size(292, 20);
            this.TB_ComandoEnviado.TabIndex = 1;
            this.TB_ComandoEnviado.Text = "AT+IPR?";
            // 
            // LB_TamanhoComando
            // 
            this.LB_TamanhoComando.AutoSize = true;
            this.LB_TamanhoComando.Location = new System.Drawing.Point(13, 200);
            this.LB_TamanhoComando.Name = "LB_TamanhoComando";
            this.LB_TamanhoComando.Size = new System.Drawing.Size(169, 13);
            this.LB_TamanhoComando.TabIndex = 2;
            this.LB_TamanhoComando.Text = "Tamanho da Resposta, retornada:";
            // 
            // TB_Tamanho
            // 
            this.TB_Tamanho.Location = new System.Drawing.Point(16, 216);
            this.TB_Tamanho.Name = "TB_Tamanho";
            this.TB_Tamanho.Size = new System.Drawing.Size(69, 20);
            this.TB_Tamanho.TabIndex = 3;
            this.TB_Tamanho.Text = "250";
            // 
            // LB_NomeChave
            // 
            this.LB_NomeChave.AutoSize = true;
            this.LB_NomeChave.Location = new System.Drawing.Point(13, 86);
            this.LB_NomeChave.Name = "LB_NomeChave";
            this.LB_NomeChave.Size = new System.Drawing.Size(189, 13);
            this.LB_NomeChave.TabIndex = 4;
            this.LB_NomeChave.Text = "Resposta do Modem, apos conclusao:";
            // 
            // TB_RespostaModem
            // 
            this.TB_RespostaModem.Location = new System.Drawing.Point(16, 102);
            this.TB_RespostaModem.Multiline = true;
            this.TB_RespostaModem.Name = "TB_RespostaModem";
            this.TB_RespostaModem.ReadOnly = true;
            this.TB_RespostaModem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_RespostaModem.Size = new System.Drawing.Size(186, 86);
            this.TB_RespostaModem.TabIndex = 5;
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(230, 174);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 6;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(230, 211);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 7;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // LB_ComandoAT
            // 
            this.LB_ComandoAT.AutoSize = true;
            this.LB_ComandoAT.Location = new System.Drawing.Point(83, 53);
            this.LB_ComandoAT.Name = "LB_ComandoAT";
            this.LB_ComandoAT.Size = new System.Drawing.Size(222, 13);
            this.LB_ComandoAT.TabIndex = 8;
            this.LB_ComandoAT.Text = "Ex.: Verifica a Velocidade da Serial: AT+IPR?";
            // 
            // FR_MODEM_tEnviarComando
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(317, 246);
            this.Controls.Add(this.LB_ComandoAT);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_RespostaModem);
            this.Controls.Add(this.LB_NomeChave);
            this.Controls.Add(this.TB_Tamanho);
            this.Controls.Add(this.LB_TamanhoComando);
            this.Controls.Add(this.TB_ComandoEnviado);
            this.Controls.Add(this.LB_Parametors);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MODEM_tEnviarComando";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "M�todo Para Envio de Comandos";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_Parametors;
        private System.Windows.Forms.TextBox TB_ComandoEnviado;
        private System.Windows.Forms.Label LB_TamanhoComando;
        private System.Windows.Forms.TextBox TB_Tamanho;
        private System.Windows.Forms.Label LB_NomeChave;
        private System.Windows.Forms.TextBox TB_RespostaModem;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Label LB_ComandoAT;
    }
}