﻿namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_rRetornarImei_MODEM_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_IMEI = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BT_IMEI = new System.Windows.Forms.Button();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TB_IMEI
            // 
            this.TB_IMEI.Location = new System.Drawing.Point(12, 32);
            this.TB_IMEI.Name = "TB_IMEI";
            this.TB_IMEI.Size = new System.Drawing.Size(241, 20);
            this.TB_IMEI.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "IMEI:";
            // 
            // BT_IMEI
            // 
            this.BT_IMEI.Location = new System.Drawing.Point(12, 58);
            this.BT_IMEI.Name = "BT_IMEI";
            this.BT_IMEI.Size = new System.Drawing.Size(75, 23);
            this.BT_IMEI.TabIndex = 2;
            this.BT_IMEI.Text = "Obter IMEI";
            this.BT_IMEI.UseVisualStyleBackColor = true;
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(93, 58);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(75, 23);
            this.BT_Limpar.TabIndex = 3;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(178, 58);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 4;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            // 
            // FR_MODEM_rRetornarImei_MODEM_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 95);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.BT_IMEI);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_IMEI);
            this.Name = "FR_MODEM_rRetornarImei_MODEM_DarumaFramework";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_IMEI;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BT_IMEI;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.Button BT_Fechar;
    }
}