﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma : Form
    {
        public FR_FISCAL_eTEF_EsperarArquivo_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_LocalArquivos_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            string Str_LocalArquivos = openFileDialog1.FileName.ToString();

            TB_pathArquivoTEF.Text = Str_LocalArquivos;
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            String Str_Path_Arquivo_Resp_TEF, Str_TempoEspera;
            Str_Path_Arquivo_Resp_TEF = TB_pathArquivoTEF.Text.Trim();
            Str_TempoEspera = TB_Tempo.Text.Trim();
            
            if (RB_Sim.Checked == true )
            {
                Declaracoes.iRetorno = Declaracoes.eTEF_EsperarArquivo_ECF_Daruma(Str_Path_Arquivo_Resp_TEF, int.Parse(Str_TempoEspera), true);
               Declaracoes.TrataRetorno(Declaracoes.iRetorno);
            } else 
                  {
                      Declaracoes.iRetorno = Declaracoes.eTEF_EsperarArquivo_ECF_Daruma(Str_Path_Arquivo_Resp_TEF, int.Parse(Str_TempoEspera), false);
                      Declaracoes.TrataRetorno(Declaracoes.iRetorno);
                  }

        }
    }
}
