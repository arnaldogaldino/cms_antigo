﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCNFReceberSemDesc_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblIndice = new System.Windows.Forms.Label();
            this.TB_Valor = new System.Windows.Forms.TextBox();
            this.CBO_Indice = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(164, 64);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 106;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(70, 64);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 105;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 104;
            this.label2.Text = "Valor";
            // 
            // lblIndice
            // 
            this.lblIndice.AutoSize = true;
            this.lblIndice.Location = new System.Drawing.Point(13, 11);
            this.lblIndice.Name = "lblIndice";
            this.lblIndice.Size = new System.Drawing.Size(36, 13);
            this.lblIndice.TabIndex = 103;
            this.lblIndice.Text = "Indice";
            // 
            // TB_Valor
            // 
            this.TB_Valor.Location = new System.Drawing.Point(72, 35);
            this.TB_Valor.Name = "TB_Valor";
            this.TB_Valor.Size = new System.Drawing.Size(100, 20);
            this.TB_Valor.TabIndex = 102;
            this.TB_Valor.Text = "1,00";
            // 
            // CBO_Indice
            // 
            this.CBO_Indice.FormattingEnabled = true;
            this.CBO_Indice.Items.AddRange(new object[] {
            "03",
            "04",
            "05",
            "06",
            "07",
            "08",
            "09",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.CBO_Indice.Location = new System.Drawing.Point(72, 8);
            this.CBO_Indice.Name = "CBO_Indice";
            this.CBO_Indice.Size = new System.Drawing.Size(55, 21);
            this.CBO_Indice.TabIndex = 101;
            // 
            // FR_FISCAL_iCNFReceberSemDesc_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(246, 91);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblIndice);
            this.Controls.Add(this.TB_Valor);
            this.Controls.Add(this.CBO_Indice);
            this.Name = "FR_FISCAL_iCNFReceberSemDesc_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCNFReceberSemDesc_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblIndice;
        private System.Windows.Forms.TextBox TB_Valor;
        private System.Windows.Forms.ComboBox CBO_Indice;
    }
}