﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_rRSAChavePublica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TB_ExpoentePublico = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BT_CaminhoChavePrivada = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_ChavePublica = new System.Windows.Forms.TextBox();
            this.TB_CaminhoChavePrivada = new System.Windows.Forms.TextBox();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TB_ExpoentePublico);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.BT_CaminhoChavePrivada);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TB_ChavePublica);
            this.groupBox1.Controls.Add(this.TB_CaminhoChavePrivada);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(475, 222);
            this.groupBox1.TabIndex = 89;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Assinando Arquivos:";
            // 
            // TB_ExpoentePublico
            // 
            this.TB_ExpoentePublico.Location = new System.Drawing.Point(9, 176);
            this.TB_ExpoentePublico.Name = "TB_ExpoentePublico";
            this.TB_ExpoentePublico.Size = new System.Drawing.Size(419, 20);
            this.TB_ExpoentePublico.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 160);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Expoente publico:";
            // 
            // BT_CaminhoChavePrivada
            // 
            this.BT_CaminhoChavePrivada.Location = new System.Drawing.Point(434, 41);
            this.BT_CaminhoChavePrivada.Name = "BT_CaminhoChavePrivada";
            this.BT_CaminhoChavePrivada.Size = new System.Drawing.Size(25, 23);
            this.BT_CaminhoChavePrivada.TabIndex = 11;
            this.BT_CaminhoChavePrivada.Text = "...";
            this.BT_CaminhoChavePrivada.UseVisualStyleBackColor = true;
            this.BT_CaminhoChavePrivada.Click += new System.EventHandler(this.BT_CaminhoChavePrivada_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Chave Publica:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Caminho da chave privada gerada pelo puttyGen:";
            // 
            // TB_ChavePublica
            // 
            this.TB_ChavePublica.Location = new System.Drawing.Point(9, 82);
            this.TB_ChavePublica.Multiline = true;
            this.TB_ChavePublica.Name = "TB_ChavePublica";
            this.TB_ChavePublica.Size = new System.Drawing.Size(420, 75);
            this.TB_ChavePublica.TabIndex = 3;
            // 
            // TB_CaminhoChavePrivada
            // 
            this.TB_CaminhoChavePrivada.Location = new System.Drawing.Point(9, 43);
            this.TB_CaminhoChavePrivada.Name = "TB_CaminhoChavePrivada";
            this.TB_CaminhoChavePrivada.Size = new System.Drawing.Size(419, 20);
            this.TB_CaminhoChavePrivada.TabIndex = 4;
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(400, 240);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 88;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(319, 240);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(77, 23);
            this.BT_Enviar.TabIndex = 87;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // FR_FISCAL_rRSAChavePublica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 275);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_rRSAChavePublica";
            this.Text = "FR_FISCAL_rRSAChavePublica";
            this.Load += new System.EventHandler(this.FR_FISCAL_rRSAChavePublica_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BT_CaminhoChavePrivada;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_ChavePublica;
        private System.Windows.Forms.TextBox TB_CaminhoChavePrivada;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_ExpoentePublico;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}