﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rCalcularMD5_ECF_Daruma : Form
    {
        public FR_FISCAL_rCalcularMD5_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void BT_Voltar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Calcular_Click(object sender, EventArgs e)
        {
            string Str_Caminho;
            StringBuilder Str_MD5HEX = new StringBuilder(300);
            StringBuilder Str_MD5Ascii = new StringBuilder(300);

            Str_Caminho = TB_Caminho.Text.Trim();
            
            Declaracoes.iRetorno = Declaracoes.rCalcularMD5_ECF_Daruma(Str_Caminho,Str_MD5HEX,Str_MD5Ascii);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_MD5Hex.Text = Str_MD5HEX.ToString();
            TB_MD5Ascii.Text = Str_MD5Ascii.ToString(); 
        }

        private void BT_LocalArquivos_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            TB_Caminho.Text = openFileDialog1.FileName.ToString();
        }
    }
}
