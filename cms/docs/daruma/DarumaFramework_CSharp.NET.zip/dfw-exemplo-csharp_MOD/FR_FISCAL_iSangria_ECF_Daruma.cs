﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iSangria_ECF_Daruma : Form
    {
        public FR_FISCAL_iSangria_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Valor, Str_Mensagem;

            Str_Valor = TB_Valor.Text.Trim();
            Str_Mensagem = TB_Mensagem.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iSangria_ECF_Daruma(Str_Valor, Str_Mensagem);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void TB_Mensagem_TextChanged(object sender, EventArgs e)
        {

        }

        private void TB_Valor_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
