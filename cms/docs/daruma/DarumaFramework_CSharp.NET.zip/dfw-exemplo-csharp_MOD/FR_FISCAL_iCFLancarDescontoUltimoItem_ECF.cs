﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFLancarDescontoUltimoItem_ECF : Form
    {
        public FR_FISCAL_iCFLancarDescontoUltimoItem_ECF()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_ValorDescAcresc, Str_TipoDescAcresc;

            Str_ValorDescAcresc = TB_ValorDescAcresc.Text.Trim();
            Str_TipoDescAcresc = TB_Tipo_Desc_Acresc.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCFLancarDescontoUltimoItem_ECF_Daruma(Str_TipoDescAcresc, Str_ValorDescAcresc);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void TB_ValorDescAcresc_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void TB_Tipo_Desc_Acresc_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
