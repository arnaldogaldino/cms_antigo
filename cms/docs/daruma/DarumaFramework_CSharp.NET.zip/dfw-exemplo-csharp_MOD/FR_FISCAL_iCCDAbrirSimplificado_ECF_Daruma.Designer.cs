﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.TB_Valor = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TB_DocOrigem = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TB_Parcelas = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TB_FormaPagto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(260, 133);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 31;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(179, 133);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 30;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // TB_Valor
            // 
            this.TB_Valor.Location = new System.Drawing.Point(118, 107);
            this.TB_Valor.Name = "TB_Valor";
            this.TB_Valor.Size = new System.Drawing.Size(217, 20);
            this.TB_Valor.TabIndex = 23;
            this.TB_Valor.Text = "1,00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Valor:";
            // 
            // TB_DocOrigem
            // 
            this.TB_DocOrigem.Location = new System.Drawing.Point(118, 81);
            this.TB_DocOrigem.Name = "TB_DocOrigem";
            this.TB_DocOrigem.Size = new System.Drawing.Size(217, 20);
            this.TB_DocOrigem.TabIndex = 21;
            this.TB_DocOrigem.Text = "999999";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Doc.Origem:";
            // 
            // TB_Parcelas
            // 
            this.TB_Parcelas.Location = new System.Drawing.Point(118, 55);
            this.TB_Parcelas.Name = "TB_Parcelas";
            this.TB_Parcelas.Size = new System.Drawing.Size(217, 20);
            this.TB_Parcelas.TabIndex = 19;
            this.TB_Parcelas.Text = "01";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(56, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Parcelas:";
            // 
            // TB_FormaPagto
            // 
            this.TB_FormaPagto.Location = new System.Drawing.Point(118, 29);
            this.TB_FormaPagto.Name = "TB_FormaPagto";
            this.TB_FormaPagto.Size = new System.Drawing.Size(217, 20);
            this.TB_FormaPagto.TabIndex = 17;
            this.TB_FormaPagto.Text = "Cartao";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Forma Pagamento:";
            // 
            // FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 170);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_Valor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TB_DocOrigem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TB_Parcelas);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TB_FormaPagto);
            this.Controls.Add(this.label1);
            this.Name = "FR_FISCAL_iCCDAbrirSimplificado_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCCDAbrirSimplificado_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.TextBox TB_Valor;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TB_DocOrigem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TB_Parcelas;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TB_FormaPagto;
        private System.Windows.Forms.Label label1;
    }
}