namespace DarumaFramework_CSharp
{
    partial class FR_DarumaFramework_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PN_Principal = new System.Windows.Forms.Panel();
            this.LB_DLL = new System.Windows.Forms.Label();
            this.LB_CSharp = new System.Windows.Forms.Label();
            this.LB_DarumaFramework = new System.Windows.Forms.Label();
            this.PB_DDC = new System.Windows.Forms.PictureBox();
            this.GB_TA2000 = new System.Windows.Forms.GroupBox();
            this.BT_TA2000 = new System.Windows.Forms.Button();
            this.GB_Fiscais = new System.Windows.Forms.GroupBox();
            this.BT_Fiscal = new System.Windows.Forms.Button();
            this.GB_NFiscal = new System.Windows.Forms.GroupBox();
            this.BT_NFiscal = new System.Windows.Forms.Button();
            this.GB_Modens = new System.Windows.Forms.GroupBox();
            this.BT_Min200 = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_HelpOnline = new System.Windows.Forms.Button();
            this.PN_Principal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).BeginInit();
            this.GB_TA2000.SuspendLayout();
            this.GB_Fiscais.SuspendLayout();
            this.GB_NFiscal.SuspendLayout();
            this.GB_Modens.SuspendLayout();
            this.SuspendLayout();
            // 
            // PN_Principal
            // 
            this.PN_Principal.BackColor = System.Drawing.Color.White;
            this.PN_Principal.Controls.Add(this.LB_DLL);
            this.PN_Principal.Controls.Add(this.LB_CSharp);
            this.PN_Principal.Controls.Add(this.LB_DarumaFramework);
            this.PN_Principal.Controls.Add(this.PB_DDC);
            this.PN_Principal.Location = new System.Drawing.Point(2, 2);
            this.PN_Principal.Name = "PN_Principal";
            this.PN_Principal.Size = new System.Drawing.Size(546, 138);
            this.PN_Principal.TabIndex = 0;
            // 
            // LB_DLL
            // 
            this.LB_DLL.AutoSize = true;
            this.LB_DLL.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DLL.Location = new System.Drawing.Point(11, 110);
            this.LB_DLL.Name = "LB_DLL";
            this.LB_DLL.Size = new System.Drawing.Size(248, 18);
            this.LB_DLL.TabIndex = 3;
            this.LB_DLL.Text = "DLL: DarumaFramework.dll";
            // 
            // LB_CSharp
            // 
            this.LB_CSharp.AutoSize = true;
            this.LB_CSharp.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_CSharp.Location = new System.Drawing.Point(11, 39);
            this.LB_CSharp.Name = "LB_CSharp";
            this.LB_CSharp.Size = new System.Drawing.Size(280, 18);
            this.LB_CSharp.TabIndex = 2;
            this.LB_CSharp.Text = "C# - Versao 2.5.0 - 16/12/011";
            // 
            // LB_DarumaFramework
            // 
            this.LB_DarumaFramework.AutoSize = true;
            this.LB_DarumaFramework.Font = new System.Drawing.Font("Verdana", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LB_DarumaFramework.Location = new System.Drawing.Point(10, 7);
            this.LB_DarumaFramework.Name = "LB_DarumaFramework";
            this.LB_DarumaFramework.Size = new System.Drawing.Size(223, 23);
            this.LB_DarumaFramework.TabIndex = 1;
            this.LB_DarumaFramework.Text = "Daruma Framework";
            // 
            // PB_DDC
            // 
            this.PB_DDC.Image = global::DarumaFramework_CSharp.Properties.Resources.logoDDCpeq2;
            this.PB_DDC.Location = new System.Drawing.Point(341, 21);
            this.PB_DDC.Name = "PB_DDC";
            this.PB_DDC.Size = new System.Drawing.Size(189, 81);
            this.PB_DDC.TabIndex = 0;
            this.PB_DDC.TabStop = false;
            // 
            // GB_TA2000
            // 
            this.GB_TA2000.Controls.Add(this.BT_TA2000);
            this.GB_TA2000.Location = new System.Drawing.Point(4, 146);
            this.GB_TA2000.Name = "GB_TA2000";
            this.GB_TA2000.Size = new System.Drawing.Size(124, 94);
            this.GB_TA2000.TabIndex = 1;
            this.GB_TA2000.TabStop = false;
            this.GB_TA2000.Text = "Terminais:";
            // 
            // BT_TA2000
            // 
            this.BT_TA2000.Location = new System.Drawing.Point(12, 28);
            this.BT_TA2000.Name = "BT_TA2000";
            this.BT_TA2000.Size = new System.Drawing.Size(98, 41);
            this.BT_TA2000.TabIndex = 0;
            this.BT_TA2000.Text = "&TA2000";
            this.BT_TA2000.UseVisualStyleBackColor = true;
            this.BT_TA2000.Click += new System.EventHandler(this.BT_TA2000_Click);
            // 
            // GB_Fiscais
            // 
            this.GB_Fiscais.Controls.Add(this.BT_Fiscal);
            this.GB_Fiscais.Location = new System.Drawing.Point(137, 146);
            this.GB_Fiscais.Name = "GB_Fiscais";
            this.GB_Fiscais.Size = new System.Drawing.Size(124, 94);
            this.GB_Fiscais.TabIndex = 2;
            this.GB_Fiscais.TabStop = false;
            this.GB_Fiscais.Text = "Impressoras Fiscal:";
            // 
            // BT_Fiscal
            // 
            this.BT_Fiscal.Location = new System.Drawing.Point(13, 27);
            this.BT_Fiscal.Name = "BT_Fiscal";
            this.BT_Fiscal.Size = new System.Drawing.Size(98, 41);
            this.BT_Fiscal.TabIndex = 1;
            this.BT_Fiscal.Text = "Impressoras &Fiscal";
            this.BT_Fiscal.UseVisualStyleBackColor = true;
            this.BT_Fiscal.Click += new System.EventHandler(this.BT_Fiscal_Click);
            // 
            // GB_NFiscal
            // 
            this.GB_NFiscal.Controls.Add(this.BT_NFiscal);
            this.GB_NFiscal.Location = new System.Drawing.Point(267, 146);
            this.GB_NFiscal.Name = "GB_NFiscal";
            this.GB_NFiscal.Size = new System.Drawing.Size(135, 94);
            this.GB_NFiscal.TabIndex = 3;
            this.GB_NFiscal.TabStop = false;
            this.GB_NFiscal.Text = "Impressoras N�o-Fiscal:";
            // 
            // BT_NFiscal
            // 
            this.BT_NFiscal.Location = new System.Drawing.Point(22, 28);
            this.BT_NFiscal.Name = "BT_NFiscal";
            this.BT_NFiscal.Size = new System.Drawing.Size(98, 41);
            this.BT_NFiscal.TabIndex = 1;
            this.BT_NFiscal.Text = "&Impressoras DUAL";
            this.BT_NFiscal.UseVisualStyleBackColor = true;
            this.BT_NFiscal.Click += new System.EventHandler(this.BT_NFiscal_Click);
            // 
            // GB_Modens
            // 
            this.GB_Modens.Controls.Add(this.BT_Min200);
            this.GB_Modens.Location = new System.Drawing.Point(408, 146);
            this.GB_Modens.Name = "GB_Modens";
            this.GB_Modens.Size = new System.Drawing.Size(124, 94);
            this.GB_Modens.TabIndex = 2;
            this.GB_Modens.TabStop = false;
            this.GB_Modens.Text = "Modem:";
            // 
            // BT_Min200
            // 
            this.BT_Min200.Location = new System.Drawing.Point(15, 28);
            this.BT_Min200.Name = "BT_Min200";
            this.BT_Min200.Size = new System.Drawing.Size(97, 41);
            this.BT_Min200.TabIndex = 2;
            this.BT_Min200.Text = "&MODEM";
            this.BT_Min200.UseVisualStyleBackColor = true;
            this.BT_Min200.Click += new System.EventHandler(this.BT_Min200_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(430, 246);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(102, 24);
            this.BT_Fechar.TabIndex = 4;
            this.BT_Fechar.Text = "&Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_HelpOnline
            // 
            this.BT_HelpOnline.Location = new System.Drawing.Point(4, 248);
            this.BT_HelpOnline.Name = "BT_HelpOnline";
            this.BT_HelpOnline.Size = new System.Drawing.Size(90, 22);
            this.BT_HelpOnline.TabIndex = 5;
            this.BT_HelpOnline.Text = "Help OnLine";
            this.BT_HelpOnline.UseVisualStyleBackColor = true;
            this.BT_HelpOnline.Click += new System.EventHandler(this.BT_HelpOnline_Click);
            // 
            // FR_DarumaFramework_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 278);
            this.Controls.Add(this.BT_HelpOnline);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.GB_Modens);
            this.Controls.Add(this.GB_NFiscal);
            this.Controls.Add(this.GB_Fiscais);
            this.Controls.Add(this.GB_TA2000);
            this.Controls.Add(this.PN_Principal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DarumaFramework_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Daruma Framework - C#                                        DDC - Daruma Develop" +
                "er Community";
            this.Load += new System.EventHandler(this.FR_DarumaFramework_Principal_Load);
            this.PN_Principal.ResumeLayout(false);
            this.PN_Principal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PB_DDC)).EndInit();
            this.GB_TA2000.ResumeLayout(false);
            this.GB_Fiscais.ResumeLayout(false);
            this.GB_NFiscal.ResumeLayout(false);
            this.GB_Modens.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PN_Principal;
        private System.Windows.Forms.Label LB_DLL;
        private System.Windows.Forms.Label LB_CSharp;
        private System.Windows.Forms.Label LB_DarumaFramework;
        private System.Windows.Forms.PictureBox PB_DDC;
        private System.Windows.Forms.GroupBox GB_TA2000;
        private System.Windows.Forms.GroupBox GB_Fiscais;
        private System.Windows.Forms.GroupBox GB_NFiscal;
        private System.Windows.Forms.GroupBox GB_Modens;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_HelpOnline;
        private System.Windows.Forms.Button BT_TA2000;
        private System.Windows.Forms.Button BT_NFiscal;
        private System.Windows.Forms.Button BT_Min200;
        private System.Windows.Forms.Button BT_Fiscal;
    }
}

