namespace DarumaFramework_CSharp
{
    partial class FR_DarumaFramework_InputBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.LB_stringInputBox = new System.Windows.Forms.Label();
            this.TB_ComandoInputBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(330, 9);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(66, 24);
            this.BT_Enviar.TabIndex = 21;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(330, 39);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(66, 24);
            this.BT_Fechar.TabIndex = 20;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // LB_stringInputBox
            // 
            this.LB_stringInputBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.LB_stringInputBox.Location = new System.Drawing.Point(1, 9);
            this.LB_stringInputBox.Name = "LB_stringInputBox";
            this.LB_stringInputBox.Size = new System.Drawing.Size(323, 75);
            this.LB_stringInputBox.TabIndex = 19;
            this.LB_stringInputBox.Text = "label1";
            this.LB_stringInputBox.Click += new System.EventHandler(this.LB_stringInputBox_Click);
            // 
            // TB_ComandoInputBox
            // 
            this.TB_ComandoInputBox.Location = new System.Drawing.Point(4, 84);
            this.TB_ComandoInputBox.Name = "TB_ComandoInputBox";
            this.TB_ComandoInputBox.Size = new System.Drawing.Size(392, 20);
            this.TB_ComandoInputBox.TabIndex = 18;
            // 
            // FR_DarumaFramework_InputBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 111);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.LB_stringInputBox);
            this.Controls.Add(this.TB_ComandoInputBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DarumaFramework_InputBox";
            this.Text = "Daruma DLL Framework";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button BT_Enviar;
        internal System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Label LB_stringInputBox;
        private System.Windows.Forms.TextBox TB_ComandoInputBox;
    }
}