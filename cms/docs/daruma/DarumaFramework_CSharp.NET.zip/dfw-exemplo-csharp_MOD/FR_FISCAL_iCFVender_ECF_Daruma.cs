﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFVender_ECF_Daruma : Form
    {
        public FR_FISCAL_iCFVender_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_Aliquota, Str_Qtde, Str_ValorUnit;
            string Str_Tipo_Desc_Acresc, Str_Valor_Desc_Acrec;
            string Str_Codigo_Item, Str_UnidadeMedida, Str_Descricao;

            Str_Aliquota = TB_Aliquota.Text.Trim();
            Str_Qtde = TB_Qtde.Text.Trim();
            Str_ValorUnit = TB_ValorUnitario.Text.Trim();
            Str_Tipo_Desc_Acresc = TB_TipoDesc_Acresc.Text.Trim();
            Str_Valor_Desc_Acrec = TB_Valor_Desc_Acresc.Text.Trim();
            Str_Codigo_Item = TB_Codigo_Item.Text.Trim();
            Str_UnidadeMedida = TB_Unidade_Medida.Text.Trim();
            Str_Descricao = TB_Descricao.Text.Trim();
            
            Declaracoes.iRetorno = Declaracoes.iCFVender_ECF_Daruma(Str_Aliquota, Str_Qtde, Str_ValorUnit, Str_Tipo_Desc_Acresc, Str_Valor_Desc_Acrec, Str_Codigo_Item, Str_UnidadeMedida, Str_Descricao);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

        }
    }
}
