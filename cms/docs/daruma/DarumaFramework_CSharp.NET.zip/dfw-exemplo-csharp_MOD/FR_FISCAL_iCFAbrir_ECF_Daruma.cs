﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFAbrir_ECF_Daruma : Form
    {
        public FR_FISCAL_iCFAbrir_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string Str_CPF_CNPJ, Str_Nome, Str_Endereco;

            Str_CPF_CNPJ = TB_CPF_CNPJ.Text.Trim();
            Str_Nome = TB_Nome.Text.Trim();
            Str_Endereco = TB_Endereço.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCFAbrir_ECF_Daruma(Str_CPF_CNPJ, Str_Nome, Str_Endereco);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
