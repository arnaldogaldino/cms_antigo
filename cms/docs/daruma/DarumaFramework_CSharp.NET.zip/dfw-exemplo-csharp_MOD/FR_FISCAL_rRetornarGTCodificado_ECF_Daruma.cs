﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_rRetornarGTCodificado_ECF_Daruma : Form
    {
        public FR_FISCAL_rRetornarGTCodificado_ECF_Daruma()
        {
            InitializeComponent();
        }

        private void BT_Voltar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StringBuilder Str_GTCodificado = new StringBuilder(38);
            Declaracoes.iRetorno = Declaracoes.rRetornarGTCodificado_ECF_Daruma(Str_GTCodificado);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);

            TB_GTCodificado.Text = Str_GTCodificado.ToString();
        }
    }
}
