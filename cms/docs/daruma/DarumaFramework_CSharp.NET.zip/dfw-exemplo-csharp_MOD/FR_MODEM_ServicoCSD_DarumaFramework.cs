﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_ServicoCSD_DarumaFramework : Form
    {
        public FR_MODEM_ServicoCSD_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_eAtivarConexaoCsd_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eAtivarConexaoCsd_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Conexao ativa com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao tentar ativar a conexao CSD.", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void BT_eRealizarChamadaCsd_Click(object sender, EventArgs e)
        {
            int iNumeroFone;

            iNumeroFone = 0;

            if (ED_NumTelefone.Text == "" || int.Parse(ED_NumTelefone.Text) == 0)
            {
                MessageBox.Show("É preciso digitar o numero do telefone diferente de 0", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                iNumeroFone = int.Parse(ED_NumTelefone.Text);
                
            }

            Declaracoes.iRetorno = Declaracoes.eRealizarChamadaCsd_MODEM_DarumaFramework(iNumeroFone.ToString());
            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Chamada Realizada com sucesso.!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ED_RetornoDeFuncoes.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao Realizar chamada!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ED_RetornoDeFuncoes.Text = Declaracoes.iRetorno.ToString();
            }

        }

        private void BT_eFinalizarChamadaCsd_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.eFinalizarChamadaCsd_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno == 1)
            {
                MessageBox.Show("Conexao Finalizada com sucesso!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Erro ao tentar Finalizar a conexao CSD!", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BT_tEnviarDadosCsd_Click(object sender, EventArgs e)
        {
            string sDados = ED_dadosEnviados.Text;
            Declaracoes.iRetorno = Declaracoes.tEnviarDadosCsd_MODEM_DarumaFramework(sDados);

            if (Declaracoes.iRetorno == 1)
            {
          
                ED_RetornoDeFuncoes.Text = Declaracoes.iRetorno.ToString();
            }
            else
            {
                MessageBox.Show("Erro ao tentar enviar Dados", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -1: ED_RetornoDeFuncoes.Text = "[-1] - Erro de comunicação serial";
                        break;
                }
            }
        }

        private void BT_rReceberDadosCsd_Click(object sender, EventArgs e)
        {
            string sDados = new string(' ', 100);

            Declaracoes.iRetorno = Declaracoes.rReceberDadosCsd_MODEM_DarumaFramework(sDados);

            if (Declaracoes.iRetorno == 1)
            {
                ED_DadosRecebidos.Text = sDados;
                ED_RetornoDeFuncoes.Text = Declaracoes.iRetorno.ToString(); 
            }
            else
            {
                MessageBox.Show("Erro ao tentar receber Dados", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -1: ED_RetornoDeFuncoes.Text = "[-1] - Erro de comunicação serial";
                        break;
                }
            }
        }

        private void BT_limparEnvio_Click(object sender, EventArgs e)
        {
            ED_RetornoDeFuncoes.Text = "";
            ED_dadosEnviados.Text = "";
        }

        private void BT_limparRecebe_Click(object sender, EventArgs e)
        {
        ED_RetornoDeFuncoes.Text = "";
        ED_DadosRecebidos.Text = "";
        }

        private void BT_limparRetorno_Click(object sender, EventArgs e)
        {
            ED_RetornoDeFuncoes.Text = "";
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
