﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_iCFBPVender_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_Descricao = new System.Windows.Forms.TextBox();
            this.TB_Aliquota = new System.Windows.Forms.TextBox();
            this.TB_Valor = new System.Windows.Forms.TextBox();
            this.CBO_TipoAcrescDesc = new System.Windows.Forms.ComboBox();
            this.TB_ValorAcrescDesc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TB_Descricao
            // 
            this.TB_Descricao.Location = new System.Drawing.Point(160, 8);
            this.TB_Descricao.Name = "TB_Descricao";
            this.TB_Descricao.Size = new System.Drawing.Size(233, 20);
            this.TB_Descricao.TabIndex = 0;
            this.TB_Descricao.Text = "Bagagem";
            // 
            // TB_Aliquota
            // 
            this.TB_Aliquota.Location = new System.Drawing.Point(160, 34);
            this.TB_Aliquota.Name = "TB_Aliquota";
            this.TB_Aliquota.Size = new System.Drawing.Size(100, 20);
            this.TB_Aliquota.TabIndex = 0;
            this.TB_Aliquota.Text = "II";
            // 
            // TB_Valor
            // 
            this.TB_Valor.Location = new System.Drawing.Point(160, 60);
            this.TB_Valor.Name = "TB_Valor";
            this.TB_Valor.Size = new System.Drawing.Size(100, 20);
            this.TB_Valor.TabIndex = 0;
            this.TB_Valor.Text = "5,00";
            // 
            // CBO_TipoAcrescDesc
            // 
            this.CBO_TipoAcrescDesc.FormattingEnabled = true;
            this.CBO_TipoAcrescDesc.Items.AddRange(new object[] {
            "D%",
            "D$",
            "A%",
            "A$"});
            this.CBO_TipoAcrescDesc.Location = new System.Drawing.Point(160, 86);
            this.CBO_TipoAcrescDesc.Name = "CBO_TipoAcrescDesc";
            this.CBO_TipoAcrescDesc.Size = new System.Drawing.Size(121, 21);
            this.CBO_TipoAcrescDesc.TabIndex = 1;
            this.CBO_TipoAcrescDesc.Text = "D%";
            // 
            // TB_ValorAcrescDesc
            // 
            this.TB_ValorAcrescDesc.Location = new System.Drawing.Point(160, 113);
            this.TB_ValorAcrescDesc.Name = "TB_ValorAcrescDesc";
            this.TB_ValorAcrescDesc.Size = new System.Drawing.Size(100, 20);
            this.TB_ValorAcrescDesc.TabIndex = 2;
            this.TB_ValorAcrescDesc.Text = "0,10";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(91, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Descrição:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Valor:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tipo Acrescimo/Desconto:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Valor Acrescimo/Desconto:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(50, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Situação Tributária:";
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(318, 160);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 7;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(237, 160);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(75, 23);
            this.BT_Enviar.TabIndex = 6;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // FR_FISCAL_iCFBPVender_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(402, 190);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_ValorAcrescDesc);
            this.Controls.Add(this.CBO_TipoAcrescDesc);
            this.Controls.Add(this.TB_Valor);
            this.Controls.Add(this.TB_Aliquota);
            this.Controls.Add(this.TB_Descricao);
            this.Name = "FR_FISCAL_iCFBPVender_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "iCFBPVender_ECF_Daruma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_Descricao;
        private System.Windows.Forms.TextBox TB_Aliquota;
        private System.Windows.Forms.TextBox TB_Valor;
        private System.Windows.Forms.ComboBox CBO_TipoAcrescDesc;
        private System.Windows.Forms.TextBox TB_ValorAcrescDesc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
    }
}