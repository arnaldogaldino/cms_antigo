﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_FISCAL_iCFIdentificarConsumidor_ECF : Form
    {
        public FR_FISCAL_iCFIdentificarConsumidor_ECF()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BT_Enviar_Click(object sender, EventArgs e)
        {
            string  Str_Nome, Str_Endereco, Str_Documento;

            Str_Nome = TB_Nome.Text.Trim();
            Str_Endereco = TB_Endereço.Text.Trim();
            Str_Documento = TB_Documento.Text.Trim();

            Declaracoes.iRetorno = Declaracoes.iCFIdentificarConsumidor_ECF_Daruma(Str_Nome, Str_Endereco, Str_Documento);
            Declaracoes.TrataRetorno(Declaracoes.iRetorno);
        }
    }
}
