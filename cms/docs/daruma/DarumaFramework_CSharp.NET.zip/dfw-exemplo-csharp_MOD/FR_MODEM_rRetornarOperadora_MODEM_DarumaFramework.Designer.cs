﻿namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.BT_Operadora = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Operadora = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(178, 59);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 9;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(93, 59);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(75, 23);
            this.BT_Limpar.TabIndex = 8;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Limpar_Click);
            // 
            // BT_Operadora
            // 
            this.BT_Operadora.Location = new System.Drawing.Point(12, 59);
            this.BT_Operadora.Name = "BT_Operadora";
            this.BT_Operadora.Size = new System.Drawing.Size(75, 23);
            this.BT_Operadora.TabIndex = 7;
            this.BT_Operadora.Text = "Operadora";
            this.BT_Operadora.UseVisualStyleBackColor = true;
            this.BT_Operadora.Click += new System.EventHandler(this.BT_Operadora_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Operadora:";
            // 
            // TB_Operadora
            // 
            this.TB_Operadora.Location = new System.Drawing.Point(12, 33);
            this.TB_Operadora.Name = "TB_Operadora";
            this.TB_Operadora.Size = new System.Drawing.Size(241, 20);
            this.TB_Operadora.TabIndex = 5;
            // 
            // FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(263, 97);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.BT_Operadora);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Operadora);
            this.Name = "FR_MODEM_rRetornarOperadora_MODEM_DarumaFramework";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Método rRetornarOperadora_MODEM_DarumaFramework";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.Button BT_Operadora;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Operadora;
    }
}