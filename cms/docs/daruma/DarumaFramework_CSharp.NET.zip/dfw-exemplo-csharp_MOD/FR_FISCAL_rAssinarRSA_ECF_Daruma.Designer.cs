﻿namespace DarumaFramework_CSharp
{
    partial class FR_FISCAL_rAssinarRSA_ECF_Daruma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BT_CaminhoChavePrivada = new System.Windows.Forms.Button();
            this.BT_CaminhoArquivo = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TB_Assinatura = new System.Windows.Forms.TextBox();
            this.TB_CaminhoChavePrivada = new System.Windows.Forms.TextBox();
            this.TB_CaminhoArquivo = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(398, 226);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(77, 23);
            this.BT_Fechar.TabIndex = 85;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(317, 226);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(77, 23);
            this.BT_Enviar.TabIndex = 84;
            this.BT_Enviar.Text = "Enviar";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BT_CaminhoChavePrivada);
            this.groupBox1.Controls.Add(this.BT_CaminhoArquivo);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TB_Assinatura);
            this.groupBox1.Controls.Add(this.TB_CaminhoChavePrivada);
            this.groupBox1.Controls.Add(this.TB_CaminhoArquivo);
            this.groupBox1.Location = new System.Drawing.Point(10, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(475, 210);
            this.groupBox1.TabIndex = 86;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Assinando Arquivos:";
            // 
            // BT_CaminhoChavePrivada
            // 
            this.BT_CaminhoChavePrivada.Location = new System.Drawing.Point(434, 76);
            this.BT_CaminhoChavePrivada.Name = "BT_CaminhoChavePrivada";
            this.BT_CaminhoChavePrivada.Size = new System.Drawing.Size(25, 23);
            this.BT_CaminhoChavePrivada.TabIndex = 11;
            this.BT_CaminhoChavePrivada.Text = "...";
            this.BT_CaminhoChavePrivada.UseVisualStyleBackColor = true;
            this.BT_CaminhoChavePrivada.Click += new System.EventHandler(this.BT_CaminhoChavePrivada_Click);
            // 
            // BT_CaminhoArquivo
            // 
            this.BT_CaminhoArquivo.Location = new System.Drawing.Point(434, 36);
            this.BT_CaminhoArquivo.Name = "BT_CaminhoArquivo";
            this.BT_CaminhoArquivo.Size = new System.Drawing.Size(25, 23);
            this.BT_CaminhoArquivo.TabIndex = 10;
            this.BT_CaminhoArquivo.Text = "...";
            this.BT_CaminhoArquivo.UseVisualStyleBackColor = true;
            this.BT_CaminhoArquivo.Click += new System.EventHandler(this.BT_CaminhoArquivo_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Assinatura Gerada:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(242, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Caminho da chave privada gerada pelo puttyGen:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Caminho do arquivo a ser assinado:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // TB_Assinatura
            // 
            this.TB_Assinatura.Location = new System.Drawing.Point(27, 123);
            this.TB_Assinatura.Multiline = true;
            this.TB_Assinatura.Name = "TB_Assinatura";
            this.TB_Assinatura.Size = new System.Drawing.Size(401, 75);
            this.TB_Assinatura.TabIndex = 3;
            this.TB_Assinatura.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // TB_CaminhoChavePrivada
            // 
            this.TB_CaminhoChavePrivada.Location = new System.Drawing.Point(9, 78);
            this.TB_CaminhoChavePrivada.Name = "TB_CaminhoChavePrivada";
            this.TB_CaminhoChavePrivada.Size = new System.Drawing.Size(419, 20);
            this.TB_CaminhoChavePrivada.TabIndex = 4;
            this.TB_CaminhoChavePrivada.TextChanged += new System.EventHandler(this.TB_ChavePrivada_TextChanged);
            // 
            // TB_CaminhoArquivo
            // 
            this.TB_CaminhoArquivo.Location = new System.Drawing.Point(9, 39);
            this.TB_CaminhoArquivo.Name = "TB_CaminhoArquivo";
            this.TB_CaminhoArquivo.Size = new System.Drawing.Size(419, 20);
            this.TB_CaminhoArquivo.TabIndex = 5;
            this.TB_CaminhoArquivo.TextChanged += new System.EventHandler(this.TB_PathArquivo_TextChanged);
            // 
            // FR_FISCAL_rAssinarRSA_ECF_Daruma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 255);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Enviar);
            this.Name = "FR_FISCAL_rAssinarRSA_ECF_Daruma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "rAssinarRSA_ECF_Daruma";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TB_Assinatura;
        private System.Windows.Forms.TextBox TB_CaminhoChavePrivada;
        private System.Windows.Forms.TextBox TB_CaminhoArquivo;
        private System.Windows.Forms.Button BT_CaminhoArquivo;
        private System.Windows.Forms.Button BT_CaminhoChavePrivada;
    }
}