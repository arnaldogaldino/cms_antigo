namespace DarumaFramework_CSharp
{
    partial class FR_DUAL_menuTestes_LoopingStatusDocumento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.LB_StatusDoc = new System.Windows.Forms.Label();
            this.TB_StatusDoc = new System.Windows.Forms.TextBox();
            this.BT_Enviar = new System.Windows.Forms.Button();
            this.BT_Stop = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.TM_StatusDoc = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // LB_StatusDoc
            // 
            this.LB_StatusDoc.AutoSize = true;
            this.LB_StatusDoc.Location = new System.Drawing.Point(8, 23);
            this.LB_StatusDoc.Name = "LB_StatusDoc";
            this.LB_StatusDoc.Size = new System.Drawing.Size(182, 13);
            this.LB_StatusDoc.TabIndex = 0;
            this.LB_StatusDoc.Text = "Status do Documento na Impressora:";
            // 
            // TB_StatusDoc
            // 
            this.TB_StatusDoc.Location = new System.Drawing.Point(11, 39);
            this.TB_StatusDoc.Name = "TB_StatusDoc";
            this.TB_StatusDoc.Size = new System.Drawing.Size(349, 20);
            this.TB_StatusDoc.TabIndex = 1;
            // 
            // BT_Enviar
            // 
            this.BT_Enviar.Location = new System.Drawing.Point(404, 23);
            this.BT_Enviar.Name = "BT_Enviar";
            this.BT_Enviar.Size = new System.Drawing.Size(93, 26);
            this.BT_Enviar.TabIndex = 2;
            this.BT_Enviar.Text = "Start";
            this.BT_Enviar.UseVisualStyleBackColor = true;
            this.BT_Enviar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Stop
            // 
            this.BT_Stop.Location = new System.Drawing.Point(404, 66);
            this.BT_Stop.Name = "BT_Stop";
            this.BT_Stop.Size = new System.Drawing.Size(93, 26);
            this.BT_Stop.TabIndex = 3;
            this.BT_Stop.Text = "Stop";
            this.BT_Stop.UseVisualStyleBackColor = true;
            this.BT_Stop.Click += new System.EventHandler(this.BT_Stop_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(404, 114);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(93, 26);
            this.BT_Fechar.TabIndex = 4;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // TM_StatusDoc
            // 
            this.TM_StatusDoc.Interval = 500;
            this.TM_StatusDoc.Tick += new System.EventHandler(this.TM_StatusDoc_Tick);
            // 
            // FR_DUAL_menuTestes_LoopingStatusDocumento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 154);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Stop);
            this.Controls.Add(this.BT_Enviar);
            this.Controls.Add(this.TB_StatusDoc);
            this.Controls.Add(this.LB_StatusDoc);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_DUAL_menuTestes_LoopingStatusDocumento";
            this.Text = "Verifica��o de Looping de Status de Documento           Daruma DDC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_StatusDoc;
        private System.Windows.Forms.TextBox TB_StatusDoc;
        private System.Windows.Forms.Button BT_Enviar;
        private System.Windows.Forms.Button BT_Stop;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Timer TM_StatusDoc;
    }
}