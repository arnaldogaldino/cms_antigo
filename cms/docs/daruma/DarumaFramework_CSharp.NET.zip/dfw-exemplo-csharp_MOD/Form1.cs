﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rRetornarImei_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rRetornarImei_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }
    }
}
