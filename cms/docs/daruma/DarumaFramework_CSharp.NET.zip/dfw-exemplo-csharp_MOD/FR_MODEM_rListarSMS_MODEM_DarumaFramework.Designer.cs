namespace DarumaFramework_CSharp
{
    partial class FR_MODEM_rListarSMS_MODEM_DarumaFramework
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_RespostaModem = new System.Windows.Forms.Label();
            this.TB_RespostaModem = new System.Windows.Forms.TextBox();
            this.BT_Listar = new System.Windows.Forms.Button();
            this.BT_Fechar = new System.Windows.Forms.Button();
            this.BT_Limpar = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // LB_RespostaModem
            // 
            this.LB_RespostaModem.AutoSize = true;
            this.LB_RespostaModem.Location = new System.Drawing.Point(27, 18);
            this.LB_RespostaModem.Name = "LB_RespostaModem";
            this.LB_RespostaModem.Size = new System.Drawing.Size(157, 13);
            this.LB_RespostaModem.TabIndex = 2;
            this.LB_RespostaModem.Text = "Resposta Recebida do Modem:";
            // 
            // TB_RespostaModem
            // 
            this.TB_RespostaModem.Location = new System.Drawing.Point(30, 34);
            this.TB_RespostaModem.Multiline = true;
            this.TB_RespostaModem.Name = "TB_RespostaModem";
            this.TB_RespostaModem.ReadOnly = true;
            this.TB_RespostaModem.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TB_RespostaModem.Size = new System.Drawing.Size(238, 21);
            this.TB_RespostaModem.TabIndex = 3;
            this.TB_RespostaModem.WordWrap = false;
            // 
            // BT_Listar
            // 
            this.BT_Listar.Location = new System.Drawing.Point(31, 61);
            this.BT_Listar.Name = "BT_Listar";
            this.BT_Listar.Size = new System.Drawing.Size(75, 23);
            this.BT_Listar.TabIndex = 4;
            this.BT_Listar.Text = "Listar";
            this.BT_Listar.UseVisualStyleBackColor = true;
            this.BT_Listar.Click += new System.EventHandler(this.BT_Enviar_Click);
            // 
            // BT_Fechar
            // 
            this.BT_Fechar.Location = new System.Drawing.Point(193, 61);
            this.BT_Fechar.Name = "BT_Fechar";
            this.BT_Fechar.Size = new System.Drawing.Size(75, 23);
            this.BT_Fechar.TabIndex = 5;
            this.BT_Fechar.Text = "Fechar";
            this.BT_Fechar.UseVisualStyleBackColor = true;
            this.BT_Fechar.Click += new System.EventHandler(this.BT_Fechar_Click);
            // 
            // BT_Limpar
            // 
            this.BT_Limpar.Location = new System.Drawing.Point(112, 61);
            this.BT_Limpar.Name = "BT_Limpar";
            this.BT_Limpar.Size = new System.Drawing.Size(75, 23);
            this.BT_Limpar.TabIndex = 6;
            this.BT_Limpar.Text = "Limpar";
            this.BT_Limpar.UseVisualStyleBackColor = true;
            this.BT_Limpar.Click += new System.EventHandler(this.BT_Limpar_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.SystemColors.Control;
            this.richTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.richTextBox1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(2, 101);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(294, 32);
            this.richTextBox1.TabIndex = 7;
            this.richTextBox1.Text = "Obs: A lista ser� criada no local especificado pela\nchave <localarquivo> do regis" +
                "tro do windows.";
            // 
            // FR_MODEM_rLerSMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(294, 133);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.BT_Limpar);
            this.Controls.Add(this.BT_Fechar);
            this.Controls.Add(this.BT_Listar);
            this.Controls.Add(this.TB_RespostaModem);
            this.Controls.Add(this.LB_RespostaModem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FR_MODEM_rLerSMS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "M�todo rListarSms_MODEM_DarumaFramework";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LB_RespostaModem;
        private System.Windows.Forms.TextBox TB_RespostaModem;
        private System.Windows.Forms.Button BT_Listar;
        private System.Windows.Forms.Button BT_Fechar;
        private System.Windows.Forms.Button BT_Limpar;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}