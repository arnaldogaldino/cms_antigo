﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DFW;

namespace DarumaFramework_CSharp
{
    public partial class FR_MODEM_rNivelSinalRecebido_MODEM_DarumaFramework : Form
    {
        public FR_MODEM_rNivelSinalRecebido_MODEM_DarumaFramework()
        {
            InitializeComponent();
        }

        private void BT_Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Bt_Verificar_Click(object sender, EventArgs e)
        {
            Declaracoes.iRetorno = Declaracoes.rNivelSinalRecebido_MODEM_DarumaFramework();

            if (Declaracoes.iRetorno >= 0)
            {
                TB_RetornoModem.Text = Declaracoes.iRetorno.ToString();
                
            }
            else
            {
                MessageBox.Show("Erro ao Verificar o sinal", "Daruma DLL Framework", MessageBoxButtons.OK, MessageBoxIcon.Error);
                switch (Declaracoes.iRetorno)
                {
                    case -3: TB_RetornoModem.Text = "[-3] - Modem retornou caractere(s) inválido(s)";
                        break;
                    case -2: TB_RetornoModem.Text = "[-2] - Modem retornou erro";
                        break;
                    case -1: TB_RetornoModem.Text = "[-1] - Erro de comunicação serial";
                        break;
                }
            }
            

        }
    }
}
